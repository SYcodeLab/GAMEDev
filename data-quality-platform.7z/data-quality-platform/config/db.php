<?php
$host = 'localhost';
$db   = 'damu_quality_db'; 
$user = 'root';       
$pass = '';           

try {
    // Создаем подключение
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    
    // Настраиваем режим ошибок и формат вывода данных
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

} catch (PDOException $e) {
    die("Ошибка подключения к БД: " . $e->getMessage());
}