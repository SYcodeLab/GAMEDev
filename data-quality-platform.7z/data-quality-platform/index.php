<?php
// --- 1. ЗАЩИТА ---
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: register.php'); 
    exit;
}

// --- 2. ПОДКЛЮЧЕНИЕ И ДАННЫЕ ---
require_once 'config/db.php';

try {
    // Запрос данных
    $sql = "SELECT r.id, r.rule_name, r.description, r.criticality, l.check_date, l.errors_found, l.status 
            FROM dq_rules r
            LEFT JOIN (SELECT * FROM dq_logs WHERE id IN (SELECT MAX(id) FROM dq_logs GROUP BY rule_id)) l 
            ON r.id = l.rule_id";
    $stmt = $pdo->query($sql);
    $checks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // --- ЛОГИКА СТАТИСТИКИ ДЛЯ ГРАФИКА ---
    $stats = ['Success' => 0, 'Warning' => 0, 'Critical' => 0, 'NEW' => 0];
    foreach ($checks as $check) {
        $status = $check['status'] ?? 'NEW';
        if (isset($stats[$status])) {
            $stats[$status]++;
        } else {
            $stats['NEW']++;
        }
    }

} catch (PDOException $e) {
    die("Ошибка SQL: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Платформа качества данных | DAMU</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

    <div class="top-navbar">
        <div class="logo">
            <i class="fas fa-layer-group"></i> DAMU <span style="font-weight:300; margin-left:5px;">Quality</span>
        </div>
        <div class="user-profile">
            <a href="profile.php" style="text-decoration: none; color: inherit; display: flex; align-items: center; gap: 10px;">
                <div class="avatar">
                    <?php echo mb_substr($_SESSION['user_name'] ?? 'U', 0, 1); ?>
                </div>
            </a>
            <a href="logout.php" style="margin-left:15px; color:#E74C3C;" title="Выйти из системы">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </div>

    <div class="layout">
        <div class="sidebar">
            <a href="index.php" class="nav-item active"><i class="fas fa-chart-line"></i> Мониторинг качества</a>
            <a href="rules.php" class="nav-item"><i class="fas fa-cog"></i> Настройка правил</a>
            
            <hr style="border: 0.5px solid #444; margin: 20px 0;">
            
            <a href="analytics.php" class="nav-item" style="background: rgba(39, 174, 96, 0.1); color: #2ecc71;">
                <i class="fas fa-file-invoice-dollar"></i> 
                <span>Управленческая отчетность</span>
            </a>

            <a href="AI/ai_dashboard.php" class="nav-item" style="background: rgba(155, 89, 182, 0.1); color: #9b59b6; margin-top: 10px; border: 1px dashed #9b59b6;">
                <i class="fas fa-robot"></i> 
                <span>AI Авто-исправление</span>
                <span class="badge-new" style="background:#e74c3c; color:white; font-size:10px; padding:2px 5px; border-radius:10px; margin-left:5px;">AI</span>
            </a>

        </div>



        <div class="content-area">
            <div class="page-header">
                <h1>Панель управления качеством данных</h1>
                <p>Оперативный контроль целостности баз данных Фонда "Даму".</p>
            </div>

            <div style="display: flex; gap: 20px; margin-bottom: 30px;">
                <div class="data-card" style="flex: 1; display: flex; align-items: center; justify-content: center;">
                    <div style="width: 250px;">
                        <canvas id="statusChart"></canvas>
                    </div>
                </div>

                <div class="data-card" style="flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 15px;">
                    <div>
                        <h2 style="margin:0; font-size: 36px; color: #27AE60;"><?php echo $stats['Success']; ?></h2>
                        <span style="color:#7f8c8d;">Успешных проверок (Clean)</span>
                    </div>
                    <div>
                        <h2 style="margin:0; font-size: 36px; color: #E74C3C;"><?php echo $stats['Critical']; ?></h2>
                        <span style="color:#7f8c8d;">Критических аномалий</span>
                    </div>
                    <div>
                        <h2 style="margin:0; font-size: 36px; color: #0055A5;"><?php echo count($checks); ?></h2>
                        <span style="color:#7f8c8d;">Всего активных правил SQL</span>
                    </div>
                </div>
            </div>

            <div class="data-card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h3 style="margin:0;">Детальный лог DQ-проверок</h3>
                    <button class="btn-run" onclick="location.reload()"><i class="fas fa-sync"></i> Обновить статус</button>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Правило контроля</th>
                            <th>Критичность</th>
                            <th>Ошибок найдено</th>
                            <th>Статус</th>
                            <th>Действие</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($checks as $check): ?>
                        <tr>
                            <td>#<?php echo $check['id']; ?></td>
                            <td><?php echo htmlspecialchars($check['rule_name']); ?></td>
                            <td>
                                <span class="badge" style="color: <?php echo ($check['criticality'] == 'High') ? '#E74C3C' : '#3498db'; ?>">
                                    ● <?php echo $check['criticality']; ?>
                                </span>
                            </td>
                            <td><b><?php echo $check['errors_found'] ?? 0; ?></b></td>
                            <td>
                                <span class="status-badge st-<?php echo $check['status'] ?? 'Success'; ?>">
                                    <?php echo $check['status'] ?? 'NEW'; ?>
                                </span>
                            </td>
                            <td><button class="btn-run" onclick="runCheck(<?php echo $check['id']; ?>, this)">Запустить SQL</button></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="footer">
        <div style="opacity: 0.8;">
            &copy; 2026 АО «Фонд развития предпринимательства «Даму».<br>
            Система мониторинга качества данных v1.0.4
        </div>
        <div style="text-align: right;">
            Поддержка: <a href="mailto:support@damu.kz" style="color: #0055A5;">support@damu.kz</a>
        </div>
    </div>

    <script>
        const ctx = document.getElementById('statusChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Успешно', 'Внимание', 'Критично', 'Новые'],
                datasets: [{
                    data: [
                        <?php echo $stats['Success']; ?>, 
                        <?php echo $stats['Warning']; ?>, 
                        <?php echo $stats['Critical']; ?>,
                        <?php echo $stats['NEW']; ?>
                    ],
                    backgroundColor: ['#27AE60', '#F39C12', '#E74C3C', '#BDC3C7'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 12 } },
                }
            }
        });
    </script>
    <script src="assets/js/main.js"></script>
</body>
</html>