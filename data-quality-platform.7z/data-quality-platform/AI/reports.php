<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Дальше ваш код...

// Проверяем, было ли выполнено сканирование (используем тот же флаг, что и в мониторе)
$is_scanned = isset($_SESSION['last_scan']) && (time() - $_SESSION['last_scan'] < 3600);

// 1. Получаем общую статистику
$statsStmt = $pdo->query("SELECT 
    SUM(CASE WHEN status = 'detected' THEN 1 ELSE 0 END) as active,
    SUM(CASE WHEN status = 'fixed' THEN 1 ELSE 0 END) as fixed
    FROM ai_anomaly_detected");
$totals = $statsStmt->fetch(PDO::FETCH_ASSOC);

// 2. Статистика по типам ошибок (для круговой диаграммы)
$typeStmt = $pdo->query("SELECT column_name, COUNT(*) as count FROM ai_anomaly_detected GROUP BY column_name");
$typesData = $typeStmt->fetchAll(PDO::FETCH_ASSOC);

// 3. ПОЛУЧАЕМ СПИСОК ИСПРАВЛЕННЫХ ДАННЫХ
$historyStmt = $pdo->query("SELECT * FROM ai_anomaly_detected WHERE status = 'fixed' ORDER BY fixed_at DESC");
$history = $historyStmt->fetchAll(PDO::FETCH_ASSOC);

// Подготовка данных для JS
$labels = [];
$counts = [];
foreach($typesData as $row) {
    $labels[] = $row['column_name'];
    $counts[] = $row['count'];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Отчеты | DAMU AI Quality Control</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary: #1e293b;
            --accent: #8e44ad;
            --bg-light: #f8fafc;
            --success: #27ae60;
        }
        body { margin: 0; font-family: 'Inter', sans-serif; background: var(--bg-light); display: flex; height: 100vh; }
        
        .sidebar { width: 280px; background: #1e293b; color: white; display: flex; flex-direction: column; flex-shrink: 0; }
        .sidebar-header { padding: 30px; font-size: 22px; font-weight: 700; border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; align-items: center; gap: 12px; }
        .nav-menu { padding: 20px 0; flex-grow: 1; }
        .nav-item { padding: 15px 30px; display: flex; align-items: center; gap: 15px; color: #94a3b8; text-decoration: none; transition: 0.3s; }
        .nav-item:hover, .nav-item.active { background: rgba(255,255,255,0.05); color: white; }
        .nav-item.active { border-left: 4px solid var(--accent); background: linear-gradient(90deg, rgba(142, 68, 173, 0.1) 0%, transparent 100%); }

        .main-content { flex-grow: 1; overflow-y: auto; padding: 40px; }
        .report-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 30px; }
        
        .card { background: white; padding: 30px; border-radius: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); }
        .stat-huge { font-size: 48px; font-weight: 800; color: var(--primary); }

        .history-card { background: white; border-radius: 20px; padding: 30px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); }
        .data-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .data-table th { text-align: left; padding: 15px; color: #64748b; font-size: 13px; border-bottom: 2px solid #f1f5f9; }
        .data-table td { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; vertical-align: middle; }
        
        .badge { padding: 5px 12px; border-radius: 6px; font-size: 12px; font-weight: 600; background: #ecfdf5; color: #059669; display: inline-flex; align-items: center; gap: 5px; }
        .val-old { color: #e74c3c; text-decoration: line-through; margin-right: 10px; font-size: 12px; }
        .val-new { color: var(--success); font-weight: 600; }
        .type-tag { font-size: 11px; background: #f1f5f9; padding: 3px 8px; border-radius: 4px; color: #475569; }

        /* Состояние "Пусто" */
        .empty-state { text-align: center; padding: 80px 20px; background: white; border-radius: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); margin-top: 20px; }
        .empty-icon { width: 100px; height: 100px; background: #f1f5f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 25px; color: #cbd5e1; font-size: 40px; }
        .btn-go { display: inline-block; background: var(--accent); color: white; padding: 12px 30px; border-radius: 10px; text-decoration: none; font-weight: 600; margin-top: 20px; transition: 0.3s; }
        .btn-go:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(142, 68, 173, 0.3); }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header"><i class="fas fa-shield-virus"></i><span>DAMU AI</span></div>
        <div class="nav-menu">
            <a href="ai_dashboard.php" class="nav-item"><i class="fas fa-home"></i> Главная</a>
            <a href="ai_monitor.php" class="nav-item"><i class="fas fa-magic"></i> AI Валидатор</a>
            <a href="reports.php" class="nav-item active"><i class="fas fa-chart-line"></i> Отчеты</a>
            <a href="sources.php" class="nav-item"><i class="fas fa-database"></i> Источники данных</a>
        </div>
    </div>

    <div class="main-content">
        <h1 style="font-weight: 700; color: var(--primary);">Аналитический отчет качества данных</h1>
        <p style="color: #64748b; margin-bottom: 40px;">Обзор исправленных аномалий и мониторинг точности системы.</p>

        <?php if (!$is_scanned): ?>
            <div class="empty-state">
                <div class="empty-icon"><i class="fas fa-chart-pie"></i></div>
                <h2 style="color: var(--primary); margin-bottom: 10px;">Отчеты не сформированы</h2>
                <p style="color: #64748b; max-width: 500px; margin: 0 auto;">Для построения аналитики необходимо запустить сканирование базы данных в разделе AI Валидатор.</p>
                <a href="ai_monitor.php" class="btn-go">Перейти к сканированию</a>
            </div>
        <?php else: ?>
            <div class="report-grid">
                <div class="card">
                    <h3 style="margin-top:0;">Статус обработки</h3>
                    <div style="display: flex; gap: 40px; margin-top: 20px;">
                        <div>
                            <div style="color: #64748b; font-size: 14px;">В очереди</div>
                            <div class="stat-huge" style="color: #f39c12;"><?php echo $totals['active'] ?? 0; ?></div>
                        </div>
                        <div>
                            <div style="color: #64748b; font-size: 14px;">Исправлено AI</div>
                            <div class="stat-huge" style="color: #27ae60;"><?php echo $totals['fixed'] ?? 0; ?></div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <h3 style="margin-top:0;">Типы выявленных аномалий</h3>
                    <canvas id="typesChart" style="max-height: 180px;"></canvas>
                </div>
            </div>

            <div class="history-card">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="margin:0;">Журнал автоматических исправлений</h3>
                    <span class="badge"><i class="fas fa-check-circle"></i> Всего исправлено: <?php echo count($history); ?></span>
                </div>
                
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Дата и время</th>
                            <th>Объект / Поле</th>
                            <th>Корректировка (Было → Стало)</th>
                            <th>Причина исправления</th>
                            <th>Исполнитель</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($history) > 0): ?>
                            <?php foreach($history as $row): ?>
                            <tr>
                                <td style="color: #64748b;"><?php echo date('d.m.Y H:i', strtotime($row['fixed_at'])); ?></td>
                                <td>
                                    <div style="font-weight:600;"><?php echo htmlspecialchars($row['entity_type']); ?> #<?php echo $row['entity_id']; ?></div>
                                    <div class="type-tag"><?php echo htmlspecialchars($row['column_name']); ?></div>
                                </td>
                                <td>
                                    <span class="val-old"><?php echo htmlspecialchars($row['current_value']); ?></span>
                                    <i class="fas fa-long-arrow-alt-right" style="color: #94a3b8; margin-right: 10px;"></i>
                                    <span class="val-new"><?php echo htmlspecialchars($row['ai_suggestion']); ?></span>
                                </td>
                                <td style="font-size: 13px;">
                                    <div style="color: #e74c3c; font-weight: 500; margin-bottom: 4px;">
                                        <i class="fas fa-exclamation-triangle"></i> Было выявлено:
                                    </div>
                                    <div style="color: #475569; font-style: italic;">
                                        <?php echo htmlspecialchars($row['anomaly_type'] ?? 'Логическая ошибка'); ?>
                                    </div>
                                </td>
                                <td>
                                    <div style="display:flex; align-items:center; gap:8px;">
                                        <div style="width:24px; height:24px; background:var(--accent); border-radius:50%; display:flex; align-items:center; justify-content:center; color:white; font-size:10px;">
                                            <?php echo substr($row['fixed_by'] ?? 'A', 0, 1); ?>
                                        </div>
                                        <?php echo htmlspecialchars($row['fixed_by'] ?? 'Система'); ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="text-align:center; padding: 40px; color: #94a3b8;">
                                    <i class="fas fa-history" style="font-size: 24px; display:block; margin-bottom:10px;"></i>
                                    Аномалии найдены, но еще не исправлены
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <script>
                const ctx = document.getElementById('typesChart').getContext('2d');
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: <?php echo json_encode($labels); ?>,
                        datasets: [{
                            data: <?php echo json_encode($counts); ?>,
                            backgroundColor: ['#8e44ad', '#3498db', '#e67e22', '#2ecc71', '#e74c3c'],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { position: 'right', labels: { usePointStyle: true, boxWidth: 8 } }
                        },
                        cutout: '80%'
                    }
                });
            </script>
        <?php endif; ?>
    </div>
</body>
</html>