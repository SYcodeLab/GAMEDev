<?php
session_start();
require_once __DIR__ . '/../config/db.php';


$total_stmt = $pdo->query("SELECT COUNT(*) FROM ai_anomaly_detected");
$total_found = $total_stmt->fetchColumn();

$fixed_stmt = $pdo->query("SELECT COUNT(*) FROM ai_anomaly_detected WHERE status = 'fixed'");
$total_fixed = $fixed_stmt->fetchColumn();

$is_scanned = isset($_SESSION['last_scan']);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Панель управления | DAMU AI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root { --primary: #1e293b; --accent: #8e44ad; --bg: #f8fafc; --success: #27ae60; }
        body { margin: 0; font-family: 'Inter', sans-serif; background: var(--bg); display: flex; height: 100vh; }
        .sidebar { width: 280px; background: #1e293b; color: white; display: flex; flex-direction: column; }
        .sidebar-header { padding: 30px; font-size: 22px; font-weight: 700; border-bottom: 1px solid rgba(255,255,255,0.05); }
        .nav-item { padding: 15px 30px; display: flex; align-items: center; gap: 15px; color: #94a3b8; text-decoration: none; }
        .nav-item.active { border-left: 4px solid var(--accent); color: white; background: rgba(255,255,255,0.05); }
        .main-content { flex: 1; padding: 40px; overflow-y: auto; }
        .welcome-card { background: linear-gradient(135deg, #8e44ad 0%, #6c3483 100%); color: white; padding: 40px; border-radius: 24px; margin-bottom: 30px; position: relative; overflow: hidden; }
        .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 25px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 25px; border-radius: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); }
        .stat-val { font-size: 32px; font-weight: 800; margin: 10px 0; }
        
        .action-card { border: 2px dashed #cbd5e1; border-radius: 20px; padding: 20px; text-align: center; cursor: pointer; transition: 0.3s; text-decoration: none; color: inherit; display: block;}
        .action-card:hover { border-color: var(--accent); background: #fdf2ff; transform: translateY(-3px); }

        /* ЧАТ СТИЛИ */
        .chat-card { background: white; border-radius: 24px; padding: 30px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); border-left: 6px solid var(--accent); }
        #chatWindow { height: 250px; overflow-y: auto; padding: 15px; background: #fcfaff; border-radius: 12px; margin-bottom: 20px; display: flex; flex-direction: column; gap: 12px; border: 1px solid #f1e9f7; }
        .msg { padding: 12px 18px; border-radius: 15px; font-size: 14px; max-width: 80%; line-height: 1.5; }
        .msg.ai { background: white; border: 1px solid #eee; align-self: flex-start; box-shadow: 0 2px 5px rgba(0,0,0,0.02); }
        .msg.user { background: var(--accent); color: white; align-self: flex-end; }
        .chat-input-group { display: flex; gap: 12px; }
        .chat-input-group input { flex: 1; padding: 15px; border: 1px solid #ddd; border-radius: 12px; outline: none; transition: 0.3s; }
        .chat-input-group input:focus { border-color: var(--accent); }
        .btn-send { background: var(--accent); color: white; border: none; padding: 0 25px; border-radius: 12px; cursor: pointer; font-weight: 600; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header"><i class="fas fa-shield-virus"></i><span>DAMU AI</span></div>
        <div class="nav-menu">
            <a href="ai_dashboard.php" class="nav-item active"><i class="fas fa-home"></i> Главная</a>
            <a href="ai_monitor.php" class="nav-item"><i class="fas fa-magic"></i> AI Валидатор</a>
            <a href="reports.php" class="nav-item"><i class="fas fa-chart-line"></i> Отчеты</a>
            <a href="sources.php" class="nav-item"><i class="fas fa-database"></i> Источники данных</a>
            <a href="../index.php" class="nav-item" style="color: #fb7185;"><i class="fas fa-arrow-left"></i> Назад в платформу
        </a>
        </div>
    </div>

    <div class="main-content">
        <div class="welcome-card">
            <i class="fas fa-robot" style="position: absolute; right: -20px; bottom: -20px; font-size: 200px; opacity: 0.1;"></i>
            <h1 style="margin: 0; font-size: 32px;">Добро пожаловать, Chuck Magee</h1>
            <p style="opacity: 0.8; margin-top: 10px;">Система готова подготовить для вас любые аналитические выгрузки.</p>
        </div>

        <div class="stats-row">
            <div class="stat-card">
                <div style="color: #64748b; font-size: 14px; font-weight: 600;">АКТИВНЫХ АНОМАЛИЙ</div>
                <div class="stat-val"><?php echo ($total_found - $total_fixed); ?></div>
            </div>
            <div class="stat-card">
                <div style="color: #64748b; font-size: 14px; font-weight: 600;">ИСПРАВЛЕНО СИСТЕМОЙ</div>
                <div class="stat-val" style="color: var(--success);"><?php echo $total_fixed; ?></div>
            </div>
            <div class="stat-card">
                <div style="color: #64748b; font-size: 14px; font-weight: 600;">СКАНИРОВАНИЕ</div>
                <div class="stat-val" style="font-size: 22px;">
                    <?php echo $is_scanned ? '<span style="color:var(--success)">Выполнено</span>' : '<span style="color:#f39c12">Требуется</span>'; ?>
                </div>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 30px;">
            <div>
                <h3>Быстрые действия</h3>
                <a href="ai_monitor.php" class="action-card" style="margin-bottom: 15px;">
                    <i class="fas fa-search" style="color: var(--accent); margin-bottom: 10px; font-size: 20px;"></i>
                    <div style="font-weight: 600;">AI Аудит</div>
                </a>
                <a href="reports.php" class="action-card">
                    <i class="fas fa-file-alt" style="color: #3498db; margin-bottom: 10px; font-size: 20px;"></i>
                    <div style="font-weight: 600;">Все отчеты</div>
                </a>
            </div>

            <div class="chat-card">
                <h3 style="margin-top: 0;"><i class="fas fa-comment-alt" style="color: var(--accent);"></i> AI Ассистент выгрузки</h3>
                <div id="chatWindow">
                    <div class="msg ai">Здравствуйте! Я могу подготовить для вас отчеты, CSV-выгрузки или провести анализ последних исправлений. Что вас интересует?</div>
                </div>
                <div class="chat-input-group">
                    <input type="text" id="userInput" placeholder="Напр: 'Сформируй отчет по исправлениям БИН'">
                    <button onclick="sendAiQuery()" class="btn-send">Спросить</button>
                </div>
            </div>
        </div>
    </div>

    <script>
    async function sendAiQuery() {
        const input = document.getElementById('userInput');
        const chat = document.getElementById('chatWindow');
        if(!input.value) return;

        const userMsg = input.value;
        chat.innerHTML += `<div class="msg user">${userMsg}</div>`;
        input.value = '';
        chat.scrollTop = chat.scrollHeight;

        try {
            const res = await fetch('api.php?action=ai_query');
            const data = await res.json();

            setTimeout(() => {
                chat.innerHTML += `
                    <div class="msg ai">
                        ${data.text}<br><br>
                        <a href="${data.export_url}" style="color: var(--accent); font-weight:700; text-decoration:none;">
                            <i class="fas fa-download"></i> Скачать сформированный CSV
                        </a>
                    </div>`;
                chat.scrollTop = chat.scrollHeight;
            }, 600);
        } catch (e) {
            console.error("Ошибка API");
        }
    }

    // Позволяем отправлять по нажатию Enter
    document.getElementById('userInput').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') sendAiQuery();
    });
    </script>
</body>
</html>