<?php
session_start();
require_once 'config/db.php';

// Если форма отправлена
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Ищем пользователя в БД
    $stmt = $pdo->prepare("SELECT * FROM dq_users WHERE username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Проверяем пароль
    if ($user && $user['password'] === $password) {
        // УСПЕХ: Записываем пользователя в сессию
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['full_name'];
        
        // Перенаправляем на дашборд
        header('Location: index.php');
        exit;
    } else {
        $error = "Неверный логин или пароль";
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход в систему | DAMU Quality</title>
    <style>
        body {
            background-color: #F4F7FA;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-card {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 350px;
            text-align: center;
            border-top: 5px solid #0055A5; /* Синий цвет Даму */
        }
        h2 { color: #003366; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; text-align: left; }
        label { display: block; margin-bottom: 5px; color: #666; font-size: 14px; }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #0055A5;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }
        button:hover { background-color: #004080; }
        .error { color: red; font-size: 14px; margin-bottom: 15px; }
        .logo { font-size: 24px; font-weight: bold; color: #0055A5; margin-bottom: 10px; display: block; }
    </style>
</head>
<body>

    <div class="login-card">
        <span class="logo">DAMU Quality</span>
        <h2>Вход в систему</h2>

        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Логин</label>
                <input type="text" name="username" placeholder="Введите логин" required>
            </div>
            <div class="form-group">
                <label>Пароль</label>
                <input type="password" name="password" placeholder="Введите пароль" required>
            </div>
            <button type="submit">Войти</button>
            
            <button type="button" style="background-color: #fff; color: #0055A5; border: 1px solid #0055A5; margin-top: 10px;" onclick="alert('Для локальной версии вход по ЭЦП отключен.\nИспользуйте логин/пароль.')">
                <i class="fas fa-key"></i> Войти через ЭЦП (NCALayer)
            </button>
        </form>
            
        </form>

        <div style="margin-top: 20px; font-size: 14px;">
            Нет аккаунта? <a href="register.php" style="color: #0055A5; text-decoration: none; font-weight: bold;">Зарегистрироваться</a>
        </div>

        <?php if (isset($_GET['registered'])): ?>
            <p style="color: green; margin-top: 10px; font-size: 14px;">Регистрация успешна! Теперь войдите.</p>
        <?php endif; ?>

    </div>

</body>
</html>