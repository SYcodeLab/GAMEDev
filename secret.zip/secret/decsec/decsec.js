#!/usr/bin/env node
'use strict';
// ═══════════════════════════════════════════════════════════════════════
//  decSec OS  ·  SWX Language Terminal  v6.0.0
//  Автор: Slywerx  |  decSec Project  |  2025
//
//  ИСПОЛЬЗОВАНИЕ:
//    node decsec                  → интерактивный REPL
//    node decsec script.swx       → запуск файла
//    node decsec -e "wx 'hello'"  → inline выполнение
//    node decsec -w script.swx    → watch режим (перезапуск при изменении)
//    node decsec --help           → справка
//    node decsec --version        → версия
// ═══════════════════════════════════════════════════════════════════════

const readline = require('readline');
const fs       = require('fs');
const path     = require('path');
const os       = require('os');
const { Interpreter } = require('./src/interpreter');

const VERSION   = '7.0.0';
const HOME      = os.homedir();
const HIST_FILE = path.join(HOME, '.swx_history');
const RC_FILE   = path.join(HOME, '.swxrc');
let   NO_COLOR  = process.argv.includes('--no-color') || !!process.env.NO_COLOR;

// ─────────────────────────────────────────────────────────────────
//  ANSI
// ─────────────────────────────────────────────────────────────────
const A = {
  r:'\x1b[0m', b:'\x1b[1m', d:'\x1b[2m',
  black:'\x1b[30m', red:'\x1b[31m', green:'\x1b[32m', yellow:'\x1b[33m',
  cyan:'\x1b[36m', white:'\x1b[37m',
  BLACK:'\x1b[90m', RED:'\x1b[91m', GREEN:'\x1b[92m', YELLOW:'\x1b[93m',
  BLUE:'\x1b[94m', MAG:'\x1b[95m', CYAN:'\x1b[96m', WHITE:'\x1b[97m',
};
const p  = (c, s) => NO_COLOR ? s : (A[c] ?? '') + s + A.r;
const cc = (...ps) => NO_COLOR ? ps.map(([,s]) => s).join('') : ps.map(([c,s]) => (A[c] ?? '') + s).join('') + A.r;

// ─────────────────────────────────────────────────────────────────
//  СИНТАКСИЧЕСКАЯ ПОДСВЕТКА (для терминала)
// ─────────────────────────────────────────────────────────────────
const KW_SET = new Set(['swx','sx','wx','sw','dr','xs','xw','ws','in']);
const KW_SFX = ['swx!','sx>','sw&','sw|','sw!','x?','x!','x.','s>','w>'];
const BI_SET = new Set([
  'str','num','int','bool','type','is_num','is_str','is_arr','is_null','parse','json','print',
  'floor','ceil','round','abs','sqrt','pow','log','sin','cos','tan','max','min','clamp','rand','randf','even','odd',
  'len','upper','lower','trim','split','join','replace','includes','starts','ends','slice','repeat','pad','padr','chars','lines','words','format','count',
  'push','pop','shift','unshift','reverse','sort','flat','unique','contains','first','last','nth','range','chunk','zip','flatten',
  'keys','values','entries','has_key','merge','del_key','assert',
]);

function hlLine(line) {
  if (NO_COLOR) return line;
  // комментарий
  const ci1 = line.indexOf('swx#'), ci2 = line.indexOf('//');
  const ci = [ci1,ci2].filter(x=>x>=0);
  if (ci.length) {
    const m = Math.min(...ci);
    return hlLine(line.slice(0, m)) + A.BLACK + line.slice(m) + A.r;
  }
  let out = '', i = 0;
  while (i < line.length) {
    const ch = line[i];
    if (ch==='"'||ch==="'"||ch==='`') {
      let s=ch,q=ch; i++;
      while(i<line.length&&line[i]!==q){if(line[i]==='\\')s+=line[i++];s+=line[i++]||'';}
      s+=line[i++]||''; out+=A.red+s+A.r; continue;
    }
    if (ch==='#') {
      let ns='#'; i++;
      while(i<line.length&&/[a-zA-Z0-9]/.test(line[i]))ns+=line[i++];
      out+=A.MAG+ns+A.r; continue;
    }
    if (/[0-9]/.test(ch)) {
      let n=''; while(i<line.length&&/[0-9._xXbB]/.test(line[i]))n+=line[i++];
      out+=A.YELLOW+n+A.r; continue;
    }
    if (/[a-zA-Z_$]/.test(ch)) {
      let w=''; while(i<line.length&&/[a-zA-Z0-9_$-]/.test(line[i]))w+=line[i++];
      const sfx = KW_SFX.find(k => (w+line[i]).startsWith(k));
      if (sfx) { out+=A.MAG+sfx+A.r; i+=sfx.length-w.length; continue; }
      if (KW_SET.has(w)) out+=A.MAG+w+A.r;
      else if (BI_SET.has(w)) out+=A.CYAN+w+A.r;
      else out+=A.WHITE+w+A.r;
      continue;
    }
    if ('><=!~*+'.includes(ch)) { out+=A.CYAN+ch+A.r; i++; continue; }
    if ('(){}[]'.includes(ch))  { out+=A.BLACK+ch+A.r; i++; continue; }
    out+=ch; i++;
  }
  return out;
}

function colorOut(line) {
  const s = String(line);
  if (/^\[SWX|^\[Lex|^\[Parse/.test(s)) return p('RED', s);
  if (/^\[render\]/.test(s))             return p('CYAN', s);
  if (/^\[ok\]/.test(s))                 return p('GREEN', s);
  if (/^\[warn\]/.test(s))               return p('YELLOW', s);
  if (/^─{3,}|^═{3,}|^━{3,}/.test(s))  return p('BLACK', s);
  return p('WHITE', s);
}

// ─────────────────────────────────────────────────────────────────
//  BANNER
// ─────────────────────────────────────────────────────────────────
const BANNER = () => `
${cc(['CYAN',  '   ██████╗ ███████╗ ██████╗███████╗███████╗ ██████╗ '])}
${cc(['CYAN',  '   ██╔══██╗██╔════╝██╔════╝██╔════╝██╔════╝██╔════╝ '])}
${cc(['cyan',  '   ██║  ██║█████╗  ██║     ███████╗█████╗  ██║      '])}
${cc(['BLACK', '   ██║  ██║██╔══╝  ██║     ╚════██║██╔══╝  ██║      '])}
${cc(['BLACK', '   ██████╔╝███████╗╚██████╗███████║███████╗╚██████╗ '])}
${cc(['BLACK', '   ╚═════╝ ╚══════╝ ╚═════╝╚══════╝╚══════╝ ╚═════╝ '])}
${p('BLACK', '   ' + '─'.repeat(52))}
   ${p('BLACK','▸')} ${p('CYAN','SWX')} ${p('BLACK','v'+VERSION+'  ·  Shadow Web eXploit Language')}
   ${p('BLACK','▸')} ${p('BLACK','Node '+process.version+'  ·  '+process.platform+'  ·  '+os.arch())}
   ${p('BLACK','▸')} ${p('BLACK','Введи')} ${p('CYAN',':help')} ${p('BLACK','для справки  ·  Ctrl+C для выхода')}
${p('BLACK', '   ' + '─'.repeat(52))}
`;

// ─────────────────────────────────────────────────────────────────
//  HELP
// ─────────────────────────────────────────────────────────────────
const HELP = () => `
${p('CYAN','━━━ SWX v'+VERSION+' — ПОЛНЫЙ СПРАВОЧНИК ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')}

${p('YELLOW','ПЕРЕМЕННЫЕ')}
  swx x = 42                число          swx s = "текст {x}"    строка с интерполяцией
  swx a = [1, 2, 3]         массив         swx o = { k: "v" }     объект
  x = 10                    переприсвоение
  x ~= 5   x -= 2   x *~ 3   x /~ 4       составное присвоение

${p('YELLOW','ВЫВОД')}
  wx "Hello {name}"   — вывести строку (с интерполяцией переменных)

${p('YELLOW','УСЛОВИЯ')}
  sw x >~ 18 {              если x >= 18
      wx "взрослый"
  } dr sw x >~ 13 {         иначе если x >= 13
      wx "подросток"
  } dr {                    иначе
      wx "ребёнок"
  }
  sw a =? b sw& c !? d { }       sw& = И   sw| = ИЛИ   sw! = НЕ

${p('YELLOW','ЦИКЛЫ')}
  xs 10 { wx _i }                    — повторить N раз (_i = индекс, _n = кол-во)
  xw item in arr { wx item }         — перебрать массив (_i = индекс)
  xw pair in obj { wx pair.key }     — перебрать объект

${p('YELLOW','ФУНКЦИИ')}
  sx greet(name, times=1) => {       — объявление (times=1 = дефолт)
      xs times { wx "Привет {name}" }
      ws "готово"                    — возврат значения
  }
  swx r = greet("ghost", 3)          — вызов

${p('YELLOW','ОШИБКИ')}
  x? { опасный() } x!(e) { wx e } x. { wx "done" }
  swx! "моя ошибка"                  — бросить ошибку

${p('YELLOW','ИМПОРТ / ЭКСПОРТ')}
  s> "stdlib"        — загрузить stdlib/stdlib.swx
  s> "./mymodule"    — относительный путь
  w> myFunc          — экспортировать функцию

${p('YELLOW','ВЕБ  (sx> = render)')}
  sx> "out.html" {
      @style {
          body   >> bg(#030810) color(#fff) font(Courier New, monospace) pad(24px)
          .card  >> bg(#0c1420) pad(20px) radius(8px) border(1px solid #0d3050)
          h1     >> color(#00e5ff) size(24px) bold uppercase
          .btn   >> bg(#00e5ff) color(#000) pad(10px 20px) pointer radius(4px)
          .grid  >> grid cols(1fr 1fr) gap(16px)
          .flex  >> flex align(center) gap(12px)
          // Флаги (без скобок): bold italic flex grid center pointer rounded uppercase
      }
      @body {
          div.card >> {
              h1 >> "Заголовок {var}"
              p  >> "Параграф"
              button.btn >> (onclick: "alert('SWX')") { "Нажми" }
          }
      }
      @script {
          wx "Скрипт выполнен после рендера"
      }
  }

${p('YELLOW','ПРОСТРАНСТВА ИМЁН')}
  #x.sha256(s)          SHA-256 хэш        #x.sha512(s)       SHA-512
  #x.sha3(s)            SHA3-256           #x.md5(s)          MD5
  #x.hmac(key, msg)     HMAC-SHA256        #x.ripemd160(s)    RIPEMD-160
  #x.aes_enc(text, key) AES-256-CBC шифр   #x.aes_dec(c, key) расшифровать
  #x.rsa_keys([bits])   RSA-2048 ключи     #x.rsa_sign(d, prv) подпись
  #x.rsa_verify(d, s, pub)                  проверить подпись
  #x.hex(s)     #x.unhex(h)               HEX кодирование
  #x.base64(s)  #x.unbase64(b)            Base64
  #x.xor(msg, key)   #x.caesar(s,n)  #x.rot13(s)  #x.vigenere(t, key)
  #x.genkey([n])     — случайный ключ       #x.uuid()          UUID v4
  #x.entropy(s)      — энтропия Шеннона     #x.crc32(s)        CRC32
  #x.pwd_strength(p) — сила пароля          #x.geniv()         случайный IV
  #x.token_create(obj, key)  — JWT-токен    #x.token_verify(t, key)

  #f.read(path)      #f.write(path, data)   #f.append(path, data)
  #f.exists(path)    #f.list([dir])         #f.stat(path)
  #f.mkdir(path)     #f.delete(path)        #f.rename(a, b)
  #f.json_read(path) #f.json_write(path, obj)

  #s.time()  #s.date()  #s.datetime()  #s.timestamp()
  #s.platform()  #s.arch()  #s.pid()  #s.cwd()
  #s.env(key)  #s.env_set(k,v)  #s.args()  #s.exit([code])
  #s.hostname()  #s.user()  #s.homedir()

  #n.get(url)  #n.post(url, data)  #n.ping(host)
  #ai.prompt(text)  #ai.analyze(data)  #ai.grade(code)

${p('YELLOW','ОПЕРАТОРЫ')}
  Сравнение:  =? (==)   !? (!=)   <   >   <~ (<=)   >~ (>=)
  Логика:     sw& (&&)   sw| (||)   sw! (!)
  Составное:  ~= (+=)   -= (-=)   *~ (*=)   /~ (/=)
  Степень:    **

${p('CYAN','━━━ КОМАНДЫ REPL ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')}
  :help            справочник          :version        версия
  :run  <файл>     запустить файл      :load <файл>    загрузить в контекст
  :watch <файл>    следить + перезапуск :new  <файл>    создать файл
  :edit <файл>     показать файл       :save <имя>     сохранить сессию в файл
  :clear           очистить экран      :reset          сбросить интерпретатор
  :vars            переменные          :fns            функции
  :ls [dir]        список файлов       :pwd            текущая папка
  :cd <dir>        сменить папку       :type <expr>    тип выражения
  :ast  <код>      AST дерево          :tokens <код>   токены лексера
  :time <код>      время выполнения    :bench N <код>  N итераций avg/min/max
  :history [n]     история команд      :hist-clear     очистить историю
  :session save    сохранить сессию    :session load   восстановить сессию
${p('CYAN','━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')}
`;

// ─────────────────────────────────────────────────────────────────
//  УТИЛИТЫ
// ─────────────────────────────────────────────────────────────────
const dur = ns => {
  if (ns < 1000n)         return `${ns}ns`;
  if (ns < 1_000_000n)    return `${Number(ns/1000n)}µs`;
  if (ns < 1_000_000_000n)return `${(Number(ns)/1e6).toFixed(2)}ms`;
  return `${(Number(ns)/1e9).toFixed(3)}s`;
};
const szFmt = b => b < 1024 ? `${b}B` : b < 1048576 ? `${(b/1024).toFixed(1)}KB` : `${(b/1048576).toFixed(1)}MB`;

function resolveSWX(cwd, name) {
  return [
    path.resolve(cwd, name),
    path.resolve(cwd, name + '.swx'),
    path.resolve(cwd, 'stdlib', name + '.swx'),
    path.resolve(__dirname, 'stdlib', name + '.swx'),
  ].find(x => fs.existsSync(x)) ?? null;
}

function table(rows, headers, out) {
  const vis = s => String(s ?? '').replace(/\x1b\[[0-9;]*m/g, '');
  const w = headers.map((h, i) => Math.max(h.length, ...rows.map(r => vis(r[i]).length)));
  const bar = (l,m,r) => l + w.map(n => '─'.repeat(n+2)).join(m) + r;
  out(p('BLACK', '  ' + bar('┌','┬','┐')));
  out('  │' + headers.map((h,i) => ' ' + p('YELLOW', h.padEnd(w[i])) + ' ').join('│') + p('BLACK','│'));
  out(p('BLACK', '  ' + bar('├','┼','┤')));
  rows.forEach(row => {
    out('  │' + row.map((cell, i) => {
      const s=String(cell??''), vl=vis(cell).length;
      return ' ' + s + ' '.repeat(Math.max(0, w[i]-vl)) + ' ';
    }).join(p('BLACK','│')) + p('BLACK','│'));
  });
  out(p('BLACK', '  ' + bar('└','┴','┘')));
}

// ─────────────────────────────────────────────────────────────────
//  REPL
// ─────────────────────────────────────────────────────────────────
class REPL {
  constructor() {
    this.cwd     = process.cwd();
    this.interp  = this._mk();
    this.buf     = [];
    this.depth   = 0;
    this.rl      = null;
    this.sess    = [];
    this.watcher = null;
  }

  _mk() {
    return new Interpreter({ cwd:this.cwd, output:l => this._out(colorOut(l)) });
  }

  _out(s)  { process.stdout.write(s + '\n'); }
  _err(s)  { process.stdout.write(p('RED',   '  ✗ ' + s) + '\n'); }
  _ok(s)   { process.stdout.write(p('GREEN', '  ✓ ' + s) + '\n'); }
  _info(s) { process.stdout.write(p('BLACK', '  · ' + s) + '\n'); }

  _prompt() {
    if (this.depth > 0)
      return cc(['BLACK', '  ' + '·'.repeat(Math.min(this.depth, 5)) + ' ']);
    const base = path.basename(this.cwd);
    return cc(
      ['BLACK',' ╭─['], ['CYAN','swx'], ['BLACK',':'],
      ['GREEN', base.length > 22 ? '…' + base.slice(-21) : base],
      ['BLACK',']'], this.watcher ? ['YELLOW','⟳'] : ['BLACK',''],
      ['YELLOW','\n ╰─⟩ ']
    );
  }

  _loadHistory() {
    try {
      if (fs.existsSync(HIST_FILE))
        return fs.readFileSync(HIST_FILE, 'utf8').split('\n').filter(Boolean).slice(-500).reverse();
    } catch {}
    return [];
  }

  _saveHistory() {
    try { fs.writeFileSync(HIST_FILE, (this.rl?.history ?? []).slice(0, 500).reverse().join('\n'), 'utf8'); }
    catch {}
  }

  _loadRC() {
    for (const rc of [RC_FILE, path.join(this.cwd, '.swxrc')]) {
      if (fs.existsSync(rc)) {
        try { this.interp.exec(fs.readFileSync(rc, 'utf8')); this._info('Загружен ' + rc); }
        catch (e) { this._err('.swxrc: ' + e.message); }
      }
    }
  }

  _sessionSave() {
    const SESSION = path.join(HOME, '.swx_session.json');
    try {
      const skip = new Set(['true','false','null','PI','E','PHI','TAU','VERSION','LANG','Infinity','NaN']);
      const vars = {};
      for (const [k,v] of Object.entries(this.interp.globals.v)) {
        if (skip.has(k) || typeof v === 'function') continue;
        try { JSON.stringify(v); vars[k] = v; } catch {}
      }
      const fnSrc = {};
      for (const [n,fn] of Object.entries(this.interp.fns))
        fnSrc[n] = { params:fn.params, body:fn.body };
      fs.writeFileSync(SESSION, JSON.stringify({ vars, fnSrc, ts:Date.now() }, null, 2), 'utf8');
      this._ok('Сессия сохранена → ' + SESSION);
    } catch (e) { this._err('Сохранение сессии: ' + e.message); }
  }

  _sessionLoad() {
    const SESSION = path.join(HOME, '.swx_session.json');
    try {
      if (!fs.existsSync(SESSION)) { this._err('Нет сохранённой сессии'); return; }
      const d = JSON.parse(fs.readFileSync(SESSION, 'utf8'));
      for (const [k,v] of Object.entries(d.vars || {})) this.interp.globals.set(k, v);
      for (const [n,fn] of Object.entries(d.fnSrc || {}))
        this.interp.fns[n] = { params:fn.params, body:fn.body, closure:this.interp.globals };
      const age = Math.round((Date.now() - (d.ts || 0)) / 60000);
      this._ok(`Сессия загружена (${age}м назад) · ${Object.keys(d.vars||{}).length} переменных · ${Object.keys(d.fnSrc||{}).length} функций`);
    } catch (e) { this._err('Загрузка сессии: ' + e.message); }
  }

  _watch(file) {
    const fp = resolveSWX(this.cwd, file);
    if (!fp) { this._err('Файл не найден: ' + file); return; }
    this.watcher?.close();
    const run = () => {
      process.stdout.write('\n');
      this._info(`[watch] ${path.basename(fp)} изменён — перезапуск...`);
      const t0 = process.hrtime.bigint();
      const wi = this._mk();
      try { wi.exec(fs.readFileSync(fp, 'utf8'), null, fp); }
      catch (e) { this._err(e.message); }
      this._info(`Готово за ${dur(process.hrtime.bigint() - t0)}`);
      this.rl?.setPrompt(this._prompt());
      this.rl?.prompt();
    };
    run();
    let deb;
    this.watcher = fs.watch(fp, () => { clearTimeout(deb); deb = setTimeout(run, 120); });
    this._ok('Слежение: ' + fp + '  (Ctrl+C для остановки)');
  }

  // ── Команды REPL ─────────────────────────────────────────
  _cmd(line) {
    const [cmd, ...rest] = line.trim().slice(1).split(/\s+/);
    const arg = rest.join(' ');

    switch (cmd) {
      case 'help': case '?':
        process.stdout.write(HELP()); break;

      case 'version': case 'v':
        this._out(cc(['CYAN','  SWX '],['WHITE','v'+VERSION],['BLACK',' · Node '+process.version+' · '+process.platform])); break;

      case 'clear': case 'cls':
        process.stdout.write('\x1b[2J\x1b[H'); break;

      case 'reset':
        this.watcher?.close(); this.watcher = null;
        this.interp = this._mk(); this.sess = [];
        this._ok('Интерпретатор сброшен'); break;

      case 'run': case 'r': {
        if (!arg) { this._err('Использование: :run <файл.swx>'); break; }
        const fp = resolveSWX(this.cwd, arg);
        if (!fp) { this._err('Файл не найден: ' + arg); break; }
        this._info('Запуск ' + p('CYAN', path.basename(fp)) + '...');
        const t0 = process.hrtime.bigint();
        try { this._mk().exec(fs.readFileSync(fp, 'utf8'), null, fp); }
        catch (e) { this._err(e.message); }
        this._info('Готово за ' + dur(process.hrtime.bigint() - t0));
        break;
      }

      case 'load': case 'l': {
        if (!arg) { this._err('Использование: :load <файл.swx>'); break; }
        const fp = resolveSWX(this.cwd, arg);
        if (!fp) { this._err('Файл не найден: ' + arg); break; }
        try {
          this.interp.exec(fs.readFileSync(fp, 'utf8'), null, fp);
          this._ok('Загружено: ' + path.basename(fp));
        } catch (e) { this._err(e.message); }
        break;
      }

      case 'watch': case 'w':
        if (!arg) {
          if (this.watcher) { this.watcher.close(); this.watcher = null; this._ok('Слежение остановлено'); }
          else this._err('Использование: :watch <файл.swx>');
        } else this._watch(arg);
        break;

      case 'new': {
        if (!arg) { this._err('Использование: :new <имя>'); break; }
        const fn = arg.endsWith('.swx') ? arg : arg + '.swx';
        const fp = path.resolve(this.cwd, fn);
        if (fs.existsSync(fp)) { this._err('Файл уже существует: ' + fp); break; }
        fs.writeFileSync(fp, `swx# ${fn}\nswx# Создан: ${new Date().toISOString()}\n\n`, 'utf8');
        this._ok('Создан: ' + fp); break;
      }

      case 'edit': case 'cat': {
        if (!arg) { this._err('Использование: :edit <файл.swx>'); break; }
        const fp = resolveSWX(this.cwd, arg);
        if (!fp) { this._err('Файл не найден: ' + arg); break; }
        const src = fs.readFileSync(fp, 'utf8');
        const ls  = src.split('\n');
        this._out(p('BLACK', `  ── ${path.basename(fp)} (${ls.length} строк, ${szFmt(Buffer.byteLength(src))}) ──`));
        ls.forEach((ln, i) => process.stdout.write(p('BLACK', String(i+1).padStart(4) + ' │ ') + hlLine(ln) + '\n'));
        break;
      }

      case 'save': {
        if (!arg) { this._err('Использование: :save <имя>'); break; }
        const fn = arg.endsWith('.swx') ? arg : arg + '.swx';
        const content = `swx# Сессия REPL — ${new Date().toISOString()}\n\n${this.sess.join('\n')}\n`;
        fs.writeFileSync(path.resolve(this.cwd, fn), content, 'utf8');
        this._ok(`Сохранено ${this.sess.length} строк → ${fn}`); break;
      }

      case 'session': {
        if (rest[0] === 'save') this._sessionSave();
        else if (rest[0] === 'load') this._sessionLoad();
        else this._err('Использование: :session save | :session load');
        break;
      }

      case 'ls': {
        const dir = arg ? path.resolve(this.cwd, arg) : this.cwd;
        try {
          const items = fs.readdirSync(dir);
          if (!items.length) { this._info('(пусто)'); break; }
          const rows = items.map(item => {
            const full = path.join(dir, item);
            const stat = fs.statSync(full);
            const isD  = stat.isDirectory();
            return [
              p(isD ? 'CYAN' : item.endsWith('.swx') ? 'GREEN' : 'WHITE', item + (isD?'/':'')),
              isD ? p('BLACK','dir') : szFmt(stat.size),
              p('BLACK', new Date(stat.mtimeMs).toLocaleString('ru-RU')),
            ];
          });
          table(rows, ['ИМЯ','РАЗМЕР','ИЗМЕНЁН'], s => this._out(s));
        } catch (e) { this._err(e.message); }
        break;
      }

      case 'pwd':
        this._out(cc(['BLACK','  '],['cyan', this.cwd])); break;

      case 'cd': {
        const target = arg || HOME;
        const nd = target.startsWith('~') ? path.join(HOME, target.slice(1)) : path.resolve(this.cwd, target);
        if (!fs.existsSync(nd)) { this._err('Не найдено: ' + nd); break; }
        this.cwd = nd; this.interp.cwd = nd;
        this.rl?.setPrompt(this._prompt());
        this._info('→ ' + nd); break;
      }

      case 'vars': {
        const skip = new Set(['true','false','null','PI','E','PHI','TAU','VERSION','LANG','Infinity','NaN']);
        const entries = Object.entries(this.interp.globals.v)
          .filter(([k]) => !skip.has(k))
          .sort(([a],[b]) => a.localeCompare(b));
        if (!entries.length) { this._info('(нет переменных)'); break; }
        const rows = entries.map(([k,v]) => {
          const t = Array.isArray(v) ? `array[${v.length}]` : v===null ? 'null' : typeof v;
          const s = this.interp.fmt(v);
          return [p('CYAN',k), p('BLACK',t), p('WHITE', s.length>55 ? s.slice(0,52)+'…' : s)];
        });
        table(rows, ['ПЕРЕМЕННАЯ','ТИП','ЗНАЧЕНИЕ'], s => this._out(s));
        break;
      }

      case 'fns': case 'functions': {
        const fns = Object.entries(this.interp.fns || {}).sort(([a],[b]) => a.localeCompare(b));
        if (!fns.length) { this._info('(нет функций)'); break; }
        const rows = fns.map(([n,fn]) => [
          p('CYAN',n),
          p('BLACK','(' + (fn.params||[]).join(', ') + ')'),
          p('BLACK',(fn.body||[]).length + ' инструкций'),
        ]);
        table(rows, ['ФУНКЦИЯ','ПАРАМЕТРЫ','ТЕЛО'], s => this._out(s));
        break;
      }

      case 'type': {
        if (!arg) { this._err('Использование: :type <выражение>'); break; }
        try {
          const { tokenize } = require('./src/lexer');
          const { Parser }   = require('./src/parser');
          const ast = new Parser(tokenize(arg)).parseProgram();
          const v = this.interp.eval(ast.stmts[0]?.expr ?? ast.stmts[0], this.interp.globals);
          const t = Array.isArray(v) ? `array[${v.length}]` : v===null ? 'null' : typeof v;
          this._out(cc(['BLACK','  '],['WHITE',this.interp.fmt(v)],['BLACK',' : '],['CYAN',t]));
        } catch (e) { this._err(e.message); }
        break;
      }

      case 'ast': {
        if (!arg) { this._err('Использование: :ast <код>'); break; }
        try {
          const { tokenize } = require('./src/lexer');
          const { Parser }   = require('./src/parser');
          this._out(p('BLACK', JSON.stringify(new Parser(tokenize(arg)).parseProgram(), null, 2)));
        } catch (e) { this._err(e.message); }
        break;
      }

      case 'tokens': {
        if (!arg) { this._err('Использование: :tokens <код>'); break; }
        try {
          const { tokenize } = require('./src/lexer');
          const toks = tokenize(arg);
          const rows = toks.map(t => [
            p('BLACK',`${t.line}:${t.col}`), p('CYAN',t.type), p('WHITE',t.value!=null?String(t.value):''),
          ]);
          table(rows, ['ПОЗ','ТИП','ЗНАЧЕНИЕ'], s => this._out(s));
        } catch (e) { this._err(e.message); }
        break;
      }

      case 'time': {
        if (!arg) { this._err('Использование: :time <код>'); break; }
        const t0 = process.hrtime.bigint();
        try { this.interp.exec(arg); } catch (e) { this._err(e.message); }
        this._out(cc(['BLACK','  ⏱  '],['CYAN', dur(process.hrtime.bigint() - t0)]));
        break;
      }

      case 'bench': {
        const N    = parseInt(rest[0]) || 100;
        const code = rest.slice(1).join(' ');
        if (!code) { this._err('Использование: :bench N <код>'); break; }
        const times = [];
        for (let k = 0; k < N; k++) {
          const t0 = process.hrtime.bigint();
          try { this.interp.exec(code); } catch (e) { this._err(e.message); break; }
          times.push(Number(process.hrtime.bigint() - t0));
        }
        if (times.length) {
          const avg = times.reduce((a,b) => a+b, 0) / times.length;
          this._out(cc(['BLACK','  runs: '],['WHITE',String(times.length)]));
          this._out(cc(['BLACK','  avg:  '],['CYAN',  dur(BigInt(Math.round(avg)))]));
          this._out(cc(['BLACK','  min:  '],['GREEN', dur(BigInt(Math.min(...times)))]));
          this._out(cc(['BLACK','  max:  '],['YELLOW',dur(BigInt(Math.max(...times)))]));
        }
        break;
      }

      case 'history': case 'hist': {
        const n    = parseInt(arg) || 20;
        const hist = (this.rl?.history ?? []).slice(0, n).reverse();
        if (!hist.length) { this._info('(нет истории)'); break; }
        hist.forEach((ln, i) => this._out(cc(['BLACK',`  ${String(i+1).padStart(4)} `],['WHITE',ln])));
        break;
      }

      case 'hist-clear':
        if (this.rl) this.rl.history = [];
        try { fs.unlinkSync(HIST_FILE); } catch {}
        this._ok('История очищена'); break;

      default:
        this._err(`Неизвестная команда ':${cmd}'. Введи :help`);
    }
  }

  // ── Выполнить строку (поддержка multiline) ────────────────
  _execLine(line) {
    let inStr=false, strCh='', opens=0, closes=0;
    for (let i=0; i<line.length; i++) {
      const ch=line[i];
      if (!inStr&&(ch==='"'||ch==="'"||ch==='`')) { inStr=true; strCh=ch; continue; }
      if (inStr&&ch===strCh&&line[i-1]!=='\\') { inStr=false; continue; }
      if (!inStr) { if(ch==='{')opens++; if(ch==='}')closes++; }
    }
    this.buf.push(line); this.depth += opens - closes;
    if (line.trim()) this.sess.push(line);
    if (this.depth <= 0 && this.buf.length > 0) {
      const src = this.buf.join('\n'); this.buf = []; this.depth = 0;
      try { this.interp.exec(src); }
      catch (e) { this._err(e.isSwx ? e.message : '[ERR] ' + e.message); }
    }
  }

  // ── Автодополнение ────────────────────────────────────────
  _complete(line) {
    const cmds = [
      ':help',':version',':run ',':load ',':watch ',':new ',':edit ',':save ',
      ':session save',':session load',':clear',':reset',
      ':vars',':fns',':ls',':pwd',':cd ',
      ':type ',':ast ',':tokens ',':time ',':bench ',
      ':history',':hist-clear',
    ];
    const kw  = ['swx ','sx ','wx ','sw ','dr','xs ','xw ','ws ','s> ','w> ','sx> ','x?','x!','x.','swx!'];
    const ns  = ['#x.','#f.','#s.','#n.','#ai.'];
    const fns = Object.keys(this.interp.fns || {});
    const vars = Object.keys(this.interp.globals.v || {});
    const all  = [...cmds, ...kw, ...ns, ...fns, ...vars];
    const hits = all.filter(c => c.startsWith(line));
    return [hits.length ? hits : all, line];
  }

  // ── Старт ─────────────────────────────────────────────────
  start() {
    process.stdout.write(BANNER());
    this._loadRC();

    this.rl = readline.createInterface({
      input:       process.stdin,
      output:      process.stdout,
      prompt:      this._prompt(),
      completer:   l => this._complete(l),
      historySize: 1000,
    });
    this.rl.history = this._loadHistory();
    this.rl.prompt();

    this.rl.on('line', raw => {
      const trimmed = raw.trim();
      if (this.depth === 0 && trimmed.startsWith(':')) {
        this._cmd(trimmed);
        this.rl.setPrompt(this._prompt());
        this.rl.prompt();
        return;
      }
      if (!trimmed && this.depth === 0) { this.rl.prompt(); return; }
      this._execLine(raw);
      this.rl.setPrompt(this._prompt());
      this.rl.prompt();
    });

    this.rl.on('close', () => {
      this._saveHistory();
      this.watcher?.close();
      process.stdout.write('\n' + p('BLACK', '  decSec out — stay ghosted.\n'));
      process.exit(0);
    });

    process.on('SIGINT', () => {
      if (this.depth > 0 || this.buf.length > 0) {
        this.buf = []; this.depth = 0;
        process.stdout.write(p('BLACK','\n  (блок отменён)\n'));
      } else if (this.watcher) {
        this.watcher.close(); this.watcher = null;
        process.stdout.write(p('BLACK','\n  (слежение остановлено)\n'));
      } else {
        this._saveHistory(); this.watcher?.close();
        process.stdout.write('\n' + p('BLACK','  decSec out — stay ghosted.\n'));
        process.exit(0);
      }
      this.rl.setPrompt(this._prompt());
      this.rl.prompt();
    });
  }
}

// ─────────────────────────────────────────────────────────────────
//  ТОЧКА ВХОДА
// ─────────────────────────────────────────────────────────────────
const argv  = process.argv.slice(2);
const flags = new Set(argv.filter(a => a.startsWith('-')));
const args  = argv.filter(a => !a.startsWith('-'));

if (flags.has('--version')||flags.has('-v')) { console.log('decSec SWX v'+VERSION); process.exit(0); }
if (flags.has('--help')||flags.has('-h'))    { console.log(HELP()); process.exit(0); }
if (flags.has('--no-color')) NO_COLOR = true;

// Inline eval: node decsec -e "wx 'hello'"
if (flags.has('-e') || flags.has('--eval')) {
  const idx = argv.findIndex(a => a==='-e'||a==='--eval');
  const src = argv.slice(idx+1).join(' ');
  if (!src) { process.stderr.write('Ошибка: -e требует код\n'); process.exit(1); }
  const i = new Interpreter({ output: l => process.stdout.write(String(l)+'\n') });
  try { i.exec(src); } catch (e) { process.stderr.write(e.message+'\n'); process.exit(1); }
  process.exit(0);
}

// Watch mode: node decsec -w file.swx
if (flags.has('-w') || flags.has('--watch')) {
  const file = args[0];
  if (!file) { process.stderr.write('Ошибка: -w требует файл\n'); process.exit(1); }
  const fp = path.resolve(process.cwd(), file.endsWith('.swx') ? file : file+'.swx');
  if (!fs.existsSync(fp)) { process.stderr.write('Файл не найден: '+fp+'\n'); process.exit(1); }
  process.stdout.write(BANNER());
  const run = () => {
    process.stdout.write('\n' + p('BLACK','  ⟳ '+path.basename(fp)+'\n'));
    const t0 = process.hrtime.bigint();
    const i = new Interpreter({ cwd:path.dirname(fp), output:l => process.stdout.write(colorOut(String(l))+'\n') });
    try { i.exec(fs.readFileSync(fp,'utf8'), null, fp); }
    catch (e) { process.stderr.write(p('RED', e.message)+'\n'); }
    process.stdout.write(p('BLACK','  Готово за '+dur(process.hrtime.bigint()-t0)+'\n'));
  };
  run();
  let deb;
  fs.watch(fp, () => { clearTimeout(deb); deb = setTimeout(run, 120); });
  process.stdout.write(p('CYAN','  Слежение: '+fp+'  (Ctrl+C)\n'));
  process.on('SIGINT', () => { process.stdout.write('\n'); process.exit(0); });
  return;
}

// Запуск файла: node decsec script.swx
if (args[0]) {
  const fp = path.resolve(process.cwd(), args[0].endsWith('.swx') ? args[0] : args[0]+'.swx');
  if (!fs.existsSync(fp)) { process.stderr.write(p('RED','Файл не найден: '+fp)+'\n'); process.exit(1); }
  const i = new Interpreter({ cwd:path.dirname(fp), output:l => process.stdout.write(String(l)+'\n') });
  try { i.exec(fs.readFileSync(fp,'utf8'), null, fp); }
  catch (e) { process.stderr.write(p('RED', e.message)+'\n'); process.exit(1); }
  process.exit(0);
}

// Интерактивный REPL
new REPL().start();
