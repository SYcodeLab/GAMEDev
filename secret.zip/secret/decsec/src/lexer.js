'use strict';
// ═══════════════════════════════════════════════════════════════════════
//  SWX LEXER  v7.0  —  Shadow Web eXploit Language
//  Автор: Slywerx  |  decSec Project  |  2025
// ═══════════════════════════════════════════════════════════════════════

const TT = {
  NUM:'NUM',STR:'STR',BOOL:'BOOL',NULL:'NULL',IDENT:'IDENT',HEXC:'HEXC',
  SWX:'SWX',SWXT:'SWXT',SX:'SX',SXR:'SXR',WX:'WX',
  SW:'SW',SWAND:'SWAND',SWOR:'SWOR',SWNOT:'SWNOT',DR:'DR',
  XS:'XS',XW:'XW',XL:'XL',WS:'WS',IN:'IN',
  MATCH:'MATCH',CASE:'CASE',DFLT:'DFLT',BREAK:'BREAK',NEXT:'NEXT',
  XTRY:'XTRY',XCAT:'XCAT',XFIN:'XFIN',SIMP:'SIMP',WEXP:'WEXP',
  AT:'AT',ARR:'ARR',NS:'NS',
  EQ:'EQ',NEQ:'NEQ',LT:'LT',GT:'GT',LTE:'LTE',GTE:'GTE',
  ASSIGN:'ASSIGN',PLEQ:'PLEQ',MIEQ:'MIEQ',MUEQ:'MUEQ',DIEQ:'DIEQ',
  PLUS:'PLUS',MINUS:'MINUS',STAR:'STAR',SLASH:'SLASH',MOD:'MOD',POW:'POW',
  LP:'LP',RP:'RP',LB:'LB',RB:'RB',LSQ:'LSQ',RSQ:'RSQ',
  COMMA:'COMMA',DOT:'DOT',COLON:'COLON',ARROW:'ARROW',PIPE:'PIPE',
  EOF:'EOF',
};

class Token{constructor(t,v,l,c){this.type=t;this.value=v;this.line=l;this.col=c;}}
class LexError extends Error{constructor(m,l,c){super(`[SWX Lex] ${l}:${c} — ${m}`);this.line=l;this.col=c;this.isSwx=true;}}

class Lexer{
  constructor(src){this.src=src;this.pos=0;this.line=1;this.col=1;}
  peek(o=0){return this.src[this.pos+o]??'';}
  next(){const c=this.src[this.pos++];if(c==='\n'){this.line++;this.col=1;}else this.col++;return c;}
  match(c){if(this.src[this.pos]===c){this.pos++;this.col++;return true;}return false;}

  skipWS(){
    while(this.pos<this.src.length){
      const c=this.peek();
      if(' \t\r\n'.includes(c)){this.next();continue;}
      if(c==='/'&&this.peek(1)==='*'){this.pos+=2;this.col+=2;while(this.pos<this.src.length-1){if(this.peek()==='*'&&this.peek(1)==='/'){this.pos+=2;break;}this.next();}continue;}
      if(c==='/'&&this.peek(1)==='/'){while(this.pos<this.src.length&&this.peek()!=='\n')this.pos++;continue;}
      break;
    }
  }

  readStr(q){
    const ln=this.line,co=this.col;let s='';
    while(this.pos<this.src.length&&this.peek()!==q){
      if(this.peek()==='\\'){this.next();const e=this.next();s+=({n:'\n',t:'\t',r:'\r','\\':'\\','"':'"',"'":"'",'`':'`'})[e]??e;}
      else s+=this.next();
    }
    if(this.pos>=this.src.length)throw new LexError('Незакрытая строка',ln,co);
    this.next();return s;
  }

  readNum(){
    let n='';
    if(this.peek()==='0'&&/[xX]/.test(this.peek(1))){n=this.next()+this.next();while(/[0-9a-fA-F_]/.test(this.peek())){const c=this.next();if(c!=='_')n+=c;}return parseInt(n,16);}
    if(this.peek()==='0'&&/[bB]/.test(this.peek(1))){n=this.next()+this.next();while(/[01_]/.test(this.peek())){const c=this.next();if(c!=='_')n+=c;}return parseInt(n,2);}
    while(this.pos<this.src.length&&/[0-9_.]/.test(this.peek())){const ch=this.next();if(ch!=='_')n+=ch;}
    if(/[eE]/.test(this.peek())){n+=this.next();if(/[+-]/.test(this.peek()))n+=this.next();while(/[0-9]/.test(this.peek()))n+=this.next();}
    return parseFloat(n);
  }

  readIdent(){
    let s='';
    while(this.pos<this.src.length&&/[a-zA-Z0-9_$]/.test(this.peek()))s+=this.next();
    return s;
  }

  tokenize(){
    const toks=[];
    while(true){
      this.skipWS();
      if(this.pos>=this.src.length){toks.push(new Token(TT.EOF,null,this.line,this.col));break;}
      const ln=this.line,co=this.col,c=this.next();

      if(c==='"'||c==="'"||c==='`'){toks.push(new Token(TT.STR,this.readStr(c),ln,co));continue;}
      if(/[0-9]/.test(c)){this.pos--;this.col--;toks.push(new Token(TT.NUM,this.readNum(),ln,co));continue;}
      if(/[a-zA-Z_$]/.test(c)){this.pos--;this.col--;const id=this.readIdent();const tok=this._kw(id,ln,co);if(tok!==null)toks.push(tok);continue;}

      if(c==='#'){
        if(/[0-9a-fA-F]/.test(this.peek())){let h='#';while(/[0-9a-fA-F]/.test(this.peek()))h+=this.next();toks.push(new Token(TT.HEXC,h,ln,co));}
        else if(/[a-zA-Z]/.test(this.peek())){let ns='';while(/[a-zA-Z]/.test(this.peek()))ns+=this.next();toks.push(new Token(TT.NS,ns,ln,co));}
        continue;
      }
      if(c==='@'){toks.push(new Token(TT.AT,'@',ln,co));continue;}
      if(c==='|'&&this.match('>')){toks.push(new Token(TT.PIPE,'|>',ln,co));continue;}
      if(c==='='){if(this.match('?'))toks.push(new Token(TT.EQ,'=?',ln,co));else if(this.match('>'))toks.push(new Token(TT.ARROW,'=>',ln,co));else toks.push(new Token(TT.ASSIGN,'=',ln,co));continue;}
      if(c==='!'){if(this.match('?'))toks.push(new Token(TT.NEQ,'!?',ln,co));else toks.push(new Token(TT.IDENT,'!',ln,co));continue;}
      if(c==='<'){if(this.match('~'))toks.push(new Token(TT.LTE,'<~',ln,co));else toks.push(new Token(TT.LT,'<',ln,co));continue;}
      if(c==='>'){if(this.match('>'))toks.push(new Token(TT.ARR,'>>',ln,co));else if(this.match('~'))toks.push(new Token(TT.GTE,'>~',ln,co));else toks.push(new Token(TT.GT,'>',ln,co));continue;}
      if(c==='~'){if(this.match('='))toks.push(new Token(TT.PLEQ,'~=',ln,co));else toks.push(new Token(TT.IDENT,'~',ln,co));continue;}
      if(c==='+')toks.push(new Token(TT.PLUS,'+',ln,co));
      else if(c==='-'){if(this.match('='))toks.push(new Token(TT.MIEQ,'-=',ln,co));else toks.push(new Token(TT.MINUS,'-',ln,co));}
      else if(c==='*'){if(this.match('*'))toks.push(new Token(TT.POW,'**',ln,co));else if(this.match('~'))toks.push(new Token(TT.MUEQ,'*~',ln,co));else toks.push(new Token(TT.STAR,'*',ln,co));}
      else if(c==='/'){if(this.match('~'))toks.push(new Token(TT.DIEQ,'/~',ln,co));else toks.push(new Token(TT.SLASH,'/',ln,co));}
      else if(c==='%')toks.push(new Token(TT.MOD,'%',ln,co));
      else if(c==='(')toks.push(new Token(TT.LP,'(',ln,co));
      else if(c===')')toks.push(new Token(TT.RP,')',ln,co));
      else if(c==='{')toks.push(new Token(TT.LB,'{',ln,co));
      else if(c==='}')toks.push(new Token(TT.RB,'}',ln,co));
      else if(c==='[')toks.push(new Token(TT.LSQ,'[',ln,co));
      else if(c===']')toks.push(new Token(TT.RSQ,']',ln,co));
      else if(c===',')toks.push(new Token(TT.COMMA,',',ln,co));
      else if(c==='.')toks.push(new Token(TT.DOT,'.',ln,co));
      else if(c===':')toks.push(new Token(TT.COLON,':',ln,co));
      else if(c===';'){}
      else throw new LexError(`Неизвестный символ '${c}' (0x${c.charCodeAt(0).toString(16)})`,ln,co);
    }
    return toks;
  }

  _kw(id,ln,co){
    if(id==='swx'&&this.peek()==='#'){while(this.pos<this.src.length&&this.peek()!=='\n')this.pos++;return null;}
    if(id==='swx'&&this.peek()==='!'){this.next();return new Token(TT.SWXT,'swx!',ln,co);}
    if(id==='swx') return new Token(TT.SWX,'swx',ln,co);
    if(id==='sx'&&this.peek()==='>'){this.next();return new Token(TT.SXR,'sx>',ln,co);}
    if(id==='sx')  return new Token(TT.SX,'sx',ln,co);
    if(id==='sw'&&this.peek()==='&'){this.next();return new Token(TT.SWAND,'sw&',ln,co);}
    if(id==='sw'&&this.peek()==='|'){this.next();return new Token(TT.SWOR,'sw|',ln,co);}
    if(id==='sw'&&this.peek()==='!'){this.next();return new Token(TT.SWNOT,'sw!',ln,co);}
    if(id==='sw')  return new Token(TT.SW,'sw',ln,co);
    if(id==='ws')  return new Token(TT.WS,'ws',ln,co);
    if(id==='wx')  return new Token(TT.WX,'wx',ln,co);
    if(id==='xw')  return new Token(TT.XW,'xw',ln,co);
    if(id==='xl')  return new Token(TT.XL,'xl',ln,co);
    if(id==='xs')  return new Token(TT.XS,'xs',ln,co);
    if(id==='dr')  return new Token(TT.DR,'dr',ln,co);
    if(id==='in')  return new Token(TT.IN,'in',ln,co);
    if(id==='x'&&this.peek()==='?'){this.next();return new Token(TT.XTRY,'x?',ln,co);}
    if(id==='x'&&this.peek()==='!'){this.next();return new Token(TT.XCAT,'x!',ln,co);}
    if(id==='x'&&this.peek()==='.'){this.next();return new Token(TT.XFIN,'x.',ln,co);}
    if(id==='s'&&this.peek()==='>'){this.next();return new Token(TT.SIMP,'s>',ln,co);}
    if(id==='w'&&this.peek()==='>'){this.next();return new Token(TT.WEXP,'w>',ln,co);}
    if(id==='match')   return new Token(TT.MATCH,'match',ln,co);
    if(id==='case')    return new Token(TT.CASE,'case',ln,co);
    if(id==='default') return new Token(TT.DFLT,'default',ln,co);
    if(id==='break')   return new Token(TT.BREAK,'break',ln,co);
    if(id==='next')    return new Token(TT.NEXT,'next',ln,co);
    if(id==='true')  return new Token(TT.BOOL,true,ln,co);
    if(id==='false') return new Token(TT.BOOL,false,ln,co);
    if(id==='null')  return new Token(TT.NULL,null,ln,co);
    return new Token(TT.IDENT,id,ln,co);
  }
}

function tokenize(src){return new Lexer(src).tokenize().filter(t=>t!==null);}
module.exports={Lexer,Token,TT,tokenize};
