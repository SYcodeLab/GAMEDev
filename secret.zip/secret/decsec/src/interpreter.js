'use strict';
// ═══════════════════════════════════════════════════════════════════════
//  SWX INTERPRETER  v7.0
//  Автор: Slywerx  |  decSec Project  |  2025
// ═══════════════════════════════════════════════════════════════════════
const path=require('path'),fs=require('fs'),C=require('./crypto');
const {tokenize}=require('./lexer');
const {Parser}=require('./parser');

class SwxError extends Error{constructor(m,l){super(m);this.line=l;this.isSwx=true;}}
class RetSig{constructor(v){this.value=v;}}
class BrkSig{}
class NxtSig{}

class Env{
  constructor(p=null){this.v=Object.create(null);this.parent=p;}
  get(n){if(n in this.v)return this.v[n];if(this.parent)return this.parent.get(n);throw new SwxError(`'${n}' не определена`,0);}
  set(n,v){this.v[n]=v;}
  assign(n,v){if(n in this.v){this.v[n]=v;return;}if(this.parent){this.parent.assign(n,v);return;}this.v[n]=v;}
  has(n){return n in this.v||(this.parent?.has(n)??false);}
}

// ── CSS shorthand → реальный CSS ──────────────────────────────
const CSS_MAP={
  bg:'background',color:'color',size:'font-size',pad:'padding',mar:'margin',
  border:'border',radius:'border-radius',font:'font-family',w:'width',h:'height',
  weight:'font-weight',shadow:'box-shadow',opacity:'opacity',display:'display',
  pos:'position',top:'top',left:'left',right:'right',bottom:'bottom',
  overflow:'overflow',cursor:'cursor',transition:'transition',transform:'transform',
  gap:'gap',align:'align-items',justify:'justify-content',wrap:'flex-wrap',
  dir:'flex-direction',cols:'grid-template-columns',rows:'grid-template-rows',
  z:'z-index',minw:'min-width',maxw:'max-width',mnh:'min-height',mxh:'max-height',
  lh:'line-height',ls:'letter-spacing',indent:'text-indent',outline:'outline',
  resize:'resize',select:'user-select',decoration:'text-decoration',
  visibility:'visibility',appearance:'appearance',
};
const CSS_FLAGS={
  bold:'font-weight: bold',italic:'font-style: italic',
  flex:'display: flex',grid:'display: grid',block:'display: block',
  inline:'display: inline',relative:'position: relative',absolute:'position: absolute',
  fixed:'position: fixed',sticky:'position: sticky',
  center:'text-align: center',underline:'text-decoration: underline',
  none:'text-decoration: none',nowrap:'white-space: nowrap',pre:'white-space: pre',
  pointer:'cursor: pointer',default:'cursor: default',hidden:'overflow: hidden',
  scroll:'overflow: scroll',auto:'overflow: auto',rounded:'border-radius: 8px',
  circle:'border-radius: 50%',uppercase:'text-transform: uppercase',
  lowercase:'text-transform: lowercase',capitalize:'text-transform: capitalize',
  'no-select':'user-select: none','border-box':'box-sizing: border-box',
};

function cssProp(prop,val){
  if(val===null)return CSS_FLAGS[prop]??(prop+': '+prop);
  return`${CSS_MAP[prop]??prop}: ${val}`;
}

class WebRenderer{
  buildCSS(rules){
    return rules.map(r=>{
      const props=r.props.map(p=>'  '+cssProp(p.prop,p.val)+';').join('\n');
      return`${r.sel} {\n${props}\n}`;
    }).join('\n');
  }
  buildHTML(nodes,interp,env){return nodes.map(n=>this._node(n,interp,env)).join('\n');}
  _node(n,interp,env){
    if(n.type==='HtmlExpr')return String(interp.eval(n.expr,env)??'');
    const{tag,cls,attrs={},children,content}=n;
    const clsA=cls?` class="${cls}"`:'';
    const attrA=Object.entries(attrs).map(([k,v])=>` ${k}="${String(interp.eval(v,env)??'').replace(/"/g,'&quot;')}"`).join('');
    const voids=new Set(['br','hr','img','input','meta','link','area','base','col','embed','param','source','track','wbr']);
    if(voids.has(tag))return`<${tag}${clsA}${attrA}>`;
    const inner=content!==null?this._interp(String(interp.eval(content,env)??''),interp,env):(children||[]).map(c=>this._node(c,interp,env)).join('\n');
    return`<${tag}${clsA}${attrA}>${inner}</${tag}>`;
  }
  _interp(s,interp,env){return s.replace(/\{([a-zA-Z_$][a-zA-Z0-9_$]*)\}/g,(_,n)=>{try{return interp.fmt(env.get(n));}catch{return`{${n}}`;}});}
  render(node,interp,env){
    const css=this.buildCSS(node.styleRules||[]);
    const html=this.buildHTML(node.bodyNodes||[],interp,env);
    if(node.scriptStmts?.length)interp.run(node.scriptStmts,env);
    const full=['<!DOCTYPE html>','<html lang="ru">','<head>',
      '  <meta charset="UTF-8">','  <meta name="viewport" content="width=device-width, initial-scale=1.0">',
      '  <title>decSec — SWX</title>','  <style>',
      css.split('\n').map(l=>'  '+l).join('\n'),'  </style>',
      '</head>','<body>',html,'</body>','</html>',].join('\n');
    return{full,css,html};
  }
}

class Interpreter{
  constructor(opts={}){
    this.opts=opts;
    this.output=opts.output||(s=>process.stdout.write(s+'\n'));
    this.cwd=opts.cwd||process.cwd();
    this.fns=Object.create(null);
    this.exports=Object.create(null);
    this.globals=this._buildGlobals();
    this.web=new WebRenderer();
  }

  _buildGlobals(){
    const e=new Env();
    e.set('PI',Math.PI);e.set('E',Math.E);e.set('PHI',1.6180339887);e.set('TAU',Math.PI*2);
    e.set('VERSION','7.0.0');e.set('LANG','SWX');
    e.set('true',true);e.set('false',false);e.set('null',null);
    e.set('Infinity',Infinity);e.set('NaN',NaN);
    return e;
  }

  _ns(ns,meth,args){
    switch(ns){
      case 'x': return this._nsX(meth,args);
      case 'f': return this._nsF(meth,args);
      case 's': return this._nsS(meth,args);
      case 'n': return this._nsN(meth,args);
      case 'ai':return this._nsAI(meth,args);
      default:  throw new SwxError(`Пространство '#${ns}' не существует`,0);
    }
  }

  _nsX(m,a){
    const M={
      sha256:([v])=>C.SHA256(v),sha512:([v])=>C.SHA512(v),sha1:([v])=>C.SHA1(v),
      md5:([v])=>C.MD5(v),sha3:([v])=>C.SHA3_256(v),ripemd160:([v])=>C.RIPEMD(v),
      hmac:([k,m,al])=>C.HMAC(al??'sha256',k,m),
      aes_enc:([t,k])=>C.aesEncrypt(t,k),aes_dec:([c,k])=>C.aesDecrypt(c,k),
      rsa_keys:([b])=>C.rsaGenKeys(b??2048),rsa_sign:([d,p])=>C.rsaSign(d,p),rsa_verify:([d,s,p])=>C.rsaVerify(d,s,p),
      hex:([v])=>C.HEX(v),unhex:([v])=>C.UNHEX(v),
      base64:([v])=>C.B64ENC(v),unbase64:([v])=>C.B64DEC(v),base64url:([v])=>C.B64URL(v),
      xor:([m,k])=>C.XOR(m,k),caesar:([s,n])=>C.CAESAR(s,n),rot13:([s])=>C.ROT13(s),vigenere:([t,k])=>C.VIGENERE(t,k),
      genkey:([n])=>C.GENKEY(n),geniv:()=>C.GENIV(),randbytes:([n])=>C.RANDOMBYTES(n),
      uuid:()=>C.UUID(),entropy:([s])=>C.ENTROPY(s),crc32:([s])=>C.CHECKSUM_CRC32(s),
      pwd_strength:([p])=>C.PASSWORD_STRENGTH(p),
      token_create:([p,s,e])=>C.createToken(p,s,e),token_verify:([t,s])=>C.verifyToken(t,s),
    };
    if(!(m in M))throw new SwxError(`#x.${m} не существует`,0);
    return M[m](a);
  }

  _nsF(m,a){
    const r=p=>path.resolve(this.cwd,String(p));
    const M={
      read:([p])=>{try{return fs.readFileSync(r(p),'utf8');}catch(e){return'[err: '+e.message+']';}},
      write:([p,d])=>{try{fs.writeFileSync(r(p),String(d??''),'utf8');return true;}catch{return false;}},
      append:([p,d])=>{try{fs.appendFileSync(r(p),String(d??''),'utf8');return true;}catch{return false;}},
      exists:([p])=>fs.existsSync(r(p)),
      list:([p])=>{try{return fs.readdirSync(r(p??'.'));}catch{return[];}},
      stat:([p])=>{try{const s=fs.statSync(r(p));return{size:s.size,isFile:s.isFile(),isDir:s.isDirectory(),mtime:s.mtimeMs};}catch{return null;}},
      mkdir:([p])=>{try{fs.mkdirSync(r(p),{recursive:true});return true;}catch{return false;}},
      delete:([p])=>{try{fs.unlinkSync(r(p));return true;}catch{return false;}},
      rename:([a,b])=>{try{fs.renameSync(r(a),r(b));return true;}catch{return false;}},
      copy:([a,b])=>{try{fs.copyFileSync(r(a),r(b));return true;}catch{return false;}},
      json_read:([p])=>{try{return JSON.parse(fs.readFileSync(r(p),'utf8'));}catch{return null;}},
      json_write:([p,d])=>{try{fs.writeFileSync(r(p),JSON.stringify(d,null,2),'utf8');return true;}catch{return false;}},
      size:([p])=>{try{return fs.statSync(r(p)).size;}catch{return 0;}},
    };
    if(!(m in M))throw new SwxError(`#f.${m} не существует`,0);
    return M[m](a);
  }

  _nsS(m,a){
    const M={
      time:()=>new Date().toLocaleTimeString('ru-RU'),
      date:()=>new Date().toLocaleDateString('ru-RU'),
      datetime:()=>new Date().toISOString(),
      timestamp:()=>Date.now(),
      platform:()=>process.platform,arch:()=>process.arch,
      pid:()=>process.pid,cwd:()=>process.cwd(),
      args:()=>process.argv.slice(2),
      env:([k])=>process.env[String(k)]??null,
      env_set:([k,v])=>{process.env[String(k)]=String(v??'');return null;},
      exit:([c])=>process.exit(Number(c??0)),
      mem:()=>{const m=process.memoryUsage();return{rss:m.rss,heap:m.heapUsed,total:m.heapTotal};},
      node:()=>process.version,
      sleep:([ms])=>{const e=Date.now()+Number(ms);while(Date.now()<e);return null;},
      hostname:()=>require('os').hostname(),
      user:()=>require('os').userInfo().username,
      homedir:()=>require('os').homedir(),
    };
    if(!(m in M))throw new SwxError(`#s.${m} не существует`,0);
    return M[m](a);
  }

  _nsN(m,a){
    const exec=cmd=>{try{return require('child_process').execSync(cmd,{encoding:'utf8',timeout:15000});}catch{return null;}};
    const M={
      get:([url])=>exec(`curl -s --max-time 10 "${String(url)}"`),
      post:([url,d])=>{const b=typeof d==='object'?JSON.stringify(d):String(d??'');return exec(`curl -s -X POST -H "Content-Type: application/json" -d '${b.replace(/'/g,"\\'")}' "${String(url)}"`)},
      ping:([host])=>exec(`ping -c 1 -W 2 "${String(host)}"`)!==null,
    };
    if(!(m in M))throw new SwxError(`#n.${m} не существует`,0);
    return M[m](a);
  }

  _nsAI(m,a){
    const M={
      prompt:([p])=>`[AI] Запрос: ${p} — интеграция в разработке`,
      analyze:([d])=>`[AI] Анализ: ${String(d).slice(0,60)}...`,
      grade:([c])=>`[AI] Сложность: ${String(c).length>100?'HIGH':'MEDIUM'}`,
    };
    if(!(m in M))throw new SwxError(`#ai.${m} не существует`,0);
    return M[m](a);
  }

  _builtin(name,args){
    const s=this;
    const B={
      str:([v])=>s.fmt(v),num:([v])=>Number(v),int:([v])=>Math.trunc(Number(v)),
      bool:([v])=>Boolean(v),type:([v])=>Array.isArray(v)?'array':v===null?'null':typeof v,
      is_num:([v])=>typeof v==='number'&&!isNaN(v),is_str:([v])=>typeof v==='string',
      is_arr:([v])=>Array.isArray(v),is_null:([v])=>v===null||v===undefined,
      is_bool:([v])=>typeof v==='boolean',
      parse:([v])=>{try{return JSON.parse(String(v));}catch{return null;}},
      json:([v,p])=>JSON.stringify(v,null,p?Number(p):undefined),
      print:([v])=>{s.output(s.fmt(v));return null;},

      floor:([a])=>Math.floor(Number(a)),ceil:([a])=>Math.ceil(Number(a)),
      round:([a,d])=>d?parseFloat(Number(a).toFixed(Number(d))):Math.round(Number(a)),
      abs:([a])=>Math.abs(Number(a)),sqrt:([a])=>Math.sqrt(Number(a)),cbrt:([a])=>Math.cbrt(Number(a)),
      pow:([a,b])=>Math.pow(Number(a),Number(b)),
      log:([a,b])=>b?Math.log(Number(a))/Math.log(Number(b)):Math.log(Number(a)),
      log2:([a])=>Math.log2(Number(a)),log10:([a])=>Math.log10(Number(a)),
      sin:([a])=>Math.sin(Number(a)),cos:([a])=>Math.cos(Number(a)),tan:([a])=>Math.tan(Number(a)),
      max:(a)=>Math.max(...a.map(Number)),min:(a)=>Math.min(...a.map(Number)),
      clamp:([v,a,b])=>Math.min(Math.max(Number(v),Number(a)),Number(b)),
      rand:([a,b])=>Math.floor(Math.random()*(Number(b??100)-Number(a??0)+1))+Number(a??0),
      randf:([a,b])=>Math.random()*(Number(b??1)-Number(a??0))+Number(a??0),
      even:([a])=>Number(a)%2===0,odd:([a])=>Number(a)%2!==0,

      len:([a])=>Array.isArray(a)?a.length:String(a??'').length,
      upper:([a])=>String(a??'').toUpperCase(),lower:([a])=>String(a??'').toLowerCase(),
      trim:([a])=>String(a??'').trim(),triml:([a])=>String(a??'').trimStart(),trimr:([a])=>String(a??'').trimEnd(),
      split:([a,b])=>String(a??'').split(b??','),
      join:([a,b])=>(Array.isArray(a)?a:[]).map(x=>s.fmt(x)).join(b??''),
      replace:([a,b,c])=>String(a??'').replaceAll(String(b),String(c)),
      replace1:([a,b,c])=>String(a??'').replace(String(b),String(c)),
      includes:([a,b])=>String(a??'').includes(String(b??'')),
      starts:([a,b])=>String(a??'').startsWith(String(b??'')),
      ends:([a,b])=>String(a??'').endsWith(String(b??'')),
      index_of:([a,b])=>String(a??'').indexOf(String(b??'')),
      slice:([a,x,y])=>Array.isArray(a)?a.slice(Number(x),y!=null?Number(y):undefined):String(a??'').slice(Number(x),y!=null?Number(y):undefined),
      repeat:([a,n])=>String(a??'').repeat(Number(n??0)),
      pad:([a,n,c])=>String(a??'').padStart(Number(n),c??'0'),
      padr:([a,n,c])=>String(a??'').padEnd(Number(n),c??' '),
      pad_c:([a,n,c])=>{const st=String(a??'');const pd=Math.max(0,Number(n)-st.length);return(c??' ').repeat(Math.floor(pd/2))+st+(c??' ').repeat(Math.ceil(pd/2));},
      chars:([a])=>[...String(a??'')],lines:([a])=>String(a??'').split('\n'),
      words:([a])=>String(a??'').trim().split(/\s+/),
      count:([a,b])=>String(a??'').split(String(b??'')).length-1,
      format:([t,...v])=>{let i=0;return String(t??'').replace(/\{\}/g,()=>s.fmt(v[i++]??null));},
      to_hex:([n])=>Number(n).toString(16),to_bin:([n])=>Number(n).toString(2),
      to_oct:([n])=>Number(n).toString(8),
      from_hex:([h])=>parseInt(String(h),16),from_bin:([b])=>parseInt(String(b),2),
      regex_test:([s,r])=>new RegExp(String(r)).test(String(s??'')),
      regex_match:([s,r])=>{const m=String(s??'').match(new RegExp(String(r),'g'));return m||[];},

      push:([a,v])=>{if(Array.isArray(a))a.push(v);return a;},
      pop:([a])=>Array.isArray(a)?(a.pop()??null):null,
      shift:([a])=>Array.isArray(a)?(a.shift()??null):null,
      unshift:([a,v])=>{if(Array.isArray(a))a.unshift(v);return a;},
      reverse:([a])=>Array.isArray(a)?[...a].reverse():a,
      sort:([a])=>Array.isArray(a)?[...a].sort():a,
      flat:([a,d])=>Array.isArray(a)?a.flat(d??1):[a],
      unique:([a])=>Array.isArray(a)?[...new Set(a)]:a,
      contains:([a,v])=>Array.isArray(a)?a.includes(v):String(a??'').includes(String(v??'')),
      first:([a])=>Array.isArray(a)?(a[0]??null):null,
      last:([a])=>Array.isArray(a)?(a[a.length-1]??null):null,
      nth:([a,n])=>Array.isArray(a)?(a[Number(n)]??null):null,
      range:([a,b,st])=>{const r=[],step=st??1;for(let i=Number(a??0);i<Number(b??0);i+=step)r.push(i);return r;},
      chunk:([a,n])=>{if(!Array.isArray(a))return[];const r=[];for(let i=0;i<a.length;i+=Number(n))r.push(a.slice(i,i+Number(n)));return r;},
      zip:(arrs)=>{const l=Math.min(...arrs.map(a=>Array.isArray(a)?a.length:0));return Array.from({length:l},(_,i)=>arrs.map(a=>a[i]??null));},
      flatten:([a])=>Array.isArray(a)?a.flat(Infinity):[a],
      shuffle:([a])=>{if(!Array.isArray(a))return a;const r=[...a];for(let i=r.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[r[i],r[j]]=[r[j],r[i]];}return r;},

      keys:([o])=>o&&typeof o==='object'&&!Array.isArray(o)?Object.keys(o):[],
      values:([o])=>o&&typeof o==='object'&&!Array.isArray(o)?Object.values(o):[],
      entries:([o])=>o&&typeof o==='object'&&!Array.isArray(o)?Object.entries(o).map(([k,v])=>({key:k,val:v})):[],
      has_key:([o,k])=>o&&typeof o==='object'?k in o:false,
      merge:([a,b])=>({...a,...b}),
      del_key:([o,k])=>{if(o&&typeof o==='object'){const r={...o};delete r[String(k)];return r;}return o;},
      from_entries:([arr])=>{const o={};if(Array.isArray(arr))arr.forEach(e=>{if(e&&typeof e==='object')o[e.key??e[0]]=e.val??e[1];});return o;},
      assert:([cond,msg])=>{if(!s.truthy(cond))throw new SwxError('Assertion: '+(msg??String(cond)),0);return true;},
    };
    if(name in B)return{found:true,val:B[name](args)};
    return{found:false,val:null};
  }

  exec(src,env=null,fp=null){
    if(fp)this.cwd=path.dirname(fp);
    const tokens=tokenize(src);
    const ast=new Parser(tokens).parseProgram();
    return this.run(ast.stmts,env||this.globals);
  }

  run(stmts,env){
    for(const s of stmts){
      const r=this.stmt(s,env);
      if(r instanceof RetSig||r instanceof BrkSig||r instanceof NxtSig)return r;
    }
    return null;
  }

  stmt(s,env){
    switch(s.type){
      case 'VarDecl': env.set(s.name,this.eval(s.expr,env));return null;

      case 'Assign':{
        let cur=env.has(s.name)?env.get(s.name):0;
        let val=this.eval(s.expr,env);
        if(s.op==='PLEQ'||s.op==='~=')val=(typeof cur==='string'||typeof val==='string')?String(cur)+String(val):Number(cur)+Number(val);
        else if(s.op==='MIEQ'||s.op==='-=')val=Number(cur)-Number(val);
        else if(s.op==='MUEQ'||s.op==='*~')val=Number(cur)*Number(val);
        else if(s.op==='DIEQ'||s.op==='/~')val=Number(cur)/Number(val);
        env.assign(s.name,val);return null;
      }

      case 'MemberAssign':{const val=this.eval(s.val,env);this._mset(s.target,val,env);return null;}

      case 'Emit': this.output(this.fmt(this.eval(s.expr,env)));return null;

      case 'FuncDef': this.fns[s.name]={params:s.params,defaults:s.defaults,body:s.body,closure:env};return null;

      case 'If':{
        if(this.truthy(this.eval(s.cond,env))){const r=this.run(s.body,new Env(env));if(r)return r;}
        else if(s.else){const r=Array.isArray(s.else)?this.run(s.else,new Env(env)):this.stmt(s.else,env);if(r)return r;}
        return null;
      }

      case 'Match':{
        const val=this.eval(s.subj,env);
        for(const cas of s.cases){
          if(cas.isDefault){const r=this.run(cas.body,new Env(env));if(r)return r;break;}
          const match=cas.patterns.some(p=>{const pv=this.eval(p,env);return pv===val;});
          if(match){const r=this.run(cas.body,new Env(env));if(r)return r;break;}
        }
        return null;
      }

      case 'Loop':{
        const n=Number(this.eval(s.count,env));
        if(n>1_000_000)throw new SwxError('Лимит xs: 1M итераций',s.line);
        for(let i=0;i<n;i++){
          const le=new Env(env);le.set('_i',i);le.set('_n',n);
          const r=this.run(s.body,le);
          if(r instanceof RetSig)return r;
          if(r instanceof BrkSig)break;
          if(r instanceof NxtSig)continue;
        }
        return null;
      }

      case 'While':{
        let iters=0;
        while(this.truthy(this.eval(s.cond,env))){
          if(++iters>1_000_000)throw new SwxError('Лимит xl: 1M итераций',s.line);
          const r=this.run(s.body,new Env(env));
          if(r instanceof RetSig)return r;
          if(r instanceof BrkSig)break;
          if(r instanceof NxtSig)continue;
        }
        return null;
      }

      case 'ForEach':{
        let iter=this.eval(s.iter,env);
        if(!Array.isArray(iter))iter=iter&&typeof iter==='object'?Object.entries(iter).map(([k,v])=>({key:k,val:v})):[iter];
        for(let i=0;i<iter.length;i++){
          const le=new Env(env);le.set(s.varName,iter[i]);le.set('_i',i);
          const r=this.run(s.body,le);
          if(r instanceof RetSig)return r;
          if(r instanceof BrkSig)break;
          if(r instanceof NxtSig)continue;
        }
        return null;
      }

      case 'Return': return new RetSig(s.expr?this.eval(s.expr,env):null);
      case 'Break':  return new BrkSig();
      case 'Next':   return new NxtSig();
      case 'Throw':  throw new SwxError(String(this.eval(s.expr,env)),s.line);

      case 'TryCatch':{
        try{const r=this.run(s.body,new Env(env));if(r)return r;}
        catch(e){
          if(s.handler?.length){const he=new Env(env);if(s.errVar)he.set(s.errVar,e.message||String(e));const r=this.run(s.handler,he);if(r)return r;}
        }finally{if(s.finally?.length)this.run(s.finally,new Env(env));}
        return null;
      }

      case 'Import':{
        const cands=[
          path.resolve(this.cwd,s.path),
          path.resolve(this.cwd,s.path+'.swx'),
          path.resolve(this.cwd,'stdlib',s.path+'.swx'),
          path.resolve(__dirname,'..','stdlib',s.path+'.swx'),
        ];
        const fp=cands.find(p=>fs.existsSync(p));
        if(!fp)throw new SwxError(`Модуль '${s.path}' не найден`,s.line);
        const old=this.cwd;this.cwd=path.dirname(fp);
        const sub=new Interpreter({...this.opts,cwd:this.cwd,output:this.output});
        sub.fns=this.fns;sub.globals=this.globals;
        sub.exec(fs.readFileSync(fp,'utf8'),this.globals,fp);
        this.cwd=old;return null;
      }

      case 'Export': try{this.exports[s.name]=env.get(s.name);}catch{}return null;

      case 'Render':{
        const{full}=this.web.render(s,this,env);
        if(s.dest){
          const op=path.resolve(this.cwd,s.dest);
          fs.mkdirSync(path.dirname(op),{recursive:true});
          fs.writeFileSync(op,full,'utf8');
          this.output(`[render] Сохранено → ${op}`);
        } else {
          this.output('[render] '+'─'.repeat(50));
          this.output(full);
          this.output('[render] '+'─'.repeat(50));
        }
        return null;
      }

      case 'ExprStmt': this.eval(s.expr,env);return null;
    }
    return null;
  }

  eval(node,env){
    if(!node)return null;
    switch(node.type){
      case 'Lit': return node.value;
      case 'StrLit': return node.value.replace(/\{([a-zA-Z_$][a-zA-Z0-9_$]*)\}/g,(_,n)=>{try{return this.fmt(env.get(n));}catch{return`{${n}}`;}});
      case 'Ident': try{return env.get(node.name);}catch{return null;}
      case 'NSCall': return{__ns__:true,ns:node.ns,meth:node.meth};
      case 'Arr': return node.elements.map(e=>this.eval(e,env));
      case 'ObjLit':{const o={};node.pairs.forEach(p=>o[p.key]=this.eval(p.val,env));return o;}

      case 'Pipe':{
        const val=this.eval(node.left,env);
        const fn=node.fn;
        if(fn.type==='NSCall')return this._ns(fn.ns,fn.meth,[val]);
        if(fn.type==='Ident'){
          const name=fn.name;
          const bi=this._builtin(name,[val]);
          if(bi.found)return bi.val;
          if(name in this.fns)return this._callFn(name,[val]);
        }
        return val;
      }

      case 'Index':{
        const t=this.eval(node.target,env),i=this.eval(node.idx,env);
        if(t===null||t===undefined)return null;
        if(Array.isArray(t))return t[Number(i)]??null;
        if(typeof t==='object')return t[String(i)]??null;
        return String(t)[Number(i)]??null;
      }

      case 'Prop':{
        const t=this.eval(node.target,env);
        if(t===null||t===undefined)return null;
        if(Array.isArray(t)){if(node.prop==='length')return t.length;if(node.prop==='last')return t[t.length-1]??null;if(node.prop==='first')return t[0]??null;}
        if(typeof t==='string'&&node.prop==='length')return t.length;
        if(typeof t==='object'&&!t.__ns__)return t[node.prop]??null;
        return null;
      }

      case 'BinOp':{
        const l=this.eval(node.left,env);
        if(node.op==='&&')return this.truthy(l)?this.eval(node.right,env):l;
        if(node.op==='||')return this.truthy(l)?l:this.eval(node.right,env);
        const r=this.eval(node.right,env);
        switch(node.op){
          case 'PLUS': return(typeof l==='string'||typeof r==='string')?String(l??'')+String(r??''):Number(l)+Number(r);
          case 'MINUS':return Number(l)-Number(r);
          case 'STAR': return Number(l)*Number(r);
          case 'SLASH':if(!Number(r))throw new SwxError('Деление на ноль',node.line);return Number(l)/Number(r);
          case 'MOD':  return Number(l)%Number(r);
          case 'POW':  return Math.pow(Number(l),Number(r));
          case 'EQ':   return l===r;
          case 'NEQ':  return l!==r;
          case 'LT':   return Number(l)<Number(r);
          case 'GT':   return Number(l)>Number(r);
          case 'LTE':  return Number(l)<=Number(r);
          case 'GTE':  return Number(l)>=Number(r);
          case '&':    return Number(l)&Number(r);
          case '|':    return Number(l)|Number(r);
          case '^':    return Number(l)^Number(r);
        }
        return null;
      }

      case 'UnOp':{const v=this.eval(node.expr,env);return node.op==='!'?!this.truthy(v):-Number(v);}

      case 'Call':{
        const callee=node.callee;
        const args=node.args.map(a=>this.eval(a,env));
        if(callee.type==='NSCall')return this._ns(callee.ns,callee.meth,args);
        const cv=this.eval(callee,env);
        if(cv&&cv.__ns__)return this._ns(cv.ns,cv.meth,args);
        if(callee.type==='Ident'){
          const name=callee.name;
          const bi=this._builtin(name,args);
          if(bi.found)return bi.val;
          if(name in this.fns)return this._callFn(name,args);
          throw new SwxError(`Функция '${name}' не определена`,node.line);
        }
        if(callee.type==='Prop'){
          const obj=this.eval(callee.target,env),meth=callee.prop;
          if(typeof obj==='string'){
            if(meth==='upper')return obj.toUpperCase();if(meth==='lower')return obj.toLowerCase();
            if(meth==='trim')return obj.trim();if(meth==='split')return obj.split(args[0]??',');
            if(meth==='includes')return obj.includes(String(args[0]??''));
            if(meth==='replace')return obj.replaceAll(String(args[0]),String(args[1]));
            if(meth==='starts')return obj.startsWith(String(args[0]??''));
            if(meth==='ends')return obj.endsWith(String(args[0]??''));
            if(meth==='slice')return obj.slice(Number(args[0]),args[1]!=null?Number(args[1]):undefined);
            if(meth==='sha256')return C.SHA256(obj);if(meth==='hex')return C.HEX(obj);if(meth==='base64')return C.B64ENC(obj);
          }
          if(Array.isArray(obj)){
            if(meth==='push'){obj.push(args[0]);return obj;}if(meth==='pop')return obj.pop()??null;
            if(meth==='join')return obj.map(x=>this.fmt(x)).join(args[0]??',');
            if(meth==='reverse')return[...obj].reverse();if(meth==='sort')return[...obj].sort();
            if(meth==='contains')return obj.includes(args[0]);
            if(meth==='slice')return obj.slice(Number(args[0]),args[1]!=null?Number(args[1]):undefined);
            if(meth==='unique')return[...new Set(obj)];
          }
          if(obj&&typeof obj==='object'){if(meth==='keys')return Object.keys(obj);if(meth==='values')return Object.values(obj);}
        }
        return null;
      }
    }
    return null;
  }

  _callFn(name,args){
    const fn=this.fns[name];
    if(!fn)throw new SwxError(`'${name}' не определена`,0);
    const fe=new Env(fn.closure||this.globals);
    fn.params.forEach((p,i)=>{const def=fn.defaults?.[i]!=null?this.eval(fn.defaults[i],fn.closure||this.globals):null;fe.set(p,args[i]??def);});
    const r=this.run(fn.body,fe);
    return r instanceof RetSig?r.value:null;
  }

  _mset(target,val,env){
    if(target.type==='Prop'){const obj=this.eval(target.target,env);if(obj&&typeof obj==='object')obj[target.prop]=val;}
    else if(target.type==='Index'){const obj=this.eval(target.target,env),idx=this.eval(target.idx,env);if(Array.isArray(obj))obj[Number(idx)]=val;else if(obj&&typeof obj==='object')obj[String(idx)]=val;}
  }

  fmt(v){
    if(v===null||v===undefined)return'null';
    if(typeof v==='boolean')return v?'true':'false';
    if(Array.isArray(v))return'['+v.map(x=>this.fmt(x)).join(', ')+']';
    if(typeof v==='object'&&!v.__ns__)return'{'+Object.entries(v).map(([k,vv])=>k+': '+this.fmt(vv)).join(', ')+'}';
    return String(v);
  }
  truthy(v){return v!==null&&v!==false&&v!==0&&v!==''&&v!==undefined;}
}

module.exports={Interpreter,SwxError,Env};
