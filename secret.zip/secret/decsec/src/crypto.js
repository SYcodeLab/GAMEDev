'use strict';
// ═══════════════════════════════════════════════════
//  SWX CRYPTO ENGINE  — real implementations
// ═══════════════════════════════════════════════════
const crypto = require('crypto');

// ── Native Node crypto wrappers ──────────────────────
const SHA256   = s => crypto.createHash('sha256').update(String(s)).digest('hex');
const SHA512   = s => crypto.createHash('sha512').update(String(s)).digest('hex');
const SHA1     = s => crypto.createHash('sha1').update(String(s)).digest('hex');
const MD5      = s => crypto.createHash('md5').update(String(s)).digest('hex');
const SHA3_256 = s => crypto.createHash('sha3-256').update(String(s)).digest('hex');
const RIPEMD   = s => { try { return crypto.createHash('ripemd160').update(String(s)).digest('hex'); } catch { return '[ripemd160 unavailable]'; } };

const HMAC = (algo, key, msg) =>
  crypto.createHmac(algo, String(key)).update(String(msg)).digest('hex');

// AES-256-CBC
function aesEncrypt(text, key) {
  const k   = crypto.scryptSync(String(key), 'swx_salt', 32);
  const iv  = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', k, iv);
  const enc = Buffer.concat([cipher.update(String(text), 'utf8'), cipher.final()]);
  return iv.toString('hex') + ':' + enc.toString('hex');
}

function aesDecrypt(ciphertext, key) {
  try {
    const [ivHex, encHex] = String(ciphertext).split(':');
    const k   = crypto.scryptSync(String(key), 'swx_salt', 32);
    const iv  = Buffer.from(ivHex, 'hex');
    const enc = Buffer.from(encHex, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', k, iv);
    return Buffer.concat([decipher.update(enc), decipher.final()]).toString('utf8');
  } catch (e) { return '[decrypt error: ' + e.message + ']'; }
}

// RSA key generation
function rsaGenKeys(bits = 2048) {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
    modulusLength: bits,
    publicKeyEncoding:  { type:'spki',  format:'pem' },
    privateKeyEncoding: { type:'pkcs8', format:'pem' },
  });
  return { pub: publicKey, priv: privateKey };
}

function rsaSign(data, privKey) {
  try {
    const sign = crypto.createSign('SHA256');
    sign.update(String(data));
    return sign.sign(String(privKey), 'hex');
  } catch (e) { return '[sign error: ' + e.message + ']'; }
}

function rsaVerify(data, sig, pubKey) {
  try {
    const verify = crypto.createVerify('SHA256');
    verify.update(String(data));
    return verify.verify(String(pubKey), String(sig), 'hex');
  } catch { return false; }
}

// Encoding
const HEX     = s  => Buffer.from(String(s), 'utf8').toString('hex');
const UNHEX   = h  => { try { return Buffer.from(String(h), 'hex').toString('utf8'); } catch { return '[invalid hex]'; } };
const B64ENC  = s  => Buffer.from(String(s), 'utf8').toString('base64');
const B64DEC  = s  => { try { return Buffer.from(String(s), 'base64').toString('utf8'); } catch { return '[invalid b64]'; } };
const B64URL  = s  => Buffer.from(String(s), 'utf8').toString('base64url');

// XOR cipher
const XOR = (msg, key) => {
  const mb = Buffer.from(String(msg), 'utf8');
  const kb = Buffer.from(String(key), 'utf8');
  return Buffer.from(mb.map((b, i) => b ^ kb[i % kb.length])).toString('hex');
};

// Classical ciphers
const CAESAR = (s, n) => {
  n = ((n % 26) + 26) % 26;
  return String(s).replace(/[a-zA-Z]/g, c => {
    const base = c <= 'Z' ? 65 : 97;
    return String.fromCharCode((c.charCodeAt(0) - base + n) % 26 + base);
  });
};
const ROT13 = s => CAESAR(s, 13);
const VIGENERE = (text, key) => {
  key = String(key).toLowerCase().replace(/[^a-z]/g,'');
  if (!key.length) return String(text);
  let ki = 0;
  return String(text).replace(/[a-zA-Z]/g, c => {
    const base = c <= 'Z' ? 65 : 97;
    const shift = key[ki++ % key.length].charCodeAt(0) - 97;
    return String.fromCharCode((c.charCodeAt(0) - base + shift) % 26 + base);
  });
};

// Utilities
const GENKEY   = (n = 32) => crypto.randomBytes(Math.ceil(n / 2)).toString('hex').slice(0, n);
const GENIV    = () => crypto.randomBytes(16).toString('hex');
const RANDOMBYTES = n => crypto.randomBytes(Number(n)).toString('hex');

const ENTROPY = s => {
  const freq = {};
  for (const c of String(s)) freq[c] = (freq[c] || 0) + 1;
  const len = String(s).length;
  return Object.values(freq).reduce((h, f) => {
    const p = f / len; return h - p * Math.log2(p);
  }, 0);
};

const CHECKSUM_CRC32 = s => {
  const buf = Buffer.from(String(s), 'utf8');
  let crc = 0xFFFFFFFF;
  for (const byte of buf) {
    crc ^= byte;
    for (let i = 0; i < 8; i++) crc = (crc & 1) ? (crc >>> 1) ^ 0xEDB88320 : crc >>> 1;
  }
  return ((crc ^ 0xFFFFFFFF) >>> 0).toString(16).padStart(8, '0');
};

// JWT-like token (not signed with RS256 for simplicity, uses HMAC)
function createToken(payload, secret, expiresIn = 3600) {
  const header  = B64URL(JSON.stringify({ alg:'HS256', typ:'SWX' }));
  const data    = B64URL(JSON.stringify({ ...payload, iat: Date.now(), exp: Date.now() + expiresIn * 1000 }));
  const sig     = HMAC('sha256', secret, `${header}.${data}`).slice(0, 43);
  return `${header}.${data}.${sig}`;
}

function verifyToken(token, secret) {
  try {
    const [header, data, sig] = String(token).split('.');
    const expected = HMAC('sha256', secret, `${header}.${data}`).slice(0, 43);
    if (sig !== expected) return { valid: false, error: 'invalid signature' };
    const payload = JSON.parse(Buffer.from(data, 'base64url').toString('utf8'));
    if (payload.exp && Date.now() > payload.exp) return { valid: false, error: 'expired' };
    return { valid: true, payload };
  } catch (e) { return { valid: false, error: e.message }; }
}

// UUID v4
const UUID = () => crypto.randomUUID ? crypto.randomUUID() :
  'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });

// Password strength
const PASSWORD_STRENGTH = pwd => {
  const s = String(pwd);
  let score = 0;
  if (s.length >= 8)  score++;
  if (s.length >= 12) score++;
  if (s.length >= 16) score++;
  if (/[A-Z]/.test(s)) score++;
  if (/[a-z]/.test(s)) score++;
  if (/[0-9]/.test(s)) score++;
  if (/[^A-Za-z0-9]/.test(s)) score++;
  if (ENTROPY(s) > 3.5) score++;
  const levels = ['VERY WEAK','WEAK','WEAK','MEDIUM','MEDIUM','STRONG','STRONG','VERY STRONG'];
  return levels[Math.min(score, 7)];
};

module.exports = {
  SHA256, SHA512, SHA1, MD5, SHA3_256, RIPEMD,
  HMAC, aesEncrypt, aesDecrypt,
  rsaGenKeys, rsaSign, rsaVerify,
  HEX, UNHEX, B64ENC, B64DEC, B64URL,
  XOR, CAESAR, ROT13, VIGENERE,
  GENKEY, GENIV, RANDOMBYTES,
  ENTROPY, CHECKSUM_CRC32,
  createToken, verifyToken,
  UUID, PASSWORD_STRENGTH,
};
