'use strict';
// ═══════════════════════════════════════════════════════════════════════
//  SWX PARSER  v7.0
// ═══════════════════════════════════════════════════════════════════════
const {TT}=require('./lexer');

const CSS_PROPS=new Set([
  'bg','color','size','pad','mar','border','radius','font','w','h','weight',
  'shadow','opacity','display','pos','top','left','right','bottom','overflow',
  'cursor','transition','transform','gap','align','justify','wrap','dir',
  'cols','rows','z','minw','maxw','mnh','mxh','lh','ls','indent',
  'outline','resize','select','appearance','decoration','visibility',
  'bold','italic','flex','grid','block','inline','relative','absolute',
  'fixed','sticky','center','underline','none','nowrap','pre','pointer',
  'default','hidden','scroll','auto','rounded','circle','uppercase',
  'lowercase','capitalize','no-select','border-box',
]);

class ParseError extends Error{
  constructor(m,t){super(`[SWX Parse] ${t?.line}:${t?.col} — ${m}`);this.line=t?.line;this.col=t?.col;this.isSwx=true;}
}

class Parser{
  constructor(toks){this.t=toks;this.p=0;}
  peek(o=0){return this.t[this.p+o];}
  next(){return this.t[this.p++];}
  check(tp){return this.peek()?.type===tp;}
  eat(tp){const tok=this.peek();if(tok?.type!==tp)throw new ParseError(`Ожидалось '${tp}', получено '${tok?.type}'${tok?.value!=null?` '${tok.value}'`:''}`,tok);return this.next();}
  match(...ts){for(const t of ts)if(this.check(t)){this.next();return true;}return false;}

  parseProgram(){const s=[];while(!this.check(TT.EOF)){const x=this.parseStmt();if(x)s.push(x);}return{type:'Program',stmts:s};}

  parseStmt(){
    const t=this.peek();
    if(!t||t.type===TT.EOF)return null;
    switch(t.type){
      case TT.SWX:   return this.parseVarDecl();
      case TT.SWXT:  return this.parseThrow();
      case TT.WX:    return this.parseEmit();
      case TT.SX:    return this.parseFuncDef();
      case TT.SXR:   return this.parseRender();
      case TT.SW:    return this.parseIf();
      case TT.MATCH: return this.parseMatch();
      case TT.XS:    return this.parseLoop();
      case TT.XL:    return this.parseWhile();
      case TT.XW:    return this.parseForEach();
      case TT.WS:    return this.parseReturn();
      case TT.SIMP:  return this.parseImport();
      case TT.WEXP:  return this.parseExport();
      case TT.XTRY:  return this.parseTryCatch();
      case TT.BREAK: this.next();return{type:'Break',line:t.line};
      case TT.NEXT:  this.next();return{type:'Next',line:t.line};
      case TT.IDENT:{
        const n1=this.peek(1);
        if([TT.ASSIGN,TT.PLEQ,TT.MIEQ,TT.MUEQ,TT.DIEQ].includes(n1?.type))return this.parseAssign();
        if(n1?.type===TT.DOT||n1?.type===TT.LSQ){
          let i=1;
          while([TT.DOT,TT.IDENT,TT.LSQ,TT.NUM,TT.STR,TT.RSQ].includes(this.peek(i)?.type))i++;
          if([TT.ASSIGN,TT.PLEQ,TT.MIEQ,TT.MUEQ,TT.DIEQ].includes(this.peek(i)?.type))return this.parseMemberAssign();
        }
        return{type:'ExprStmt',expr:this.parseExpr(),line:t.line};
      }
      default:return{type:'ExprStmt',expr:this.parseExpr(),line:t.line};
    }
  }

  parseVarDecl(){const ln=this.peek().line;this.eat(TT.SWX);const name=this.eat(TT.IDENT).value;this.eat(TT.ASSIGN);return{type:'VarDecl',name,expr:this.parseExpr(),line:ln};}
  parseAssign(){const ln=this.peek().line;const name=this.eat(TT.IDENT).value;const op=this.next().type;return{type:'Assign',name,op,expr:this.parseExpr(),line:ln};}
  parseMemberAssign(){const ln=this.peek().line;const target=this.parsePostfix();const op=this.next().type;return{type:'MemberAssign',target,op,val:this.parseExpr(),line:ln};}
  parseThrow(){const ln=this.peek().line;this.eat(TT.SWXT);return{type:'Throw',expr:this.parseExpr(),line:ln};}
  parseEmit(){const ln=this.peek().line;this.eat(TT.WX);return{type:'Emit',expr:this.parseExpr(),line:ln};}

  parseFuncDef(){
    const ln=this.peek().line;this.eat(TT.SX);
    const name=this.eat(TT.IDENT).value;
    const{params,defaults}=this._params();
    this.eat(TT.ARROW);
    const body=this.check(TT.LB)?this.parseBlock():[{type:'Return',expr:this.parseExpr(),line:ln}];
    return{type:'FuncDef',name,params,defaults,body,line:ln};
  }

  _params(){
    this.eat(TT.LP);const params=[],defaults=[];
    if(!this.check(TT.RP)){
      do{params.push(this.eat(TT.IDENT).value);if(this.check(TT.ASSIGN)){this.eat(TT.ASSIGN);defaults.push(this.parseExpr());}else defaults.push(null);}
      while(this.match(TT.COMMA));
    }
    this.eat(TT.RP);return{params,defaults};
  }

  parseIf(){
    const ln=this.peek().line;this.eat(TT.SW);const cond=this.parseExpr();const body=this.parseBlock();
    let el=null;
    if(this.check(TT.DR)){this.eat(TT.DR);el=this.check(TT.SW)?this.parseIf():this.parseBlock();}
    return{type:'If',cond,body,else:el,line:ln};
  }

  parseMatch(){
    const ln=this.peek().line;this.eat(TT.MATCH);
    const subj=this.parseExpr();
    this.eat(TT.LB);
    const cases=[];
    while(!this.check(TT.RB)&&!this.check(TT.EOF)){
      if(this.check(TT.DFLT)){
        this.eat(TT.DFLT);this.eat(TT.ARROW);
        const body=this.check(TT.LB)?this.parseBlock():[this.parseStmt()];
        cases.push({patterns:null,body,isDefault:true});
      } else {
        this.eat(TT.CASE);
        const patterns=[];
        patterns.push(this.parseExpr());
        while(this.check(TT.BOR||'BOR')||this.peek()?.value==='|'){this.next();patterns.push(this.parseExpr());}
        this.eat(TT.ARROW);
        const body=this.check(TT.LB)?this.parseBlock():[this.parseStmt()];
        cases.push({patterns,body,isDefault:false});
      }
      this.match(TT.COMMA);
    }
    this.eat(TT.RB);
    return{type:'Match',subj,cases,line:ln};
  }

  parseLoop(){const ln=this.peek().line;this.eat(TT.XS);return{type:'Loop',count:this.parseExpr(),body:this.parseBlock(),line:ln};}
  parseWhile(){const ln=this.peek().line;this.eat(TT.XL);return{type:'While',cond:this.parseExpr(),body:this.parseBlock(),line:ln};}

  parseForEach(){
    const ln=this.peek().line;this.eat(TT.XW);
    const varName=this.eat(TT.IDENT).value;this.eat(TT.IN);
    return{type:'ForEach',varName,iter:this.parseExpr(),body:this.parseBlock(),line:ln};
  }

  parseReturn(){const ln=this.peek().line;this.eat(TT.WS);const expr=(this.check(TT.RB)||this.check(TT.EOF))?null:this.parseExpr();return{type:'Return',expr,line:ln};}
  parseImport(){const ln=this.peek().line;this.eat(TT.SIMP);return{type:'Import',path:this.eat(TT.STR).value,line:ln};}
  parseExport(){const ln=this.peek().line;this.eat(TT.WEXP);return{type:'Export',name:this.eat(TT.IDENT).value,line:ln};}

  parseTryCatch(){
    const ln=this.peek().line;this.eat(TT.XTRY);const body=this.parseBlock();
    let errVar=null,handler=[],fin=null;
    if(this.check(TT.XCAT)){this.eat(TT.XCAT);if(this.check(TT.LP)){this.eat(TT.LP);errVar=this.eat(TT.IDENT).value;this.eat(TT.RP);}handler=this.parseBlock();}
    if(this.check(TT.XFIN)){this.eat(TT.XFIN);fin=this.parseBlock();}
    return{type:'TryCatch',body,errVar,handler,finally:fin,line:ln};
  }

  // ── RENDER ──────────────────────────────────────────────
  parseRender(){
    const ln=this.peek().line;this.eat(TT.SXR);
    const dest=this.check(TT.STR)?this.eat(TT.STR).value:null;
    this.eat(TT.LB);
    let styleRules=[],bodyNodes=[],scriptStmts=[];
    while(!this.check(TT.RB)&&!this.check(TT.EOF)){
      this.eat(TT.AT);const sec=this.eat(TT.IDENT).value;this.eat(TT.LB);
      if(sec==='style')styleRules=this._parseStyle();
      else if(sec==='body')bodyNodes=this._parseBody();
      else if(sec==='script')scriptStmts=this._parseScript();
      else this._skipBlock();
    }
    this.eat(TT.RB);
    return{type:'Render',dest,styleRules,bodyNodes,scriptStmts,line:ln};
  }


  // Read CSS identifier that may contain hyphens: card-title, btn-primary
  _readCSSIdent(){
    let name=this.eat(TT.IDENT).value;
    while(this.check(TT.MINUS)&&this.peek(1)?.type===TT.IDENT){this.eat(TT.MINUS);name+='-'+this.eat(TT.IDENT).value;}
    return name;
  }

  _parseStyle(){
    const rules=[];
    while(!this.check(TT.RB)&&!this.check(TT.EOF)){
      let sel='';
      if(this.check(TT.DOT)){this.eat(TT.DOT);sel='.'+this._readCSSIdent();}
      else if(this.check(TT.IDENT)){
        sel=this._readCSSIdent();
        while(this.check(TT.DOT)&&this.peek(1)?.type===TT.IDENT){this.eat(TT.DOT);sel+='.'+this._readCSSIdent();}
      } else break;
      if(!this.check(TT.ARR))break;
      this.eat(TT.ARR);
      const props=[];
      while(!this.check(TT.RB)&&!this.check(TT.EOF)){
        if(this.check(TT.DOT))break;
        if(!this.check(TT.IDENT))break;
        const id=this.peek().value;
        if(!CSS_PROPS.has(id)){let i=1;while([TT.IDENT,TT.DOT].includes(this.peek(i)?.type))i++;if(this.peek(i)?.type===TT.ARR)break;}
        const prop=this.eat(TT.IDENT).value;
        if(this.check(TT.LP)){this.eat(TT.LP);const val=this._cssVal();this.eat(TT.RP);props.push({prop,val});}
        else props.push({prop,val:null});
      }
      if(props.length)rules.push({sel,props});
    }
    this.eat(TT.RB);return rules;
  }

  _cssVal(){
    const parts=[];
    while(!this.check(TT.RP)&&!this.check(TT.EOF)){
      const t=this.peek();
      if(t.type===TT.HEXC){this.next();parts.push(t.value);}
      else if(t.type===TT.NUM){this.next();if(this.check(TT.IDENT)){const u=this.eat(TT.IDENT).value;parts.push(String(t.value)+u);}else parts.push(String(t.value));}
      else if(t.type===TT.STR){this.next();parts.push('"'+t.value+'"');}
      else if(t.type===TT.IDENT){this.next();parts.push(t.value);}
      else if(t.type===TT.NS){this.next();parts.push('#'+(t.value||''));}
      else if(t.type===TT.SLASH){this.next();parts.push('/');}
      else if(t.type===TT.MINUS){this.next();if(this.check(TT.NUM)){const n=this.eat(TT.NUM).value;if(this.check(TT.IDENT)){const u=this.eat(TT.IDENT).value;parts.push('-'+n+u);}else parts.push('-'+n);}else parts.push('-');}
      else if(t.type===TT.DOT){this.next();parts.push('.');}
      else if(t.type===TT.COMMA){this.next();parts.push(', ');}
      else if(t.type===TT.COLON){this.next();parts.push(':');}
      else{this.next();parts.push(String(t.value??t.type));}
    }
    return parts.join('').trim().replace(/ ,/g,',');
  }

  _parseBody(){const nodes=[];while(!this.check(TT.RB)&&!this.check(TT.EOF))nodes.push(this._htmlNode());this.eat(TT.RB);return nodes;}

  _htmlNode(){
    if(!this.check(TT.IDENT))return{type:'HtmlExpr',expr:this.parseExpr()};
    const tag=this._readCSSIdent();
    let cls='';
    while(this.check(TT.DOT)&&this.peek(1)?.type===TT.IDENT){this.eat(TT.DOT);cls+=(cls?' ':'')+this._readCSSIdent();}
    this.eat(TT.ARR);
    const attrs={};
    if(this.check(TT.LP)){this.eat(TT.LP);while(!this.check(TT.RP)&&!this.check(TT.EOF)){const k=this.eat(TT.IDENT).value;this.eat(TT.COLON);attrs[k]=this.parseExpr();this.match(TT.COMMA);}this.eat(TT.RP);}
    if(this.check(TT.LB)){this.eat(TT.LB);const ch=[];while(!this.check(TT.RB)&&!this.check(TT.EOF))ch.push(this._htmlNode());this.eat(TT.RB);return{type:'HtmlNode',tag,cls,attrs,children:ch,content:null};}
    return{type:'HtmlNode',tag,cls,attrs,children:null,content:this.parseExpr()};
  }

  _parseScript(){const s=[];while(!this.check(TT.RB)&&!this.check(TT.EOF)){const x=this.parseStmt();if(x)s.push(x);}this.eat(TT.RB);return s;}
  _skipBlock(){let d=0;while(!this.check(TT.EOF)){if(this.check(TT.LB))d++;else if(this.check(TT.RB)){if(d===0){this.eat(TT.RB);return;}d--;}this.next();}}

  parseBlock(){this.eat(TT.LB);const s=[];while(!this.check(TT.RB)&&!this.check(TT.EOF)){const x=this.parseStmt();if(x)s.push(x);}this.eat(TT.RB);return s;}

  // ── Выражения ────────────────────────────────────────────
  parseExpr(){return this.parsePipe();}

  // Pipe: a |> f  →  f(a)
  parsePipe(){
    let l=this.parseOr();
    while(this.check(TT.PIPE)){
      this.next();const fn=this.parsePostfix();
      l={type:'Pipe',left:l,fn,line:l.line};
    }
    return l;
  }

  parseOr()  {let l=this.parseAnd();  while(this.check(TT.SWOR)) {this.next();l={type:'BinOp',op:'||',left:l,right:this.parseAnd()};}  return l;}
  parseAnd() {let l=this.parseEq();   while(this.check(TT.SWAND)){this.next();l={type:'BinOp',op:'&&',left:l,right:this.parseEq()};}   return l;}
  parseEq()  {let l=this.parseCmp();  while(this.check(TT.EQ)||this.check(TT.NEQ)){const op=this.next().type;l={type:'BinOp',op,left:l,right:this.parseCmp()};}return l;}
  parseCmp() {let l=this.parseAdd();  while([TT.LT,TT.GT,TT.LTE,TT.GTE].some(t=>this.check(t))){const op=this.next().type;l={type:'BinOp',op,left:l,right:this.parseAdd()};}return l;}
  parseAdd() {let l=this.parseMul();  while(this.check(TT.PLUS)||this.check(TT.MINUS)){const op=this.next().type;l={type:'BinOp',op,left:l,right:this.parseMul()};}return l;}
  parseMul() {let l=this.parsePow();  while(this.check(TT.STAR)||this.check(TT.SLASH)||this.check(TT.MOD)){const op=this.next().type;l={type:'BinOp',op,left:l,right:this.parsePow()};}return l;}
  parsePow() {let l=this.parseUnary();if(this.check(TT.POW)){this.next();return{type:'BinOp',op:'POW',left:l,right:this.parsePow()};}return l;}

  parseUnary(){
    if(this.check(TT.SWNOT)){this.next();return{type:'UnOp',op:'!',expr:this.parseUnary()};}
    if(this.check(TT.MINUS)){this.next();return{type:'UnOp',op:'-',expr:this.parseUnary()};}
    return this.parsePostfix();
  }

  parsePostfix(){
    let expr=this.parsePrimary();
    while(true){
      if(this.check(TT.LP)){
        this.next();const args=[];
        if(!this.check(TT.RP)){args.push(this.parseExpr());while(this.match(TT.COMMA))args.push(this.parseExpr());}
        this.eat(TT.RP);expr={type:'Call',callee:expr,args,line:expr.line};
      } else if(this.check(TT.LSQ)){
        this.next();const idx=this.parseExpr();this.eat(TT.RSQ);
        expr={type:'Index',target:expr,idx,line:expr.line};
      } else if(this.check(TT.DOT)){
        this.next();const prop=this.eat(TT.IDENT).value;
        expr={type:'Prop',target:expr,prop,line:expr.line};
      } else break;
    }
    return expr;
  }

  parsePrimary(){
    const t=this.peek();
    if(this.check(TT.NUM)) {this.next();return{type:'Lit',value:t.value,line:t.line};}
    if(this.check(TT.STR)) {this.next();return{type:'StrLit',value:t.value,line:t.line};}
    if(this.check(TT.BOOL)){this.next();return{type:'Lit',value:t.value,line:t.line};}
    if(this.check(TT.NULL)){this.next();return{type:'Lit',value:null,line:t.line};}
    if(this.check(TT.HEXC)){this.next();return{type:'StrLit',value:t.value,line:t.line};}
    if(this.check(TT.IDENT)){this.next();return{type:'Ident',name:t.value,line:t.line};}
    if(this.check(TT.NS)){this.next();const ns=t.value;this.eat(TT.DOT);const meth=this.eat(TT.IDENT).value;return{type:'NSCall',ns,meth,line:t.line};}
    if(this.check(TT.LP)){this.next();const e=this.parseExpr();this.eat(TT.RP);return e;}
    if(this.check(TT.LSQ)){
      this.next();const els=[];
      if(!this.check(TT.RSQ)){els.push(this.parseExpr());while(this.match(TT.COMMA))els.push(this.parseExpr());}
      this.eat(TT.RSQ);return{type:'Arr',elements:els,line:t.line};
    }
    if(this.check(TT.LB)){
      this.next();const pairs=[];
      while(!this.check(TT.RB)&&!this.check(TT.EOF)){
        let key;if(this.check(TT.STR))key=this.next().value;else key=this.eat(TT.IDENT).value;
        this.eat(TT.COLON);const val=this.parseExpr();
        pairs.push({key,val});this.match(TT.COMMA);
      }
      this.eat(TT.RB);return{type:'ObjLit',pairs,line:t.line};
    }
    throw new ParseError(`Неожиданный токен '${t?.type}'${t?.value!=null?` '${t.value}'`:''}`,t);
  }
}

module.exports={Parser,ParseError};
