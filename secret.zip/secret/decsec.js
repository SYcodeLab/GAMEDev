#!/usr/bin/env node
'use strict';
// ══════════════════════════════════════════════════════════════════════════════
//  decSec OS  —  SWX Language Terminal  v6.0
//
//  USAGE:
//    node decsec.js                    → interactive REPL
//    node decsec.js script.swx         → run file
//    node decsec.js -e "emit 42"       → inline eval
//    node decsec.js --watch script.swx → auto-rerun on file change
//    node decsec.js --check script.swx → syntax check only
//    node decsec.js --version          → print version
//    node decsec.js --no-color         → disable ANSI colors
// ══════════════════════════════════════════════════════════════════════════════

const readline = require('readline');
const fs       = require('fs');
const os       = require('os');
const path     = require('path');
const { Interpreter } = require('./src/interpreter');
const { Lexer }       = require('./src/lexer');
const { Parser }      = require('./src/parser');

const VERSION = '6.0.0';

// ── Parse CLI flags early ──────────────────────────────────────────────────
const rawArgv  = process.argv.slice(2);
const NO_COLOR = rawArgv.includes('--no-color') || !!process.env.NO_COLOR || !process.stdout.isTTY;

// ══════════════════════════════════════════════════════════════════════════════
//  ANSI + COLOR UTILS
// ══════════════════════════════════════════════════════════════════════════════

const A = {
  reset:'\x1b[0m', bold:'\x1b[1m', dim:'\x1b[2m', under:'\x1b[4m',
  black:'\x1b[30m', red:'\x1b[31m', green:'\x1b[32m', yellow:'\x1b[33m',
  blue:'\x1b[34m', magenta:'\x1b[35m', cyan:'\x1b[36m', white:'\x1b[37m',
  bblack:'\x1b[90m', bred:'\x1b[91m', bgreen:'\x1b[92m', byellow:'\x1b[93m',
  bblue:'\x1b[94m', bmagenta:'\x1b[95m', bcyan:'\x1b[96m', bwhite:'\x1b[97m',
  bgblack:'\x1b[40m', bgred:'\x1b[41m', bggreen:'\x1b[42m', bgblue:'\x1b[44m',
  bgcyan:'\x1b[46m', bgmagenta:'\x1b[45m',
};

const c  = NO_COLOR ? (_, s) => s : (col, s) => (A[col] || '') + s + A.reset;
const cc = NO_COLOR
  ? (...pairs) => pairs.map(([, s]) => s).join('')
  : (...pairs) => pairs.map(([col, s]) => (A[col] || '') + s).join('') + A.reset;

const W  = () => process.stdout.columns || 80;
const hr = (ch, n) => (ch || '─').repeat(Math.max(1, Math.min(n || W(), W())));

// ══════════════════════════════════════════════════════════════════════════════
//  SYNTAX HIGHLIGHTER  (terminal ANSI)
// ══════════════════════════════════════════════════════════════════════════════

const SWX_KW = new Set(['set','emit','def','when','else','loop','foreach','in','ret','import',
  'export','render','shell','try','catch','throw','break','next','and','or','not','true','false','null']);
const SWX_BT = new Set(['sha256','sha512','sha1','md5','sha3','hmac','aes_enc','aes_dec','rsa_keys',
  'rsa_sign','rsa_verify','hex','unhex','base64','unbase64','xor','caesar','rot13','vigenere',
  'genkey','geniv','uuid','entropy','crc32','pwd_strength','token_create','token_verify',
  'len','str','num','type','print','emit','keys','values','entries','has_key','merge',
  'floor','ceil','round','abs','sqrt','pow','log','rand','randf','max','min','clamp',
  'upper','lower','trim','split','join','replace','includes','starts','ends','slice',
  'repeat','pad','padr','chars','lines','push','pop','shift','unshift','reverse','sort',
  'flat','unique','contains','first','last','range','chunk','zip','time','date','datetime',
  'timestamp','fs_read','fs_write','fs_exists','fs_list','fs_stat','fs_mkdir','fs_delete',
  'env_get','env_set','args','platform','pid','exit','format','regex_test','regex_match']);

function highlightLine(line) {
  if (NO_COLOR) return line;
  let out = '', i = 0;
  while (i < line.length) {
    if ((line[i]==='#'&&line[i+1]==='#')||(line[i]==='/'&&line[i+1]==='/')) {
      out += A.bblack + line.slice(i) + A.reset; break;
    }
    if (line[i]==='"'||line[i]==="'"||line[i]==='`') {
      const q=line[i]; let s=q; i++;
      while(i<line.length&&line[i]!==q){if(line[i]==='\\')s+=line[i++];s+=line[i++];}
      s+=(line[i++]||'');
      out+=A.yellow+s.replace(/\{([a-zA-Z_$]\w*)\}/g,(_,n)=>A.reset+A.byellow+'{'+n+'}'+A.reset+A.yellow)+A.reset;
      continue;
    }
    if(/[0-9]/.test(line[i])){
      let n='';while(i<line.length&&/[0-9a-fA-FxXbB_.]/.test(line[i]))n+=line[i++];
      out+=A.bmagenta+n+A.reset;continue;
    }
    if(/[a-zA-Z_$]/.test(line[i])){
      let w='';while(i<line.length&&/[a-zA-Z0-9_$]/.test(line[i]))w+=line[i++];
      if(SWX_KW.has(w))out+=A.bcyan+w+A.reset;
      else if(SWX_BT.has(w))out+=A.bblue+w+A.reset;
      else out+=A.bwhite+w+A.reset;continue;
    }
    if('=!<>&|+-*/%^~'.includes(line[i])){out+=A.cyan+line[i]+A.reset;i++;continue;}
    if('(){}[]'.includes(line[i])){out+=A.bblack+line[i]+A.reset;i++;continue;}
    out+=A.bblack+line[i]+A.reset;i++;
  }
  return out;
}

function highlightSrc(src) {
  return src.split('\n').map((ln, i) =>
    cc(['bblack', String(i+1).padStart(4)+' │ '])+highlightLine(ln)
  ).join('\n');
}

// ══════════════════════════════════════════════════════════════════════════════
//  BANNER  v6
// ══════════════════════════════════════════════════════════════════════════════

const BANNER = (() => {
  const logo=[
    '  ██████╗ ███████╗ ██████╗███████╗███████╗ ██████╗ ',
    '  ██╔══██╗██╔════╝██╔════╝██╔════╝██╔════╝██╔════╝ ',
    '  ██║  ██║█████╗  ██║     ███████╗█████╗  ██║      ',
    '  ██║  ██║██╔══╝  ██║     ╚════██║██╔══╝  ██║      ',
    '  ██████╔╝███████╗╚██████╗███████║███████╗╚██████╗ ',
    '  ╚═════╝ ╚══════╝ ╚═════╝╚══════╝╚══════╝ ╚═════╝ ',
  ];
  const cols=['bcyan','bcyan','cyan','cyan','bblack','bblack'];
  const lines=logo.map((ln,i)=>c(cols[i],ln));
  const info=[
    cc(['bblack','  '],['bblack',hr('─',50)]),
    cc(['bblack','  ▸ '],['cyan','SWX Language '],['bblack',`v${VERSION}`],['bblack','  ·  '],['bblack','Shadow Web eXploit Runtime']),
    cc(['bblack','  ▸ '],['bblack','Node.js '],['bgreen',process.version],['bblack','  ·  '],['bblack',process.platform],['bblack','  ·  '],['bblack',`pid ${process.pid}`]),
    cc(['bblack','  ▸ '],['bblack','Type '],['cyan',':help'],['bblack',' for reference  ·  '],['bblack','Ctrl+D to exit']),
    cc(['bblack','  '],['bblack',hr('─',50)]),
  ];
  return '\n'+lines.join('\n')+'\n'+info.join('\n')+'\n';
})();

// ══════════════════════════════════════════════════════════════════════════════
//  HELP  (sections)
// ══════════════════════════════════════════════════════════════════════════════

function buildHelp(section) {
  const sep = () => c('bcyan', hr('━'));
  const H = {
    lang: `
${sep()}
${c('bcyan','  SWX LANGUAGE QUICK REFERENCE')}
${c('bblack',hr('─'))}
${c('byellow','  VARIABLES')}
  set x = 42              set name = "hi {x}"      set a = [1,2,3]
  set o = { k: "val" }    x = x + 1                x += 10  x -= 5

${c('byellow','  OUTPUT')}
  emit "result: {x}"      print(val)

${c('byellow','  CONTROL FLOW')}
  when x > 0 { ... } else when x == 0 { ... } else { ... }
  loop 5 { emit _i }          ## _i = 0..4, _n = 5
  foreach item in arr { }     ## _i = index
  break   next                ## loop control

${c('byellow','  FUNCTIONS')}
  def add(a, b) { ret a + b }
  set r = add(3, 4)

${c('byellow','  ERROR HANDLING')}
  try { ... } catch(err) { emit "Error: {err}" }
  throw "message"

${c('byellow','  MODULES')}
  import "stdlib"           import "./mylib"

${c('byellow','  HTML RENDERING')}
  render "out.html" {
      style { ".cls { color: red }" }
      h1 { "Title" }
      div.card(id="x") { p { "text" } }
  }

${c('byellow','  SHELL')}
  shell "ls -la"            shell "git log --oneline -5"

${c('byellow','  OPERATORS')}
  + - * / % **              && || !              & | ^ ~ << >>
  == != < > <= >=           += -= *= /=
${c('bblack',hr('─'))}
  ${c('bblack',':help crypto   :help fs   :help math   :help str   :help arr   :help repl')}
${sep()}`,

    crypto: `
${sep()}
${c('bcyan','  SWX CRYPTO REFERENCE')}
${c('bblack',hr('─'))}
${c('byellow','  HASHES')}
  sha256(s)   sha512(s)   sha1(s)   md5(s)   sha3(s)   ripemd160(s)

${c('byellow','  MAC / SIGNATURES')}
  hmac(key, msg)           → HMAC-SHA256
  hmac(key, msg, "sha512") → HMAC-SHA512
  rsa_keys([bits])         → {pub, priv}  (default 2048)
  rsa_sign(data, priv)     → hex signature
  rsa_verify(data, sig, pub) → bool

${c('byellow','  SYMMETRIC ENCRYPTION')}
  aes_enc(text, key)       → "iv:ciphertext"  (AES-256-CBC)
  aes_dec(cipher, key)     → plaintext

${c('byellow','  ENCODING')}
  hex(s)   unhex(h)   base64(s)   unbase64(b)   base64url(s)

${c('byellow','  CLASSICAL CIPHERS')}
  xor(msg, key)   caesar(s, n)   rot13(s)   vigenere(text, key)

${c('byellow','  UTILS')}
  genkey([n])     → n-char hex key (default 32)
  geniv()         → 16-byte hex IV
  randbytes(n)    → n-byte hex
  uuid()          → UUID v4
  entropy(s)      → Shannon entropy (bits/char)
  crc32(s)        → CRC-32 hex
  pwd_strength(p) → VERY WEAK / WEAK / MEDIUM / STRONG / VERY STRONG
  token_create(obj, secret [, ttlSec])  → signed JWT-like token
  token_verify(tok, secret) → {valid, payload}
${sep()}`,

    fs: `
${sep()}
${c('bcyan','  SWX FILESYSTEM REFERENCE')}
${c('bblack',hr('─'))}
  fs_read(path)            → string content
  fs_write(path, data)     → bool
  fs_append(path, data)    → bool
  fs_exists(path)          → bool
  fs_list([dir])           → array of filenames
  fs_stat(path)            → {size, isFile, isDir, mtime}
  fs_mkdir(path)           → bool  (recursive)
  fs_delete(path)          → bool
${sep()}`,

    math: `
${sep()}
${c('bcyan','  SWX MATH REFERENCE')}
${c('bblack',hr('─'))}
  floor ceil round abs sqrt cbrt pow log log2 log10 sin cos tan
  max min clamp rand randf even odd
  PI   E   PHI   Infinity   NaN
  hex_to_dec  dec_to_hex  dec_to_bin  dec_to_oct  bin_to_dec
${sep()}`,

    str: `
${sep()}
${c('bcyan','  SWX STRING REFERENCE')}
${c('bblack',hr('─'))}
  len upper lower trim triml trimr split join replace replace1
  includes starts ends index_of slice repeat pad padr
  chars lines words count format regex_test regex_match
  "str".upper()  "str".trim()  "str".sha256()   ## method style
${sep()}`,

    arr: `
${sep()}
${c('bcyan','  SWX ARRAY REFERENCE')}
${c('bblack',hr('─'))}
  push pop shift unshift reverse sort flat flatten unique
  contains index_of first last nth slice chunk zip range
  map_fn(arr,"fn")  filter_fn(arr,"fn")  reduce_fn(arr,"fn",init)
  arr.push(v)  arr.pop()  arr.join(",")  arr.length   ## method style
  keys values entries has_key merge delete_key from_entries
${sep()}`,

    repl: `
${sep()}
${c('bcyan','  REPL COMMANDS  v6')}
${c('bblack',hr('─'))}
  ${c('cyan',':help [section]')}     section: lang crypto fs math str arr repl
  ${c('cyan',':run  <file>')}       run .swx file, preserve state
  ${c('cyan',':reload')}            re-run last :run file
  ${c('cyan',':load <file>')}       load file into current context
  ${c('cyan',':watch <file>')}      watch & auto-rerun on save (Ctrl+C stops)
  ${c('cyan',':check <file>')}      syntax-check only (no execution)
  ${c('cyan',':new  <name>')}       create new .swx file with template
  ${c('cyan',':cat  <file>')}       print file with syntax highlight + line numbers
  ${c('cyan',':edit <file>')}       open in $EDITOR (nano/vi fallback)
  ${c('cyan',':tokens <code>')}     show lexer token stream
  ${c('cyan',':ast <code>')}        show parsed AST (JSON)
  ${c('cyan',':time <code>')}       measure execution time (µs/ms)
  ${c('cyan',':bench <N> <code>')}  benchmark N runs — avg/min/max
  ${c('cyan',':doc <fn>')}          docs for builtin function
  ${c('cyan',':vars')}              list variables with types + values
  ${c('cyan',':fns')}               list user-defined functions
  ${c('cyan',':types')}             type summary of current vars
  ${c('cyan',':export <var>')}      print variable as JSON
  ${c('cyan',':import_json <f>')}   load JSON file as SWX variable
  ${c('cyan',':history [n]')}       show last n commands (default 20)
  ${c('cyan',':ls [dir]')}          list directory
  ${c('cyan',':ll [dir]')}          long listing with sizes and dates
  ${c('cyan',':pwd')}               current directory
  ${c('cyan',':cd <dir>')}          change directory
  ${c('cyan',':clear')}             clear screen
  ${c('cyan',':reset')}             reset interpreter (clear all vars/fns)
  ${c('cyan',':version')}           version info
  ${c('cyan',':exit')}              quit
${c('bblack',hr('─'))}
  ${c('bblack','Tab')} autocomplete  ${c('bblack','↑↓')} history  ${c('bblack','Ctrl+C')} cancel/exit  ${c('bblack','Ctrl+D')} quit
  ${c('bblack','~/.swxrc')} auto-loaded on startup  ${c('bblack','~/.swx_history')} persisted
  ${c('bblack','Auto-print:')} single expressions return their value inline
${sep()}`,
  };
  return H[section] || H['lang'];
}

// ══════════════════════════════════════════════════════════════════════════════
//  BUILTIN DOCS
// ══════════════════════════════════════════════════════════════════════════════

const BUILTIN_DOCS = {
  sha256:'sha256(s) → SHA-256 hex hash',
  sha512:'sha512(s) → SHA-512 hex hash',
  sha3:'sha3(s) → SHA3-256 hex hash',
  md5:'md5(s) → MD5 hex hash',
  hmac:'hmac(key, msg [, algo]) → HMAC hex  (default algo: "sha256")',
  aes_enc:'aes_enc(text, key) → AES-256-CBC encrypted "iv:ciphertext"',
  aes_dec:'aes_dec(cipher, key) → decrypted plaintext',
  rsa_keys:'rsa_keys([bits]) → {pub, priv} PEM key pair  (default 2048)',
  rsa_sign:'rsa_sign(data, privKey) → hex RSA-SHA256 signature',
  rsa_verify:'rsa_verify(data, sig, pubKey) → bool',
  genkey:'genkey([n]) → random hex key, n chars  (default 32)',
  uuid:'uuid() → UUID v4 string',
  entropy:'entropy(s) → Shannon entropy bits/char (float)',
  base64:'base64(s) → base64 encoded string',
  unbase64:'unbase64(s) → base64 decoded string',
  hex:'hex(s) → UTF-8 bytes as lowercase hex string',
  unhex:'unhex(h) → hex string decoded to UTF-8',
  xor:'xor(msg, key) → XOR cipher, returns hex ciphertext',
  caesar:'caesar(s, n) → Caesar cipher shift n positions',
  rot13:'rot13(s) → ROT-13 substitution cipher',
  vigenere:'vigenere(text, key) → Vigenère cipher',
  crc32:'crc32(s) → CRC-32 checksum as 8-char hex',
  pwd_strength:'pwd_strength(p) → VERY WEAK / WEAK / MEDIUM / STRONG / VERY STRONG',
  token_create:'token_create(obj, secret [, ttlSec]) → signed SWX token string',
  token_verify:'token_verify(tok, secret) → {valid:bool, payload|error}',
  len:'len(s|arr) → length of string or array',
  str:'str(v) → convert any value to string',
  num:'num(v) → convert to number (parseFloat)',
  int:'int(v) → convert to integer (Math.trunc)',
  type:'type(v) → "string"|"number"|"boolean"|"array"|"object"|"null"',
  rand:'rand(min, max) → random integer in [min, max] inclusive',
  randf:'randf(min, max) → random float in [min, max]',
  range:'range(start, end [, step]) → array of numbers',
  push:'push(arr, val) → mutates arr, appends val, returns arr',
  pop:'pop(arr) → removes and returns last element',
  split:'split(str, sep) → array of substrings split by sep',
  join:'join(arr [, sep]) → concatenates elements with separator',
  upper:'upper(s) → uppercase string',
  lower:'lower(s) → lowercase string',
  trim:'trim(s) → remove leading/trailing whitespace',
  includes:'includes(str, sub) → bool  (also works on arrays)',
  format:'format(tpl, v1, v2, …) → replace {} in template with values in order',
  map_fn:'map_fn(arr, "fnName") → transform each element with user function',
  filter_fn:'filter_fn(arr, "fnName") → keep elements where fn returns truthy',
  reduce_fn:'reduce_fn(arr, "fnName", init) → fold array to single value',
  fs_read:'fs_read(path) → file contents as string',
  fs_write:'fs_write(path, data) → write string to file, returns bool',
  fs_list:'fs_list([dir]) → array of filenames in directory',
  fs_stat:'fs_stat(path) → {size, isFile, isDir, mtime}',
  time:'time() → current time HH:MM:SS',
  date:'date() → current date DD/MM/YYYY',
  timestamp:'timestamp() → Unix timestamp milliseconds',
  env_get:'env_get(key) → OS environment variable value or null',
  platform:'platform() → "linux" | "darwin" | "win32" etc.',
  exit:'exit([code]) → terminate process with exit code (default 0)',
};

// ══════════════════════════════════════════════════════════════════════════════
//  OUTPUT FORMATTER
// ══════════════════════════════════════════════════════════════════════════════

function colorOutput(line) {
  const s = String(line);
  if (/^\[ERR\]|^\[error\]|^Parse error|^Lex error/.test(s)) return c('bred', s);
  if (/^\[render\]/.test(s))  return c('cyan', s);
  if (/^\[shell /.test(s))    return c('yellow', s);
  if (/^\[warn\]/.test(s))    return c('byellow', s);
  if (/^\[ok\]/.test(s))      return c('bgreen', s);
  return c('bwhite', s);
}

function prettyVal(v, depth) {
  depth = depth || 0;
  if (v === null || v === undefined) return c('bblack', 'null');
  if (typeof v === 'boolean')  return c('bcyan', v ? 'true' : 'false');
  if (typeof v === 'number')   return c('bmagenta', String(v));
  if (typeof v === 'string') {
    if (v.length > 200) return c('yellow', '"' + v.slice(0, 200) + '…"');
    return c('yellow', '"' + v + '"');
  }
  if (Array.isArray(v)) {
    if (!v.length) return c('bblack', '[]');
    if (depth >= 2) return c('bblack', `[…${v.length}]`);
    const items  = v.slice(0, 20).map(x => prettyVal(x, depth + 1));
    const suffix = v.length > 20 ? c('bblack', `, …+${v.length - 20}`) : '';
    return c('bblack','[')+items.join(c('bblack',', '))+suffix+c('bblack',']');
  }
  if (typeof v === 'object') {
    const keys = Object.keys(v);
    if (!keys.length) return c('bblack', '{}');
    if (depth >= 2) return c('bblack', `{…${keys.length}}`);
    const pairs  = keys.slice(0, 10).map(k => c('bblue',k)+c('bblack',': ')+prettyVal(v[k], depth+1));
    const suffix = keys.length > 10 ? c('bblack', `, …+${keys.length-10}`) : '';
    return c('bblack','{ ')+pairs.join(c('bblack',', '))+suffix+c('bblack',' }');
  }
  return String(v);
}

// ══════════════════════════════════════════════════════════════════════════════
//  ERROR CONTEXT DISPLAY
// ══════════════════════════════════════════════════════════════════════════════

function showErrorContext(src, line, col, errMsg) {
  const lines = src.split('\n');
  const lo    = Math.max(0, (line||1) - 3);
  const hi    = Math.min(lines.length - 1, (line||1) + 1);
  let out = c('bred', `\n  ✗ ${errMsg}\n`);
  for (let i = lo; i <= hi; i++) {
    const ln    = i + 1;
    const isErr = ln === (line||1);
    const pfx   = isErr ? c('bred', `  ${String(ln).padStart(4)} ▶ `) : c('bblack', `  ${String(ln).padStart(4)} │ `);
    out += pfx + (isErr ? c('bwhite', lines[i]) : c('bblack', lines[i])) + '\n';
    if (isErr && col) out += c('bred', '       ' + ' '.repeat(col - 1) + '^\n');
  }
  return out;
}

// ══════════════════════════════════════════════════════════════════════════════
//  FILE TEMPLATE
// ══════════════════════════════════════════════════════════════════════════════

function fileTemplate(name) {
  return `## ${name}
## decSec SWX v${VERSION}
## Created: ${new Date().toISOString()}

## ── Your code below ──────────────────────────────────────

emit "Hello from SWX {VERSION}"
`;
}

// ══════════════════════════════════════════════════════════════════════════════
//  REPL  v6
// ══════════════════════════════════════════════════════════════════════════════

class REPL {
  constructor() {
    this.cwd        = process.cwd();
    this.interp     = this._makeInterp();
    this.buffer     = [];
    this.depth      = 0;
    this.inStr      = false;
    this.rl         = null;
    this.watchTimer = null;
    this.lastFile   = null;
  }

  _makeInterp() {
    return new Interpreter({
      cwd:    this.cwd,
      output: line => process.stdout.write(colorOutput(String(line)) + '\n'),
    });
  }

  // ── Prompt ──────────────────────────────────────────────────────
  _prompt() {
    if (this.depth > 0) {
      return cc(['bblack', '  '.repeat(Math.min(this.depth, 4))], ['bblack', `(${this.depth}) `], ['bcyan', '┆ ']);
    }
    return cc(
      ['bblack', ' ['],
      ['bcyan',  'swx'],
      ['bblack', '@'],
      ['bgreen', 'decSec'],
      ['bblack', ':'],
      ['byellow', path.basename(this.cwd)],
      ['bblack', '] '],
      ['bcyan',  '❯ '],
    );
  }

  // ── Output helpers ───────────────────────────────────────────────
  _w(s)    { process.stdout.write(s); }
  _wl(s)   { process.stdout.write(s + '\n'); }
  _ok(s)   { this._wl(cc(['bblack','  '],['bgreen','✓ '],['bwhite',s])); }
  _err(s)  { this._wl(cc(['bblack','  '],['bred',  '✗ '],['bwhite',s])); }
  _info(s) { this._wl(cc(['bblack','  '],['bcyan', '▸ '],['bblack',s])); }
  _warn(s) { this._wl(cc(['bblack','  '],['byellow','⚠ '],['bblack',s])); }
  _dim(s)  { this._wl(c('bblack', '  ' + s)); }

  // ── Command router ───────────────────────────────────────────────
  _cmd(line) {
    const parts = line.trim().slice(1).trim().split(/\s+/);
    const cmd   = parts[0];
    const arg   = parts.slice(1).join(' ');

    switch (cmd) {

      case 'help': case 'h': case '?':
        this._w(buildHelp(arg || 'lang'));
        break;

      case 'clear': case 'cls':
        this._w('\x1b[2J\x1b[H');
        break;

      case 'version': case 'v':
        this._wl(cc(['cyan','  decSec SWX '],['bwhite',`v${VERSION}`],['bblack','  Node.js '],['bgreen',process.version],['bblack','  '],['bblack',process.platform]));
        break;

      case 'exit': case 'quit': case 'q':
        this._saveHistory();
        this._wl('\n' + c('bblack', '  Goodbye. decSec out.'));
        process.exit(0);
        break;

      case 'reset':
        this.interp = this._makeInterp();
        this._ok('Interpreter reset — fresh state');
        break;

      case 'run': case 'r': {
        const fp = this._resolveSWX(arg);
        if (!fp) break;
        this.lastFile = fp;
        this._runFile(fp, true);
        break;
      }

      case 'reload': {
        if (!this.lastFile) { this._warn('No file loaded yet. Use :run <file>'); break; }
        this._runFile(this.lastFile, true);
        break;
      }

      case 'load': case 'l': {
        const fp = this._resolveSWX(arg);
        if (!fp) break;
        const src = fs.readFileSync(fp, 'utf8');
        try { this.interp.exec(src, null, fp); this._ok(`Loaded: ${path.basename(fp)}`); }
        catch (e) { this._printErr(e, src); }
        break;
      }

      case 'watch': case 'w': {
        const fp = this._resolveSWX(arg);
        if (!fp) break;
        this.lastFile = fp;
        this._watchFile(fp);
        break;
      }

      case 'check': {
        const fp = this._resolveSWX(arg);
        if (!fp) break;
        const src = fs.readFileSync(fp, 'utf8');
        try {
          const toks = new Lexer(src).tokenize();
          new Parser(toks).parseProgram();
          this._ok(`Syntax OK  (${toks.length} tokens, ${src.split('\n').length} lines)`);
        } catch (e) { this._printErr(e, src); }
        break;
      }

      case 'cat': case 'show': {
        const fp = this._resolveSWX(arg);
        if (!fp) break;
        const src = fs.readFileSync(fp, 'utf8');
        const lns = src.split('\n');
        this._wl(c('bblack', `\n  ── ${path.basename(fp)} (${lns.length} lines, ${src.length} bytes) ──`));
        this._wl(highlightSrc(src));
        this._wl(c('bblack', '  ── EOF ──'));
        break;
      }

      case 'new': case 'n': {
        if (!arg) { this._warn('Usage: :new <filename>'); break; }
        const fname = arg.endsWith('.swx') ? arg : arg + '.swx';
        const fpath = path.resolve(this.cwd, fname);
        if (fs.existsSync(fpath)) { this._warn(`File exists: ${fname}  (use :edit to open)`); break; }
        fs.writeFileSync(fpath, fileTemplate(fname), 'utf8');
        this._ok(`Created: ${fpath}`);
        break;
      }

      case 'edit': case 'e': {
        const fp = this._resolveSWX(arg);
        if (!fp) break;
        const editor = process.env.EDITOR || process.env.VISUAL || (process.platform === 'win32' ? 'notepad' : 'nano');
        const { spawnSync } = require('child_process');
        this.rl.pause();
        process.stdout.write('\n');
        spawnSync(editor, [fp], { stdio: 'inherit' });
        this.rl.resume();
        this._ok(`Returned from ${editor}`);
        break;
      }

      case 'tokens': case 'tok': {
        if (!arg) { this._warn('Usage: :tokens <swx code>'); break; }
        try {
          const toks = new Lexer(arg).tokenize();
          this._wl(c('bblack', '\n  Token stream:'));
          toks.forEach(t => {
            if (t.type === 'EOF') return;
            const val = t.value !== null ? c('yellow', ` ${JSON.stringify(t.value)}`) : '';
            this._wl(cc(['bblack','  '],['bcyan', t.type.padEnd(12)],['bblack', ` L${t.line}:C${t.col}`]) + val);
          });
          this._dim(`${toks.length - 1} tokens`);
        } catch (e) { this._err(e.message); }
        break;
      }

      case 'ast': case 'a': {
        if (!arg) { this._warn('Usage: :ast <swx code>'); break; }
        try {
          const toks = new Lexer(arg).tokenize();
          const ast  = new Parser(toks).parseProgram();
          this._wl(c('bblack', JSON.stringify(ast, null, 2)));
        } catch (e) { this._err(e.message); }
        break;
      }

      case 'time': case 't': {
        if (!arg) { this._warn('Usage: :time <swx code>'); break; }
        const t0 = process.hrtime.bigint();
        try { this.interp.exec(arg); } catch (e) { this._printErr(e, arg); }
        const ns = process.hrtime.bigint() - t0;
        this._wl(cc(['bblack','  ⏱  '],['bcyan',`${Number(ns/1000n).toLocaleString()}µs`],['bblack','  ('],['bblack',`${Number(ns/1_000_000n)}ms`],['bblack',')']));
        break;
      }

      case 'bench': case 'b': {
        const m = arg.match(/^(\d+)\s+(.+)$/s);
        if (!m) { this._warn('Usage: :bench <N> <swx code>'); break; }
        const N = Math.min(parseInt(m[1]), 100_000);
        const src = m[2];
        const times = [];
        this._dim(`Benchmarking × ${N}…`);
        for (let i = 0; i < N; i++) {
          const t0 = process.hrtime.bigint();
          try { this.interp.exec(src); }
          catch (e) { this._printErr(e, src); break; }
          times.push(Number(process.hrtime.bigint() - t0));
        }
        if (!times.length) break;
        const avg = times.reduce((a,b)=>a+b,0) / times.length;
        const mn  = Math.min(...times);
        const mx  = Math.max(...times);
        this._wl(cc(
          ['bblack','  '],['byellow','avg '],['bcyan',`${Math.round(avg/1000)}µs`],
          ['bblack','  '],['bgreen','min '],['bcyan',`${Math.round(mn/1000)}µs`],
          ['bblack','  '],['bred','max '],['bcyan',`${Math.round(mx/1000)}µs`],
          ['bblack',`  × ${N}`]));
        break;
      }

      case 'doc': case 'docs': {
        if (!arg) { this._warn('Usage: :doc <function_name>'); break; }
        const doc = BUILTIN_DOCS[arg];
        if (doc) {
          this._wl(cc(['bblack','\n  '],['bcyan',arg],['bblack',':\n    ']));
          this._wl(cc(['bblack','    '],['bwhite',doc]));
        } else {
          const fn = this.interp.userFns[arg];
          if (fn) this._wl(cc(['bblack','\n  user def '],['bgreen',arg],['bblack','('],['byellow',fn.params.join(', ')],['bblack',')']));
          else this._warn(`No docs for '${arg}' — try :help`);
        }
        break;
      }

      case 'vars': {
        const SKIP = new Set(['true','false','null','PI','E','PHI','VERSION','LANG','Infinity','NaN']);
        const entries = Object.entries(this.interp.globals.vars).filter(([k])=>!SKIP.has(k));
        if (!entries.length) { this._dim('(no user variables)'); break; }
        this._wl(c('bblack', `\n  ${'Name'.padEnd(18)} ${'Type'.padEnd(12)} Value`));
        this._wl(c('bblack', `  ${'─'.repeat(18)} ${'─'.repeat(12)} ${'─'.repeat(28)}`));
        entries.forEach(([k, v]) => {
          const t = Array.isArray(v) ? `array[${v.length}]` : v===null ? 'null' : typeof v;
          this._wl(cc(['bblack','  '],['cyan',k.padEnd(18)],['bblack',t.padEnd(12)],' ')+prettyVal(v));
        });
        break;
      }

      case 'fns': {
        const fns = Object.entries(this.interp.userFns);
        if (!fns.length) { this._dim('(no user functions)'); break; }
        this._wl(c('bblack','\n  User-defined functions:'));
        fns.forEach(([name, fn]) => {
          this._wl(cc(['bblack','  '],['cyan','def '],['bwhite',name],['bblack','('],['byellow',fn.params.join(', ')],['bblack',')']));
        });
        break;
      }

      case 'types': {
        const SKIP = new Set(['true','false','null','PI','E','PHI','VERSION','LANG','Infinity','NaN']);
        const entries = Object.entries(this.interp.globals.vars).filter(([k])=>!SKIP.has(k));
        const sum = {};
        entries.forEach(([,v])=>{ const t=Array.isArray(v)?'array':v===null?'null':typeof v; sum[t]=(sum[t]||0)+1; });
        if (!Object.keys(sum).length) { this._dim('(no user variables)'); break; }
        this._wl(c('bblack','\n  Variable types:'));
        Object.entries(sum).forEach(([t,n])=>this._wl(cc(['bblack','  '],['cyan',t.padEnd(12)],['byellow',String(n)])));
        break;
      }

      case 'export': {
        if (!arg) { this._warn('Usage: :export <varName>'); break; }
        try { this._wl(c('bwhite', JSON.stringify(this.interp.globals.get(arg), null, 2))); }
        catch(e) { this._err(e.message); }
        break;
      }

      case 'import_json': {
        const p2   = arg.split(/\s+/);
        const file = p2[0];
        const vname= p2[1] || path.basename(file, path.extname(file)).replace(/[^a-zA-Z0-9_]/g,'_');
        const fp   = path.resolve(this.cwd, file);
        if (!fs.existsSync(fp)) { this._err(`File not found: ${fp}`); break; }
        try {
          const data = JSON.parse(fs.readFileSync(fp,'utf8'));
          this.interp.globals.set(vname, data);
          this._ok(`Imported JSON as '${vname}'`);
        } catch(e) { this._err('JSON error: '+e.message); }
        break;
      }

      case 'history': {
        const n    = parseInt(arg) || 20;
        const hist = (this.rl.history || []).slice(0, n).reverse();
        hist.forEach((cmd, i) => this._wl(cc(['bblack',`  ${String(i+1).padStart(4)} `],['bwhite',cmd])));
        break;
      }

      case 'ls': {
        const dir = arg ? path.resolve(this.cwd, arg) : this.cwd;
        try {
          fs.readdirSync(dir).forEach(item => {
            let stat; try{stat=fs.statSync(path.join(dir,item));}catch{}
            const isDir=stat?.isDirectory();
            const ext=path.extname(item);
            const col=isDir?'bcyan':ext==='.swx'?'bgreen':ext==='.json'?'byellow':'bwhite';
            this._wl(c(col, `  ${item}${isDir?'/':''}`));
          });
        } catch(e){ this._err(e.message); }
        break;
      }

      case 'll': {
        const dir = arg ? path.resolve(this.cwd, arg) : this.cwd;
        try {
          fs.readdirSync(dir).forEach(item => {
            let stat; try{stat=fs.statSync(path.join(dir,item));}catch{}
            const isDir=stat?.isDirectory();
            const size=stat?(isDir?'       -':String(stat.size).padStart(8)):'       ?';
            const mt  =stat?new Date(stat.mtimeMs).toISOString().slice(0,16).replace('T',' '):'';
            const ext =path.extname(item);
            const col =isDir?'bcyan':ext==='.swx'?'bgreen':ext==='.json'?'byellow':'bwhite';
            this._wl(cc(['bblack',`  ${size}  ${mt}  `],[col,item+(isDir?'/':'')]));
          });
        } catch(e){ this._err(e.message); }
        break;
      }

      case 'pwd':
        this._wl(c('cyan', '  ' + this.cwd));
        break;

      case 'cd': {
        const target = arg ? arg.replace(/^~/,os.homedir()) : os.homedir();
        const newDir = path.resolve(this.cwd, target);
        if (!fs.existsSync(newDir)) { this._err(`No such directory: ${newDir}`); break; }
        this.cwd = newDir;
        this.interp.cwd = newDir;
        this._info(`→ ${newDir}`);
        this.rl.setPrompt(this._prompt());
        break;
      }

      default:
        this._warn(`Unknown command ':${cmd}' — type :help repl`);
    }
  }

  // ── Helpers ──────────────────────────────────────────────────────
  _resolveSWX(arg) {
    if (!arg) { this._warn('Filename required'); return null; }
    const fp = path.resolve(this.cwd, arg.endsWith('.swx') ? arg : arg + '.swx');
    if (!fs.existsSync(fp)) { this._err(`File not found: ${fp}`); return null; }
    return fp;
  }

  _runFile(fp, timing) {
    const src = fs.readFileSync(fp, 'utf8');
    this._wl(c('bblack', `\n  ▶ ${path.basename(fp)}`));
    const t0 = process.hrtime.bigint();
    try { this.interp.exec(src, null, fp); }
    catch (e) { this._printErr(e, src); }
    if (timing) {
      const ms = Number((process.hrtime.bigint()-t0)/1_000_000n);
      this._wl(cc(['bblack','  ─ done in '],['bcyan',`${ms}ms`]));
    }
  }

  _printErr(e, src) {
    if (e.isSwx && e.line) process.stdout.write(showErrorContext(src, e.line, e.col, e.message));
    else this._err(e.message);
  }

  _watchFile(fp) {
    if (this.watchTimer) { clearInterval(this.watchTimer); this.watchTimer = null; }
    this._ok(`Watching: ${path.basename(fp)}  (Ctrl+C to stop)`);
    let lastMtime = 0;
    this._runFile(fp, true);
    this.watchTimer = setInterval(() => {
      try {
        const mt = fs.statSync(fp).mtimeMs;
        if (mt !== lastMtime) {
          lastMtime = mt;
          this._wl(cc(['bblack','\n  ↻ '],['bcyan',path.basename(fp)],['bblack',' changed → rerunning…']));
          this.interp = this._makeInterp();
          this._runFile(fp, true);
          this.rl.setPrompt(this._prompt());
          this.rl.prompt(true);
        }
      } catch {}
    }, 300);
  }

  _saveHistory() {
    try {
      fs.writeFileSync(
        path.join(os.homedir(), '.swx_history'),
        (this.rl.history || []).slice(0, 1000).reverse().join('\n'), 'utf8'
      );
    } catch {}
  }

  // ── Smart autocomplete ────────────────────────────────────────────
  _completer(line) {
    const CMDS = [':help',':help crypto',':help fs',':help math',':help str',':help arr',':help repl',
      ':run ',':reload',':load ',':watch ',':check ',':new ',':cat ',':edit ',
      ':tokens ',':ast ',':time ',':bench ',':doc ',
      ':vars',':fns',':types',':export ',':import_json ',':history',
      ':clear',':reset',':version',':exit',':ls',':ll',':pwd',':cd '];
    const KW   = ['set ','emit ','def ','when ','else ','loop ','foreach ','in ','ret ',
                  'import ','render ','shell ','try ','catch ','throw ','break','next'];
    const BT   = Object.keys(this.interp.builtins || {});
    const UV   = Object.keys(this.interp.globals?.vars || {});
    const UF   = Object.keys(this.interp.userFns || {});

    const all  = [...CMDS, ...KW, ...BT, ...UV, ...UF];
    const hits = all.filter(s => s.startsWith(line));
    return [hits.length ? hits : all, line];
  }

  // ── Multi-line depth tracking (string-aware) ──────────────────────
  _updateDepth(line) {
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if ((ch==='"'||ch==="'"||ch==='`') && (i===0||line[i-1]!=='\\')) this.inStr = !this.inStr;
      if (!this.inStr) {
        if (ch==='{') this.depth++;
        if (ch==='}') this.depth = Math.max(0, this.depth - 1);
      }
    }
  }

  // ── Load ~/.swxrc ────────────────────────────────────────────────
  _loadRc() {
    const rc = path.join(os.homedir(), '.swxrc');
    if (!fs.existsSync(rc)) return;
    try {
      this.interp.exec(fs.readFileSync(rc,'utf8'), null, rc);
      this._dim('Loaded ~/.swxrc');
    } catch(e) { this._warn(`~/.swxrc: ${e.message}`); }
  }

  // ── Auto-print single expression ─────────────────────────────────
  _tryAutoPrint(src) {
    try {
      const toks = new Lexer(src).tokenize();
      const ast  = new Parser(toks).parseProgram();
      if (ast.stmts.length === 1 && ast.stmts[0].type === 'ExprStmt') {
        const val = this.interp.eval(ast.stmts[0].expr, this.interp.globals);
        if (val !== null && val !== undefined) {
          this._wl(cc(['bblack','  ⟹  ']) + prettyVal(val));
          return true;
        }
      }
    } catch {}
    return false;
  }

  // ── Main REPL loop ────────────────────────────────────────────────
  start() {
    this._w(BANNER);

    this.rl = readline.createInterface({
      input:       process.stdin,
      output:      process.stdout,
      prompt:      this._prompt(),
      completer:   line => this._completer(line),
      historySize: 1000,
    });

    // Load persisted history
    const hf = path.join(os.homedir(), '.swx_history');
    if (fs.existsSync(hf)) {
      try {
        this.rl.history = fs.readFileSync(hf,'utf8').split('\n').filter(Boolean).reverse().slice(0,1000);
      } catch {}
    }

    this._loadRc();
    this.rl.prompt();

    this.rl.on('line', (line) => {
      const trimmed = line.trim();

      // REPL command
      if (this.depth === 0 && trimmed.startsWith(':')) {
        this._cmd(trimmed);
        this.rl.setPrompt(this._prompt());
        this.rl.prompt();
        return;
      }

      // Empty at top level
      if (!trimmed && this.depth === 0) {
        this.rl.prompt();
        return;
      }

      this.buffer.push(line);
      this._updateDepth(line);

      if (this.depth <= 0 && this.buffer.length > 0) {
        const src   = this.buffer.join('\n');
        this.buffer = [];
        this.depth  = 0;
        this.inStr  = false;

        // Try auto-print, else full exec
        if (!this._tryAutoPrint(src)) {
          try { this.interp.exec(src); }
          catch (e) { this._printErr(e, src); }
        }
      }

      this.rl.setPrompt(this._prompt());
      this.rl.prompt();
    });

    this.rl.on('close', () => {
      this._saveHistory();
      this._wl('\n' + c('bblack', '  Goodbye. decSec out.'));
      process.exit(0);
    });

    process.on('SIGINT', () => {
      if (this.watchTimer) {
        clearInterval(this.watchTimer); this.watchTimer = null;
        this._wl('\n' + c('bblack', '  Watch stopped'));
      } else if (this.depth > 0 || this.buffer.length > 0) {
        this.buffer = []; this.depth = 0; this.inStr = false;
        this._wl('\n' + c('bblack', '  Cancelled'));
      } else {
        this._wl('\n' + c('bblack', '  (Ctrl+D to exit)'));
      }
      this.rl.setPrompt(this._prompt());
      this.rl.prompt();
    });
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  ENTRY POINT
// ══════════════════════════════════════════════════════════════════════════════

const argv = rawArgv.filter(a => a !== '--no-color');

if (argv.includes('--version') || argv.includes('-V')) {
  console.log(`decSec SWX v${VERSION}  Node.js ${process.version}  ${process.platform}`);
  process.exit(0);
}

if (argv.includes('--help') || argv.includes('-h')) {
  console.log(buildHelp('lang'));
  process.exit(0);
}

if (argv[0] === '--check') {
  const fp = path.resolve(process.cwd(), argv[1] || '');
  if (!fs.existsSync(fp)) { console.error(`File not found: ${fp}`); process.exit(1); }
  const src = fs.readFileSync(fp, 'utf8');
  try {
    const toks = new Lexer(src).tokenize();
    new Parser(toks).parseProgram();
    console.log(c('bgreen', `✓ Syntax OK: ${fp}  (${toks.length} tokens)`));
  } catch (e) {
    process.stderr.write(showErrorContext(src, e.line, e.col, e.message));
    process.exit(1);
  }
} else if (argv[0] === '--watch') {
  const fp = path.resolve(process.cwd(), argv[1] || '');
  if (!fs.existsSync(fp)) { console.error(`File not found: ${fp}`); process.exit(1); }
  console.log(c('cyan', `  Watching: ${fp}  (Ctrl+C to stop)\n`));
  const runW = () => {
    const src    = fs.readFileSync(fp, 'utf8');
    const interp = new Interpreter({ cwd: path.dirname(fp), output: l => process.stdout.write(colorOutput(String(l))+'\n') });
    console.log(c('bblack', `\n─── ${new Date().toLocaleTimeString()} ───────────────────────`));
    try { interp.exec(src, null, fp); }
    catch (e) { process.stderr.write(showErrorContext(src, e.line, e.col, e.message)); }
  };
  runW();
  let lastMt = 0;
  setInterval(() => { try { const mt=fs.statSync(fp).mtimeMs; if(mt!==lastMt){lastMt=mt;runW();} } catch{} }, 300);
  process.on('SIGINT', () => { console.log('\n'+c('bblack','  Watch stopped')); process.exit(0); });
} else if (argv[0] === '-e' || argv[0] === '--eval') {
  const src    = argv.slice(1).join(' ');
  const interp = new Interpreter({ output: l => console.log(String(l)) });
  try { interp.exec(src); }
  catch (e) { process.stderr.write(showErrorContext(src, e.line, e.col, e.message)+'\n'); process.exit(1); }
} else if (argv[0] && !argv[0].startsWith('-')) {
  const fp = path.resolve(process.cwd(), argv[0]);
  if (!fs.existsSync(fp)) { console.error(c('bred', `File not found: ${fp}`)); process.exit(1); }
  const src    = fs.readFileSync(fp, 'utf8');
  const interp = new Interpreter({ cwd: path.dirname(fp), output: l => process.stdout.write(colorOutput(String(l))+'\n') });
  try { interp.exec(src, null, fp); }
  catch (e) { process.stderr.write(showErrorContext(src, e.line, e.col, e.message)+'\n'); process.exit(1); }
} else {
  new REPL().start();
}
