<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// --- ЛОГИКА: ДОБАВЛЕНИЕ ИСТОЧНИКА ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_source'])) {
    $name = $_POST['source_name'];
    $type = $_POST['source_type'];
    $host = $_POST['host_info'];
    
    $stmt = $pdo->prepare("INSERT INTO dq_sources (source_name, source_type, host_info, status) VALUES (?, ?, ?, 'Active')");
    $stmt->execute([$name, $type, $host]);
    header('Location: sources.php');
    exit;
}

// --- ЛОГИКА: УДАЛЕНИЕ ---
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    $pdo->prepare("DELETE FROM dq_sources WHERE id = ?")->execute([$id]);
    header('Location: sources.php');
    exit;
}

// Получаем список источников
$sources = $pdo->query("SELECT * FROM dq_sources ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Источники данных | DAMU AI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --sidebar-bg: #1a1f2b; /* Темный цвет со скриншота */
            --sidebar-hover: #242a38;
            --accent: #a78bfa; /* Светло-фиолетовый акцент */
            --text-gray: #94a3b8;
            --bg-main: #f8fafc;
        }

        body { 
            margin: 0; 
            font-family: 'Inter', sans-serif; 
            background: var(--bg-main); 
            display: flex; 
            height: 100vh; 
        }

        /* SIDEBAR В СТИЛЕ DAMU AI */
        .sidebar { 
            width: 250px; 
            background: var(--sidebar-bg); 
            color: white; 
            display: flex; 
            flex-direction: column;
            flex-shrink: 0;
        }

        .sidebar-header { 
            padding: 25px 20px; 
            font-size: 18px; 
            font-weight: 700; 
            display: flex; 
            align-items: center; 
            gap: 10px;
            letter-spacing: 0.5px;
        }

        .nav-menu { 
            display: flex; 
            flex-direction: column; 
            gap: 5px; 
            padding: 10px;
        }

        .nav-item { 
            padding: 12px 15px; 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            color: var(--text-gray); 
            text-decoration: none; 
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s ease;
        }

        .nav-item i { 
            width: 20px; 
            text-align: center;
            font-size: 16px;
        }

        .nav-item:hover { 
            background: var(--sidebar-hover); 
            color: white; 
        }

        .nav-item.active { 
            background: rgba(167, 139, 250, 0.1); 
            color: var(--accent); 
        }

        /* ОСНОВНОЙ КОНТЕНТ */
        .main-content { 
            flex-grow: 1; 
            padding: 40px; 
            overflow-y: auto; 
        }

        .page-header h1 { 
            font-size: 24px; 
            font-weight: 600; 
            color: #1e293b; 
            margin: 0 0 10px 0;
        }

        .grid-container { 
            display: grid; 
            grid-template-columns: 320px 1fr; 
            gap: 25px; 
            margin-top: 30px;
        }

        .card { 
            background: white; 
            border-radius: 12px; 
            padding: 24px; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .card h3 { 
            margin-top: 0; 
            font-size: 16px; 
            color: #334155; 
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* ТАБЛИЦА */
        .data-table { 
            width: 100%; 
            border-collapse: collapse; 
        }
        
        .data-table th { 
            text-align: left; 
            padding: 12px; 
            border-bottom: 1px solid #edf2f7; 
            color: #64748b; 
            font-size: 13px; 
            font-weight: 500;
        }

        .data-table td { 
            padding: 15px 12px; 
            border-bottom: 1px solid #f8fafc; 
            font-size: 14px;
        }

        /* ФОРМЫ */
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 13px; margin-bottom: 6px; color: #64748b; }
        .form-group input, .form-group select {
            width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 8px; box-sizing: border-box;
        }

        .btn-submit {
            width: 100%; padding: 12px; background: var(--accent); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 500;
        }

        .status-badge {
            padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 500;
        }
        .status-active { background: #dcfce7; color: #166534; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-shield-halved" style="color: var(--accent);"></i>
            <span>DAMU AI</span>
        </div>
        
        <div class="nav-menu">
            <a href="ai_dashboard.php" class="nav-item">
                <i class="fas fa-home"></i> Главная
            </a>
            <a href="ai_monitor.php" class="nav-item">
                <i class="fas fa-pen-nib"></i> AI Валидатор
            </a>
            <a href="reports.php" class="nav-item">
                <i class="fas fa-chart-bar"></i> Отчеты
            </a>
            <a href="sources.php" class="nav-item active">
                <i class="fas fa-database"></i> Источники данных
            </a>
        </div>
    </div>

    <div class="main-content">
        <div class="page-header">
            <h1>Реестр источников данных</h1>
            <p style="color: #64748b;">Управление базами данных для анализа качества.</p>
        </div>

        <div class="grid-container">
            <div class="card">
                <h3>Добавить систему</h3>
                <form method="POST">
                    <div class="form-group">
                        <label>Название системы</label>
                        <input type="text" name="source_name" required>
                    </div>
                    <div class="form-group">
                        <label>Тип СУБД</label>
                        <select name="source_type">
                            <option value="PostgreSQL">PostgreSQL</option>
                            <option value="MS SQL Server">MS SQL Server</option>
                            <option value="MySQL">MySQL</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Хост / IP</label>
                        <input type="text" name="host_info" required>
                    </div>
                    <button type="submit" name="add_source" class="btn-submit">Подключить</button>
                </form>
            </div>

            <div class="card">
                <h3><i class="fas fa-table"></i> Подключенные базы</h3>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Система</th>
                            <th>Тип</th>
                            <th>Адрес</th>
                            <th>Статус</th>
                            <th>Действие</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sources as $source): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($source['source_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($source['source_type']); ?></td>
                            <td style="font-family: monospace;"><?php echo htmlspecialchars($source['host_info']); ?></td>
                            <td><span class="status-badge status-active">Активен</span></td>
                            <td>
                                <a href="sources.php?delete_id=<?php echo $source['id']; ?>" 
                                   style="color: #ef4444;" onclick="return confirm('Удалить?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>