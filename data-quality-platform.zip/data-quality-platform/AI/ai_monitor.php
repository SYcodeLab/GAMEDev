<?php
session_start();
require_once __DIR__ . '/../config/db.php';

if (isset($_GET['reset'])) {
    unset($_SESSION['last_scan']);
    $pdo->query("UPDATE ai_anomaly_detected SET status = 'detected', fixed_at = NULL, fixed_by = NULL");
    header('Location: ai_monitor.php');
    exit;
}

$is_scanned = isset($_SESSION['last_scan']) && (time() - $_SESSION['last_scan'] < 3600);

if (isset($_GET['action']) && $_GET['action'] == 'set_scan_flag') {
    $_SESSION['last_scan'] = time();
    echo 'success'; exit;
}

$anomalies = [];
if ($is_scanned) {
    $stmt = $pdo->query("SELECT * FROM ai_anomaly_detected WHERE status = 'detected' ORDER BY detected_at DESC");
    $anomalies = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$historyCountStmt = $pdo->query("SELECT COUNT(*) FROM ai_anomaly_detected WHERE status = 'fixed'");
$fixed_total = $historyCountStmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>AI Валидатор | DAMU AI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root { --primary: #2c3e50; --accent: #8e44ad; --success: #27ae60; --warning: #f39c12; --sidebar-width: 280px; --bg-light: #f8fafc; }
        body { margin: 0; font-family: 'Inter', sans-serif; background-color: var(--bg-light); color: var(--primary); display: flex; height: 100vh; overflow: hidden; }
        .sidebar { width: var(--sidebar-width); background: #1e293b; color: white; display: flex; flex-direction: column; flex-shrink: 0; }
        .sidebar-header { padding: 30px; font-size: 22px; font-weight: 700; display: flex; align-items: center; gap: 12px; border-bottom: 1px solid rgba(255,255,255,0.05); }
        .nav-item { padding: 15px 30px; display: flex; align-items: center; gap: 15px; color: #94a3b8; text-decoration: none; transition: 0.3s; }
        .nav-item.active { border-left: 4px solid var(--accent); color: white; background: rgba(255,255,255,0.05); }
        .main-content { flex-grow: 1; display: flex; flex-direction: column; overflow-y: auto; }
        header { height: 80px; background: white; display: flex; align-items: center; justify-content: space-between; padding: 0 40px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .container { padding: 40px; max-width: 1200px; margin: 0 auto; width: 100%; box-sizing: border-box; }
        .stat-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; margin-bottom: 40px; }
        .stat-card { background: white; padding: 25px; border-radius: 16px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); border-bottom: 4px solid transparent; }
        .data-table-card { background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.02); margin-bottom: 30px; }
        .terminal { background: #0f172a; color: #38bdf8; padding: 25px; border-radius: 12px; font-family: monospace; display: none; margin-top: 20px; text-align: left; }
        .btn-start-scan { background: var(--accent); color: white; border: none; padding: 15px 30px; border-radius: 10px; cursor: pointer; font-weight: 600; }
        .diff-tag { padding: 4px 8px; border-radius: 4px; font-size: 12px; }
        .diff-old { background: #fee2e2; color: #991b1b; text-decoration: line-through; }
        .diff-new { background: #dcfce7; color: #166534; }
        .row-fade-out { transform: translateX(40px); opacity: 0; transition: 0.5s; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header"><i class="fas fa-shield-virus"></i><span>DAMU AI</span></div>
        <div class="nav-menu">
            <a href="ai_dashboard.php" class="nav-item"><i class="fas fa-home"></i> Главная</a>
            <a href="ai_monitor.php" class="nav-item active"><i class="fas fa-magic"></i> AI Валидатор</a>
            <a href="reports.php" class="nav-item"><i class="fas fa-chart-line"></i> Отчеты</a>
            <a href="sources.php" class="nav-item"><i class="fas fa-database"></i> Источники данных</a>
        </div>
    </div>

    <div class="main-content">
        <header>
            <h2 style="font-weight: 600;">Мониторинг качества данных</h2>
            <div style="font-size: 13px; color: #64748b;">Статус: <?php echo $is_scanned ? 'Просканировано' : 'Ожидание'; ?></div>
        </header>

        <div class="container">
            <?php if (!$is_scanned): ?>
                <div style="background: white; padding: 60px; border-radius: 20px; text-align: center;">
                    <i class="fas fa-microchip" id="main-icon" style="font-size: 50px; color: var(--accent); margin-bottom: 20px;"></i>
                    <h1>Запустить аудит данных?</h1>
                    <button class="btn-start-scan" id="startBtn" onclick="runAdvancedScan()">Начать сканирование</button>
                    <div class="terminal" id="terminal"><div id="terminal-content"></div></div>
                </div>
            <?php else: ?>
                <div class="stat-grid">
                    <div class="stat-card" style="border-color: var(--accent);">
                        <div style="color: #64748b;">Ошибок найдено</div>
                        <div style="font-size: 32px; font-weight: 700;" id="count-bad"><?php echo count($anomalies); ?></div>
                    </div>
                    <div class="stat-card" style="border-color: var(--success);">
                        <div style="color: #64748b;">Исправлено AI</div>
                        <div style="font-size: 32px; font-weight: 700;" id="count-fixed"><?php echo $fixed_total; ?></div>
                    </div>
                    <div class="stat-card" style="display: flex; align-items: center; justify-content: center;">
                         <a href="?reset=true" style="color: var(--accent); text-decoration: none; font-weight: 600;"><i class="fas fa-redo"></i> Сбросить данные</a>
                    </div>
                </div>

                <div class="data-table-card">
                    <div style="padding: 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center;">
                        <b style="font-size: 18px;">Выявленные аномалии</b>
                        <button onclick="fixAllAnomalies()" id="fixAllBtn" style="background: var(--success); color: white; border: none; padding: 8px 20px; border-radius: 8px; cursor: pointer; font-weight: 600;">Исправить все</button>
                    </div>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="text-align: left; background: #f8fafc; font-size: 12px; color: #64748b; text-transform: uppercase;">
                                <th style="padding: 15px;">Объект ID</th>
                                <th>Поле</th>
                                <th>Анализ ИИ (Было → Стало)</th>
                                <th style="text-align: right; padding-right: 20px;">Действие</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($anomalies as $row): ?>
                            <tr id="row-<?php echo $row['id']; ?>" style="border-top: 1px solid #eee;">
                                <td style="padding: 15px;">#<?php echo $row['entity_id']; ?></td>
                                <td><span style="background:#f1f5f9; padding: 4px 8px; border-radius: 4px; font-weight: 600; font-size: 13px;"><?php echo $row['column_name']; ?></span></td>
                                <td>
                                    <span class="diff-tag diff-old"><?php echo $row['current_value']; ?></span>
                                    <i class="fas fa-arrow-right" style="color: #ccc; font-size: 10px; margin: 0 5px;"></i>
                                    <span class="diff-tag diff-new"><?php echo $row['ai_suggestion']; ?></span>
                                </td>
                                <td style="text-align: right; padding-right: 20px;">
                                    <button class="btn-fix" onclick="fixAnomaly(<?php echo $row['id']; ?>, this)" style="border: 1px solid var(--success); background: none; color: var(--success); padding: 5px 15px; border-radius: 6px; cursor: pointer; transition: 0.2s;">Одобрить</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
    function runAdvancedScan() {
        const btn = document.getElementById('startBtn');
        const term = document.getElementById('terminal');
        const content = document.getElementById('terminal-content');
        btn.disabled = true; term.style.display = 'block';
        const steps = [
            { m: "Инициализация нейросети...", d: 500 },
            { m: "Поиск семантических аномалий...", d: 1500 },
            { m: "Валидация бизнес-логики...", d: 2500 },
            { m: "Готово! Данные обработаны.", d: 3500 }
        ];
        steps.forEach((s, i) => {
            setTimeout(() => {
                content.innerHTML += `<div>> ${s.m}</div>`;
                if (i === steps.length - 1) {
                    fetch('ai_monitor.php?action=set_scan_flag').then(() => location.reload());
                }
            }, s.d);
        });
    }

function fixAnomaly(id, btn) {
    const originalContent = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    btn.disabled = true;

    // Передаем id методом GET для максимальной совместимости
    fetch(`api.php?action=fix_one&id=${id}`)
    .then(r => r.json())
    .then(data => {
        if(data.success) {
            const row = document.getElementById('row-' + id);
            row.classList.add('row-fade-out');
            setTimeout(() => {
                row.remove();
                // Обновляем счетчики
                const countBad = document.getElementById('count-bad');
                const countFixed = document.getElementById('count-fixed');
                if(countBad) countBad.innerText = Math.max(0, parseInt(countBad.innerText) - 1);
                if(countFixed) countFixed.innerText = parseInt(countFixed.innerText) + 1;
            }, 500);
        } else {
            alert('Ошибка: ' + (data.error || 'Не удалось исправить'));
            btn.innerHTML = originalContent;
            btn.disabled = false;
        }
    })
    .catch(err => {
        console.error('Ошибка запроса:', err);
        btn.innerHTML = originalContent;
        btn.disabled = false;
    });
}

function fixAllAnomalies() {
    if(!confirm('Применить все рекомендации AI?')) return;
    const btn = document.getElementById('fixAllBtn');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Обработка...';

    fetch('api.php?action=fix_all')
    .then(r => r.json())
    .then(data => {
        if(data.success) {
            location.reload();
        }
    });
}
    </script>
</body>
</html>