<?php
session_start();
session_destroy(); // Удаляем сессию
header('Location: login.php'); // Отправляем на страницу входа
exit;