<?php
session_start();
require_once 'config/db.php';

// Проверка доступа
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// --- ЛОГИКА: ДОБАВЛЕНИЕ ПРАВИЛА ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_rule'])) {
    $name = $_POST['rule_name'];
    $desc = $_POST['description'];
    $crit = $_POST['criticality'];

    $stmt = $pdo->prepare("INSERT INTO dq_rules (rule_name, description, criticality) VALUES (?, ?, ?)");
    $stmt->execute([$name, $desc, $crit]);
    header('Location: rules.php'); 
    exit;
}

// --- ЛОГИКА: УДАЛЕНИЕ ПРАВИЛА ---
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    // Сначала удаляем логи, связанные с правилом
    $pdo->prepare("DELETE FROM dq_logs WHERE rule_id = ?")->execute([$id]);
    // Теперь удаляем само правило
    $pdo->prepare("DELETE FROM dq_rules WHERE id = ?")->execute([$id]);
    header('Location: rules.php');
    exit;
}

// Получаем список всех правил
$rules = $pdo->query("SELECT * FROM dq_rules ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Настройка правил | DAMU Quality</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <div class="top-navbar">
        <div class="logo">
            <i class="fas fa-layer-group"></i> DAMU <span style="font-weight:300; margin-left:5px;">Quality</span>
        </div>
        <div class="user-profile">
            <a href="profile.php" style="text-decoration: none; color: inherit; display: flex; align-items: center; gap: 10px;">
                <div class="avatar">
                    <?php echo mb_substr($_SESSION['user_name'] ?? 'U', 0, 1); ?>
                </div>
            </a>
            <a href="logout.php" style="margin-left:15px; color:#E74C3C;" title="Выйти из системы">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </div>

    <div class="layout">
        <div class="sidebar">
            <a href="index.php" class="nav-item"><i class="fas fa-chart-line"></i> Мониторинг качества</a>
            <a href="sources.php" class="nav-item"><i class="fas fa-database"></i> Источники данных</a>
            <a href="rules.php" class="nav-item active"><i class="fas fa-cog"></i> Настройка правил</a>
            
            <hr style="border: 0.5px solid #444; margin: 20px 0;">
            
            <a href="analytics.php" class="nav-item">
                <i class="fas fa-file-invoice-dollar"></i> 
                <span>Управленческая отчетность</span>
            </a>
        </div>

        <div class="content-area">
            <div class="page-header">
                <h1>Управление правилами проверок</h1>
                <p>Добавление и редактирование SQL-сценариев качества данных для Фонда "Даму".</p>
            </div>

            <div style="display: flex; gap: 30px;">
                
                <div class="data-card" style="flex: 1; height: fit-content;">
                    <h3><i class="fas fa-plus-circle"></i> Новое правило</h3>
                    <form method="POST">
                        <div style="margin-bottom: 15px;">
                            <label style="display:block; margin-bottom:5px; font-weight:bold;">Название проверки</label>
                            <input type="text" name="rule_name" placeholder="Например: Проверка ИИН" required 
                                   style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
                        </div>
                        
                        <div style="margin-bottom: 15px;">
                            <label style="display:block; margin-bottom:5px; font-weight:bold;">Описание / SQL логика</label>
                            <textarea name="description" placeholder="Опишите логику SQL запроса..." required rows="4"
                                      style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; font-family: sans-serif; resize: vertical;"></textarea>
                        </div>

                        <div style="margin-bottom: 20px;">
                            <label style="display:block; margin-bottom:5px; font-weight:bold;">Уровень критичности</label>
                            <select name="criticality" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">
                                <option value="Low">Low (Низкая)</option>
                                <option value="Medium" selected>Medium (Средняя)</option>
                                <option value="High">High (Высокая)</option>
                            </select>
                        </div>

                        <button type="submit" name="add_rule" class="btn-run" style="width: 100%;">Сохранить правило</button>
                    </form>
                </div>

                <div class="data-card" style="flex: 2;">
                    <h3>Реестр активных правил DQ</h3>
                    
                    

                    <table>
                        <thead>
                            <tr>
                                <th style="width: 50px;">ID</th>
                                <th>Название и логика</th>
                                <th style="width: 120px;">Критичность</th>
                                <th style="width: 100px;">Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rules as $rule): ?>
                            <tr>
                                <td style="color: #999;">#<?php echo $rule['id']; ?></td>
                                <td>
                                    <div style="font-weight: bold; color: #2c3e50;"><?php echo htmlspecialchars($rule['rule_name']); ?></div>
                                    <div style="font-size: 12px; color: #7f8c8d; margin-top: 4px; line-height: 1.4;">
                                        <?php echo htmlspecialchars($rule['description']); ?>
                                    </div>
                                </td>
                                <td>
                                    <?php 
                                        $color = '#3498db';
                                        if($rule['criticality'] == 'High') $color = '#E74C3C';
                                        if($rule['criticality'] == 'Medium') $color = '#F39C12';
                                    ?>
                                    <span style="display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; text-transform: uppercase; border: 1px solid <?php echo $color; ?>; color: <?php echo $color; ?>;">
                                        <i class="fas fa-exclamation-circle"></i> <?php echo $rule['criticality']; ?>
                                    </span>
                                </td>
                                <td style="text-align: center;">
                                    <a href="rules.php?delete_id=<?php echo $rule['id']; ?>" 
                                       onclick="return confirm('Внимание! Это удалит правило и всю историю его проверок. Продолжить?')" 
                                       style="color: #E74C3C; font-size: 16px;" title="Удалить правило">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php if (empty($rules)): ?>
                        <p style="text-align: center; color: #999; margin-top: 20px;">Правила еще не созданы.</p>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>

</body>
</html>