-- Таблица 1: Список правил (какие проверки мы делаем)
CREATE TABLE IF NOT EXISTS dq_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(255) NOT NULL,
    description TEXT,
    criticality ENUM('Low', 'Medium', 'High') DEFAULT 'Medium',
    is_active TINYINT(1) DEFAULT 1
);

-- Таблица 2: Журнал проверок (история ошибок)
CREATE TABLE IF NOT EXISTS dq_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_id INT,
    check_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    errors_found INT DEFAULT 0,
    status ENUM('Success', 'Warning', 'Critical') DEFAULT 'Success',
    FOREIGN KEY (rule_id) REFERENCES dq_rules(id)
);

-- Добавляем тестовые данные (чтобы таблица на сайте не была пустой)
INSERT INTO dq_rules (rule_name, description, criticality) VALUES
('Проверка на NULL в ИИН', 'Поиск клиентов с незаполненным ИИН', 'High'),
('Дубликаты договоров', 'Поиск повторяющихся номеров договоров за текущий год', 'Medium'),
('Отрицательные суммы', 'Проверка сумм транзакций на отрицательные значения', 'High'),
('Сверка с ГБД', 'Сверка данных с Государственной Базой Данных', 'Low');

-- Добавляем тестовые результаты проверок
INSERT INTO dq_logs (rule_id, errors_found, status) VALUES
(1, 15, 'Critical'),
(2, 0, 'Success'),
(3, 4, 'Warning');