<?php
session_start();
require_once 'config/db.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    // 1. Проверка паролей
    if ($password !== $confirm) {
        $message = "Пароли не совпадают!";
    } else {
        // 2. Проверка: есть ли уже такой логин?
        $stmt = $pdo->prepare("SELECT id FROM dq_users WHERE username = ?");
        $stmt->execute([$username]);
        
        if ($stmt->fetch()) {
            $message = "Этот логин уже занят!";
        } else {
            // 3. Создаем пользователя
            // По умолчанию даем роль "Аналитик", чтобы он не был главным Админом
            $sql = "INSERT INTO dq_users (username, password, full_name, email, role) VALUES (?, ?, ?, ?, 'Аналитик данных')";
            $stmt = $pdo->prepare($sql);
            
            if ($stmt->execute([$username, $password, $full_name, $email])) {
                // Успех! Перенаправляем на вход
                header('Location: login.php?registered=1');
                exit;
            } else {
                $message = "Ошибка при регистрации.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация | DAMU Quality</title>
    <style>
        body {
            background-color: #F4F7FA;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-card {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            border-top: 5px solid #0055A5;
        }
        h2 { color: #003366; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; text-align: left; }
        label { display: block; margin-bottom: 5px; color: #666; font-size: 14px; }
        input {
            width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;
        }
        button {
            width: 100%; padding: 12px; background-color: #0055A5; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; margin-top: 10px;
        }
        button:hover { background-color: #004080; }
        .error { color: red; font-size: 14px; margin-bottom: 15px; }
        .link { margin-top: 15px; font-size: 14px; display: block; color: #0055A5; text-decoration: none; }
        .link:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <div class="login-card">
        <h2 style="margin-top:0;">Регистрация сотрудника</h2>
        <p style="color:#777; font-size:14px; margin-bottom:20px;">Создание учетной записи в системе качества.</p>

        <?php if ($message): ?>
            <div class="error"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>ФИО Сотрудника</label>
                <input type="text" name="full_name" required placeholder="Иванов Иван">
            </div>
            
            <div class="form-group">
                <label>Придумайте Логин</label>
                <input type="text" name="username" required placeholder="ivanov.i">
            </div>

            <div class="form-group">
                <label>Корпоративный Email</label>
                <input type="email" name="email" required placeholder="ivanov@damu.kz">
            </div>

            <div class="form-group">
                <label>Пароль</label>
                <input type="password" name="password" required  placeholder="Введите пароль">
            </div>

            <div class="form-group">
                <label>Повторите пароль</label>
                <input type="password" name="confirm_password" required  placeholder="Повторите пароль">
            </div>

            <button type="submit">Зарегистрироваться</button>
        </form>

        <div style="margin-top: 20px; text-align: center; font-size: 14px;">
        Уже есть аккаунт? <br>
        <a href="login.php" style="color: #0055A5; font-weight: bold; text-decoration: none;">
            Войти в систему →
        </a>
    </div>
    </div>
</body>
</html>