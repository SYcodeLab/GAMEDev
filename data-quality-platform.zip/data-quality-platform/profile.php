<?php
session_start();
require_once 'config/db.php';

// Проверка доступа
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';
$msg_type = ''; // success или error

// --- ЛОГИКА: ОБНОВЛЕНИЕ ДАННЫХ ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // 1. Смена личных данных
    if (isset($_POST['update_info'])) {
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        
        $stmt = $pdo->prepare("UPDATE dq_users SET full_name = ?, email = ? WHERE id = ?");
        if ($stmt->execute([$full_name, $email, $user_id])) {
            $_SESSION['user_name'] = $full_name; // Обновляем имя в сессии сразу
            $message = "Данные успешно сохранены!";
            $msg_type = "success";
        } else {
            $message = "Ошибка при сохранении.";
            $msg_type = "error";
        }
    }

    // 2. Смена пароля
    if (isset($_POST['change_password'])) {
        $old_pass = $_POST['old_password'];
        $new_pass = $_POST['new_password'];
        $confirm_pass = $_POST['confirm_password'];

        // Получаем текущий пароль из БД
        $stmt = $pdo->prepare("SELECT password FROM dq_users WHERE id = ?");
        $stmt->execute([$user_id]);
        $current_user = $stmt->fetch();

        if ($current_user['password'] !== $old_pass) {
            $message = "Старый пароль введен неверно!";
            $msg_type = "error";
        } elseif ($new_pass !== $confirm_pass) {
            $message = "Новые пароли не совпадают!";
            $msg_type = "error";
        } else {
            // Обновляем пароль
            $stmt = $pdo->prepare("UPDATE dq_users SET password = ? WHERE id = ?");
            $stmt->execute([$new_pass, $user_id]);
            $message = "Пароль успешно изменен!";
            $msg_type = "success";
        }
    }
}

// Получаем свежие данные пользователя для отображения
$stmt = $pdo->prepare("SELECT * FROM dq_users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Личный кабинет | DAMU Quality</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .profile-header {
            background: linear-gradient(135deg, #0055A5 0%, #003366 100%);
            color: white;
            padding: 30px;
            border-radius: 8px 8px 0 0;
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .profile-avatar-big {
            width: 80px;
            height: 80px;
            background: white;
            color: #0055A5;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            font-weight: bold;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .form-section { padding: 30px; }
        .form-row { margin-bottom: 20px; }
        .form-row label { display: block; margin-bottom: 8px; color: #555; font-weight: 600; }
        .form-input {
            width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;
        }
        .msg-box {
            padding: 15px; margin-bottom: 20px; border-radius: 4px;
        }
        .msg-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .msg-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>

    <div class="top-navbar">
        <div class="logo">
            <i class="fas fa-layer-group"></i> DAMU <span style="font-weight:300; margin-left:5px;">Quality</span>
        </div>
        <div class="user-profile">
            <a href="profile.php" style="text-decoration: none; color: inherit; display: flex; align-items: center; gap: 10px;">
                <div class="avatar">
                    <?php echo mb_substr($_SESSION['user_name'] ?? 'U', 0, 1); ?>
                </div>
            </a>
            <a href="logout.php" style="margin-left:15px; color:#E74C3C;" title="Выйти из системы">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </div>

    <div class="layout">
        <div class="sidebar">
            <a href="index.php" class="nav-item"><i class="fas fa-chart-line"></i> Мониторинг качества</a>
            <a href="sources.php" class="nav-item"><i class="fas fa-database"></i> Источники данных</a>
            <a href="rules.php" class="nav-item"><i class="fas fa-cog"></i> Настройка правил</a>
            
            <hr style="border: 0.5px solid #444; margin: 20px 0;">
            
            <a href="analytics.php" class="nav-item">
                <i class="fas fa-file-invoice-dollar"></i> 
                <span>Управленческая отчетность</span>
            </a>
        </div>

        <div class="content-area">
            
            <?php if ($message): ?>
                <div class="msg-box msg-<?php echo $msg_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div style="display: flex; gap: 30px;">
                
                <div class="data-card" style="flex: 1.5; padding: 0; overflow: hidden;">
                    <div class="profile-header">
                        <div class="profile-avatar-big">
                            <?php echo mb_substr($user['full_name'] ?? 'U', 0, 1); ?>
                        </div>
                        <div>
                            <h2 style="margin: 0; font-size: 22px;"><?php echo htmlspecialchars($user['full_name']); ?></h2>
                            <p style="margin: 5px 0 0 0; opacity: 0.8;"><?php echo htmlspecialchars($user['role'] ?? 'Сотрудник'); ?></p>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <form method="POST">
                            <div class="form-row">
                                <label>Логин (не меняется)</label>
                                <input type="text" class="form-input" value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" disabled style="background: #f9f9f9;">
                            </div>
                            <div class="form-row">
                                <label>ФИО сотрудника</label>
                                <input type="text" name="full_name" class="form-input" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required>
                            </div>
                            <div class="form-row">
                                <label>Корпоративный Email</label>
                                <input type="email" name="email" class="form-input" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>">
                            </div>
                            <button type="submit" name="update_info" class="btn-run">Сохранить изменения</button>
                        </form>
                    </div>
                </div>

                <div class="data-card" style="flex: 1; height: fit-content;">
                    <h3><i class="fas fa-lock"></i> Безопасность</h3>
                    <p style="color: #777; font-size: 14px; margin-bottom: 20px;">Рекомендуется менять пароль согласно политике ИБ Фонда "Даму".</p>
                    
                    <form method="POST">
                        <div class="form-row">
                            <label>Старый пароль</label>
                            <input type="password" name="old_password" class="form-input" required>
                        </div>
                        <div class="form-row">
                            <label>Новый пароль</label>
                            <input type="password" name="new_password" class="form-input" required>
                        </div>
                        <div class="form-row">
                            <label>Повторите новый пароль</label>
                            <input type="password" name="confirm_password" class="form-input" required>
                        </div>
                        <button type="submit" name="change_password" class="btn-run" style="background-color: #E74C3C;">Сменить пароль</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

</body>
</html>