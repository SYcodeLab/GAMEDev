<?php
ob_start();
session_start();

// ПУТЬ К КОНФИГУ: должен быть идентичен тому, что в ai_monitor.php
require_once __DIR__ . '/../config/db.php';

// Авторизация
$current_user_name = $_SESSION['user_name'] ?? 'Chuck Magee'; 
$action = $_GET['action'] ?? '';

// 1. Получаем роль и регион (нужно для чата и экспорта)
$stmt = $pdo->prepare("SELECT region, role FROM st_people WHERE person = ?");
$stmt->execute([$current_user_name]);
$user = $stmt->fetch();

$user_role = $user['role'] ?? 'Guest';
$user_region = $user['region'] ?? 'All';

// 2. Обработка ЭКСПОРТА (отдельно, так как это не JSON)
if ($action === 'export') {
    $sql = "SELECT * FROM st_orders";
    $params = [];
    if ($user_role === 'Manager') {
        $sql .= " WHERE Region = ?";
        $params[] = $user_region;
    }
    $query = $pdo->prepare($sql);
    $query->execute($params);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=AI_Report_'.date('Y-m-d').'.csv');
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM для кириллицы в Excel
    
    $first = true;
    while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
        if ($first) { fputcsv($output, array_keys($row), ';'); $first = false; }
        fputcsv($output, $row, ';');
    }
    fclose($output);
    exit;
}

// 3. Обработка JSON-запросов (Валидатор и Чат)
header('Content-Type: application/json');

try {
    switch ($action) {
        case 'fix_one':
            $id = (int)($_GET['id'] ?? 0);
            if ($id > 0) {
                $stmt = $pdo->prepare("UPDATE ai_anomaly_detected SET status = 'fixed', fixed_at = NOW(), fixed_by = ? WHERE id = ?");
                $success = $stmt->execute([$current_user_name, $id]);
                echo json_encode(['success' => $success]);
            } else {
                echo json_encode(['success' => false, 'error' => 'ID не получен']);
            }
            break;

        case 'fix_all':
            $stmt = $pdo->prepare("UPDATE ai_anomaly_detected SET status = 'fixed', fixed_at = NOW(), fixed_by = ? WHERE status = 'detected'");
            $success = $stmt->execute([$current_user_name]);
            echo json_encode(['success' => $success]);
            break;

        case 'ai_query':
        case 'get_status':
            $sql = "SELECT COUNT(*) as total FROM st_orders";
            $params = [];
            if ($user_role === 'Manager') {
                $sql .= " WHERE Region = ?";
                $params[] = $user_region;
            }
            $query = $pdo->prepare($sql);
            $query->execute($params);
            $res = $query->fetch();

            echo json_encode([
                'success' => true,
                'text' => "База проанализирована. Для роли $user_role доступно {$res['total']} записей.",
                'count' => $res['total'],
                'export_url' => 'api.php?action=export'
            ]);
            break;

        default:
            echo json_encode(['success' => false, 'error' => 'Действие не определено']);
            break;
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

ob_end_flush();