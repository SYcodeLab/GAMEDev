<?php
// api/run_check.php
header('Content-Type: application/json');
require_once '../config/db.php';

// Получаем данные из запроса (JSON)
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['rule_id'])) {
    $rule_id = $data['rule_id'];

    // 1. Имитация логики проверки (в реальном проекте тут был бы сложный SQL запрос к 1С)
    // Генерируем случайное количество ошибок от 0 до 50
    $errors = rand(0, 20); 
    
    // Определяем статус
    if ($errors === 0) {
        $status = 'Success';
    } elseif ($errors < 10) {
        $status = 'Warning';
    } else {
        $status = 'Critical';
    }

    // 2. ЗАПИСЬ В БАЗУ ДАННЫХ (Реальный INSERT)
    try {
        $stmt = $pdo->prepare("INSERT INTO dq_logs (rule_id, errors_found, status) VALUES (?, ?, ?)");
        $stmt->execute([$rule_id, $errors, $status]);

        // Возвращаем ответ сайту
        echo json_encode(['success' => true, 'new_status' => $status, 'errors' => $errors]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }

} else {
    echo json_encode(['success' => false, 'error' => 'No ID provided']);
}
?>