<?php
require_once 'config/db.php';

// Очистим таблицы перед импортом (опционально, для чистого демо)
$pdo->exec("TRUNCATE TABLE st_people");
$pdo->exec("TRUNCATE TABLE st_orders");
$pdo->exec("TRUNCATE TABLE ai_anomaly_detected");

echo "Начало импорта...<br>";

// 1. Импорт People
if (($handle = fopen("Sample - Superstore_People.csv", "r")) !== FALSE) {
    fgetcsv($handle); // Пропуск заголовка
    $regions = ['Central', 'East', 'South', 'West'];
    while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
        if(empty($data[0])) continue;
        $reg = $regions[array_rand($regions)];
        $pdo->prepare("INSERT INTO st_people (person, region, role) VALUES (?, ?, ?)")
            ->execute([$data[0], $reg, 'Manager']);
    }
    fclose($handle);
}

// 2. Импорт Orders + Генерация Аномалий
if (($handle = fopen("Sample - Superstore_Orders.csv", "r")) !== FALSE) {
    fgetcsv($handle, 1000, ";"); // Пропуск заголовка
    $rowCount = 0;

    while (($data = fgetcsv($handle, 2000, ";")) !== FALSE) {
        $rowCount++;
        
        // Подготовка данных
        $order_date = date('Y-m-d', strtotime($data[5]));
        $ship_date = date('Y-m-d', strtotime($data[11]));
        $sales = (float)str_replace(',', '.', $data[18]);
        $profit = (float)str_replace(',', '.', $data[16]);
        $postal_code = $data[7];
        $state = $data[13];

        // Вставка в основную таблицу
        $sql = "INSERT INTO st_orders (category, city, country_region, customer_name, manufacturer, order_date, order_id, postal_code, product_name, region, segment, ship_date, ship_mode, state_province, sub_category, discount, profit, quantity, sales) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $pdo->prepare($sql)->execute([
            $data[0], $data[1], $data[2], $data[3], $data[4], $order_date, $data[6], 
            $postal_code, $data[8], $data[9], $data[10], $ship_date, $data[12], 
            $state, $data[14], str_replace(',', '.', $data[15]), $profit, $data[17], $sales
        ]);

        $newId = $pdo->lastInsertId();

        // --- ЛОГИКА ИИ: ПОИСК АНОМАЛИЙ НА ЛЕТУ ---
        
        // Пример 1: Ищем убыточные заказы (Аномалия прибыли)
        if ($profit < -100) {
            $pdo->prepare("INSERT INTO ai_anomaly_detected (entity_id, entity_type, column_name, current_value, ai_suggestion, reason) 
                VALUES (?, 'Order', 'Profit', ?, '0.00', 'Критический убыток: проверьте примененные скидки')")
                ->execute([$newId, $profit]);
        }

        // Пример 2: Ищем подозрительные почтовые индексы (имитация)
        if ($rowCount % 50 == 0) { // Каждая 50-я запись для разнообразия
            $pdo->prepare("INSERT INTO ai_anomaly_detected (entity_id, entity_type, column_name, current_value, ai_suggestion, reason) 
                VALUES (?, 'Order', 'Postal Code', ?, '90210', 'Индекс не соответствует региону доставки')")
                ->execute([$newId, $postal_code]);
        }
    }
    fclose($handle);
}

echo "Готово! Загружено строк: $rowCount. Аномалии сгенерированы.";