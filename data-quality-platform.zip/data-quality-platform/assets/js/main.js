// --- ОСНОВНЫЕ ФУНКЦИИ МОНИТОРИНГА ---

function runCheck(ruleId, btnElement) {
    const originalText = btnElement.innerHTML;
    btnElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Ждем...';
    btnElement.disabled = true;

    fetch('api/run_check.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rule_id: ruleId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            btnElement.innerHTML = '<i class="fas fa-check"></i> Готово';
            btnElement.style.background = '#27ae60'; // Success green
            
            setTimeout(() => {
                location.reload(); 
            }, 1000);
        } else {
            alert('Ошибка сервера: ' + data.error);
            btnElement.innerHTML = originalText;
            btnElement.disabled = false;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка соединения');
        btnElement.innerHTML = originalText;
        btnElement.disabled = false;
    });
}

// --- ЛОГИКА AI АССИСТЕНТА (Единый стиль) ---

async function sendAiQuery() {
    const input = document.getElementById('userInput');
    const chatWindow = document.getElementById('chatWindow');
    const text = input.value.trim();

    if (!text) return;

    // 1. Отображаем сообщение пользователя
    chatWindow.innerHTML += `
        <div class="msg user" style="align-self: flex-end; background: #a78bfa; color: white; padding: 10px 15px; border-radius: 12px; margin-bottom: 10px; font-size: 14px; max-width: 85%;">
            ${text}
        </div>`;
    
    input.value = '';
    chatWindow.scrollTop = chatWindow.scrollHeight;

    // 2. Имитация загрузки (печатает...)
    const typingId = 'typing_' + Date.now();
    chatWindow.innerHTML += `<div id="${typingId}" class="msg ai" style="font-size: 12px; color: #94a3b8;"><i class="fas fa-robot"></i> AI анализирует данные...</div>`;

    try {
        // 3. Запрос к API
        const response = await fetch('api.php?action=get_status');
        const data = await response.json();
        
        // Удаляем индикатор загрузки
        document.getElementById(typingId).remove();

        // 4. Формируем ответ AI
        let aiResponse = `
            <div class="msg ai" style="align-self: flex-start; background: #f1f5f9; color: #1e293b; padding: 12px 15px; border-radius: 12px; margin-bottom: 15px; font-size: 14px; border-bottom-left-radius: 2px; border: 1px solid #e2e8f0; max-width: 85%;">
                <b style="color: #8e44ad;"><i class="fas fa-robot"></i> DAMU AI:</b><br>
                Анализ завершен. Найдено записей: <b>${data.count}</b>.<br>
                Региональный доступ: <span class="host-code" style="font-size: 12px;">${data.region}</span>
                
                <div style="margin-top:12px; padding:12px; background:white; border:1px solid #e2e8f0; border-radius:10px; display:flex; align-items:center; gap:12px;">
                    <i class="fas fa-file-csv" style="font-size: 24px; color: #27ae60;"></i>
                    <div style="flex-grow:1;">
                        <div style="font-weight:600; font-size:12px;">Отчет_исправлений.csv</div>
                        <div style="font-size:10px; color: #64748b;">Нажмите для выгрузки из БД</div>
                    </div>
                    <a href="api.php?action=export" class="btn-submit" style="width:auto; padding:5px 12px; font-size:11px; text-decoration:none;">
                        Скачать
                    </a>
                </div>
            </div>`;
        
        chatWindow.innerHTML += aiResponse;
        chatWindow.scrollTop = chatWindow.scrollHeight;

    } catch (error) {
        console.error('AI Error:', error);
        document.getElementById(typingId).innerHTML = '<i class="fas fa-exclamation-triangle"></i> Ошибка связи с AI';
    }
}

// Привязка Enter к инпуту
document.addEventListener('DOMContentLoaded', () => {
    const inputField = document.getElementById('userInput');
    if(inputField) {
        inputField.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendAiQuery();
        });
    }
});